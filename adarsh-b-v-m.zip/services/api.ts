
// ... existing imports ...
import { UserRole, Principal, Teacher, Parent, Student, Attendance, Homework, Remark, TestResult, Notice, LoggedInUser, TeacherAttendance, FeeStructure, FeeTransaction, TimetableEntry, Exam, ExamSchedule, ExamResult, Message, LeaveRequest, Payroll, ClassSubject, StudentLeaveRequest, GalleryItem } from '../types';
import { db, storage } from '../firebase';
import { collection, doc, getDocs, getDoc, addDoc, updateDoc, deleteDoc, query, where, setDoc, writeBatch, limit } from 'firebase/firestore';
import { ref, uploadString, getDownloadURL } from 'firebase/storage';

// ... (Keep global config and helper functions same as before) ...
export const SCHOOL_LOGO_URL = "https://cdn-icons-png.flaticon.com/512/2602/2602414.png"; 
export const ALL_CLASSES = ['Nursery', 'LKG', 'UKG', '1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12'];

const today = () => new Date().toISOString().split('T')[0];

// Secure Password Generator
const generatePassword = () => {
  const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789@#$";
  let pass = "";
  for (let i = 0; i < 8; i++) {
    pass += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return pass;
};

// Basic Sanitization
const sanitize = (input: string) => {
    if (typeof input !== 'string') return input;
    return input.replace(/</g, "&lt;").replace(/>/g, "&gt;");
};

// Grading Logic
export const calculateGrade = (marks: number, maxMarks: number): string => {
  if (maxMarks === 0) return '-';
  const percentage = (marks / maxMarks) * 100;
  if (percentage >= 90) return 'A+';
  if (percentage >= 80) return 'A';
  if (percentage >= 70) return 'B';
  if (percentage >= 60) return 'C';
  if (percentage >= 50) return 'D';
  return 'F';
};

// Upload Helper (Base64 to Storage)
const uploadFileToStorage = async (path: string, base64String: string): Promise<string> => {
    if (!base64String || !base64String.startsWith('data:')) return base64String;
    try {
        const storageRef = ref(storage, path);
        await uploadString(storageRef, base64String, 'data_url');
        return await getDownloadURL(storageRef);
    } catch (error) {
        console.error("Upload failed, using base64 fallback (not recommended for production)", error);
        return base64String;
    }
};

// --- API IMPLEMENTATION ---
export const api = {
    calculateGrade,

    createBackup: async (): Promise<void> => {
        alert("Firebase Data is backed up automatically on Google Cloud!");
    },
    restoreBackup: async (file: File): Promise<void> => {
        alert("Restoring directly from JSON to Firebase is disabled for safety. Please contact admin.");
    },
    
    getLastSaveTime: (): string => new Date().toISOString(),
    resetDatabase: (): void => { alert("Reset disabled in Cloud Mode"); },

    // --- Auth ---
    login: async (mobile: string, pass: string, role: UserRole): Promise<LoggedInUser | null> => {
        const cleanMobile = mobile.trim();
        const cleanPass = pass.trim();

        if (!cleanMobile || !cleanPass) {
            throw new Error("मोबाइल नंबर और पासवर्ड दोनों आवश्यक हैं।");
        }

        // Admin Special Handler
        const isDefaultAdmin = cleanMobile === '9876543210' && cleanPass === 'admin';

        try {
            console.log(`Attempting ONLINE login for ${cleanMobile} as ${role}`);

            const q = query(collection(db, 'users'), where('mobile', '==', cleanMobile));
            
            // Timeout logic
            const timeoutPromise = new Promise((_, reject) => 
                setTimeout(() => reject(new Error("DB_TIMEOUT")), 30000)
            );

            let snapshot: any;
            try {
                snapshot = await Promise.race([getDocs(q), timeoutPromise]);
            } catch (err: any) {
                if (err.code === 'permission-denied') {
                    throw new Error("Firebase Permission Error:\nFirebase Console > Rules को 'if true;' करें।");
                }
                // If DB timeout, but we are admin, try to allow entry if possible or throw clear error
                if (isDefaultAdmin && (err.message === "DB_TIMEOUT" || err.code === 'unavailable')) {
                     console.warn("DB Unavailable, attempting emergency admin entry...");
                } else if (err.message === "DB_TIMEOUT") {
                     throw new Error("सर्वर से कनेक्ट नहीं हो पा रहा है। (Internet Issue)");
                } else {
                     throw err;
                }
            }
            
            // --- MASTER ADMIN AUTO-FIX LOGIC ---
            if (isDefaultAdmin) {
                let adminDoc = (snapshot && !snapshot.empty) ? snapshot.docs[0] : null;
                
                // 1. If User Missing in DB -> Seed it
                if (!adminDoc) {
                     console.log("Admin user missing in DB. Auto-seeding...");
                     try {
                         await seedDatabase(); 
                         // Try fetching again
                         const retrySnap = await getDocs(q);
                         adminDoc = retrySnap.empty ? null : retrySnap.docs[0];
                     } catch (seedErr) {
                         console.error("Seeding failed", seedErr);
                     }
                }
                
                // 2. If Still Missing (Seeding failed), Force Login (Mock)
                if (!adminDoc) {
                    const mockAdmin: Principal = { id: 'admin_emergency', name: 'Principal (Admin)', mobile: '9876543210', role: UserRole.PRINCIPAL };
                    sessionStorage.setItem('currentUser', JSON.stringify(mockAdmin));
                    return mockAdmin;
                }

                // 3. Fix Password/Role if corrupted
                const data = adminDoc.data();
                if (data.password !== 'admin' || data.role !== UserRole.PRINCIPAL) {
                    console.log("Fixing Admin Credentials in DB...");
                    try {
                        await updateDoc(doc(db, 'users', adminDoc.id), {
                            password: 'admin',
                            role: UserRole.PRINCIPAL
                        });
                    } catch(e) {
                        console.warn("Could not update DB (ReadOnly?), proceeding anyway.");
                    }
                    data.profileId = data.profileId || 'admin_restored';
                }

                // 4. Ensure Profile Exists
                try {
                    const profileRef = doc(db, 'principals', data.profileId);
                    const profileSnap = await getDoc(profileRef);
                    if (!profileSnap.exists()) {
                         console.log("Fixing Admin Profile...");
                         await setDoc(profileRef, { name: 'Principal (Admin)', mobile: '9876543210' });
                    }
                } catch(e) { console.warn("Profile check failed"); }
                
                // 5. Return Admin User (Override Role Selection)
                const adminUser: Principal = {
                    id: data.profileId,
                    name: 'Principal (Admin)',
                    mobile: '9876543210',
                    role: UserRole.PRINCIPAL
                };
                sessionStorage.setItem('currentUser', JSON.stringify(adminUser));
                return adminUser;
            }
            // -----------------------------------

            if (snapshot.empty) {
                throw new Error("यह मोबाइल नंबर पंजीकृत नहीं है। (User not found)");
            }

            // Verify Password for non-admin
            const userDoc = snapshot.docs.find((d: any) => d.data().role === role && d.data().password === cleanPass);
            
            if (!userDoc) {
                // Check if wrong role
                const wrongRoleDoc = snapshot.docs.find((d: any) => d.data().password === cleanPass);
                if (wrongRoleDoc) {
                    const actualRole = wrongRoleDoc.data().role;
                    throw new Error(`गलत रोल (Role) चुना गया है। यह नंबर '${actualRole.toUpperCase()}' के रूप में पंजीकृत है। कृपया '${actualRole.toUpperCase()}' चुनें।`);
                }
                throw new Error("पासवर्ड गलत है। कृपया पुनः प्रयास करें।");
            }

            // Fetch Profile
            const userData = userDoc.data();
            const collections = {
                [UserRole.PRINCIPAL]: 'principals',
                [UserRole.TEACHER]: 'teachers',
                [UserRole.PARENT]: 'parents',
                [UserRole.STUDENT]: 'students'
            };

            const profileRef = doc(db, collections[role], userData.profileId);
            const profileSnap = await getDoc(profileRef);
            
            if (profileSnap.exists()) {
                const userObj = { ...profileSnap.data(), id: userData.profileId } as LoggedInUser;
                sessionStorage.setItem('currentUser', JSON.stringify(userObj));
                return userObj;
            } else {
                throw new Error("उपयोगकर्ता प्रोफ़ाइल डेटाबेस में नहीं मिली।");
            }

        } catch (e: any) {
            console.error("Login Error:", e);
            throw e; 
        }
    },

    // Manual Demo Login (Only manual trigger)
    loginDemo: async (role: UserRole): Promise<LoggedInUser> => {
        let user: LoggedInUser;
        if (role === UserRole.PRINCIPAL) {
            user = { id: 'demo_admin', name: 'Principal (Demo)', mobile: '9876543210', role: UserRole.PRINCIPAL };
        } else if (role === UserRole.TEACHER) {
            user = { id: 'demo_teacher', name: 'Ramesh Kumar (Demo)', mobile: '9999999999', role: UserRole.TEACHER, assignedClasses: ['1', '2'], subject: 'Mathematics', qualification: 'B.Ed', experience: '5 Years', baseSalary: 25000 } as Teacher;
        } else if (role === UserRole.STUDENT) {
             user = { id: 'demo_student', name: 'Rohan Singh (Demo)', mobile: '8888888888', role: UserRole.STUDENT, class: '5', fatherName: 'Rajesh Singh', motherName: 'Anita Singh', parentId: 'demo_parent', gender: 'Male' } as Student;
        } else {
             user = { id: 'demo_parent', name: 'Rajesh Singh (Demo)', mobile: '7777777777', role: UserRole.PARENT, childId: 'demo_student' } as Parent;
        }
        sessionStorage.setItem('currentUser', JSON.stringify(user));
        return user;
    },

    // ... (Keep rest of the API methods exactly as they were) ...
    logout: () => {
        sessionStorage.removeItem('currentUser');
    },

    getCurrentUser: (): LoggedInUser | null => {
        const user = sessionStorage.getItem('currentUser');
        return user ? JSON.parse(user) : null;
    },

    getAllUserCredentials: async (): Promise<{name: string, role: string, mobile: string, password: string}[]> => {
        try {
            const snapshot = await getDocs(collection(db, 'users'));
            return snapshot.docs.map(doc => doc.data() as {name: string, role: string, mobile: string, password: string})
                .sort((a, b) => a.role.localeCompare(b.role));
        } catch(e) {
            return [];
        }
    },

    // --- Subjects ---
    getAllClassSubjects: async (): Promise<ClassSubject[]> => {
        try {
            const snapshot = await getDocs(collection(db, 'classSubjects'));
            return snapshot.docs.map(d => ({ id: d.id, ...d.data() } as ClassSubject));
        } catch(e) { return []; }
    },
    addClassSubject: async (className: string, subjectName: string): Promise<void> => {
        await addDoc(collection(db, 'classSubjects'), { 
            class: className, 
            subjectName: sanitize(subjectName) 
        });
    },
    removeClassSubject: async (id: string): Promise<void> => {
        await deleteDoc(doc(db, 'classSubjects', id));
    },

    // --- Notices ---
    getPublicNotices: async (): Promise<Notice[]> => {
        try {
            const q = query(collection(db, 'notices'), where('audience', '==', 'public'));
            const snapshot = await getDocs(q);
            return snapshot.docs.map(d => ({ id: d.id, ...d.data() } as Notice));
        } catch(e) { return []; }
    },
    getTeacherNotices: async (): Promise<Notice[]> => {
        try {
            const q = query(collection(db, 'notices'), where('audience', '==', 'teacher'));
            const snapshot = await getDocs(q);
            return snapshot.docs.map(d => ({ id: d.id, ...d.data() } as Notice));
        } catch(e) { return []; }
    },
    getAllNotices: async (): Promise<Notice[]> => {
        try {
            const snapshot = await getDocs(collection(db, 'notices'));
            return snapshot.docs.map(d => ({ id: d.id, ...d.data() } as Notice));
        } catch(e) { return []; }
    },
    createNotice: async (title: string, content: string, audience: 'public' | 'teacher'): Promise<void> => {
        await addDoc(collection(db, 'notices'), { 
            title: sanitize(title), 
            content: sanitize(content), 
            audience, 
            date: today() 
        });
    },
    deleteNotice: async (id: string): Promise<void> => {
        await deleteDoc(doc(db, 'notices', id));
    },

    // --- Gallery ---
    getGalleryItems: async (): Promise<GalleryItem[]> => {
        try {
            const snapshot = await getDocs(collection(db, 'gallery'));
            return snapshot.docs.map(d => ({ id: d.id, ...d.data() } as GalleryItem));
        } catch(e) { return []; }
    },
    addGalleryItem: async (item: Omit<GalleryItem, 'id' | 'date'>): Promise<void> => {
        let mediaUrl = item.url;
        if (item.url.startsWith('data:')) {
             mediaUrl = await uploadFileToStorage(`gallery/${Date.now()}_media`, item.url);
        }

        await addDoc(collection(db, 'gallery'), {
            date: today(),
            title: sanitize(item.title),
            description: item.description ? sanitize(item.description) : '',
            type: item.type,
            url: mediaUrl
        });
    },
    deleteGalleryItem: async (id: string): Promise<void> => {
        await deleteDoc(doc(db, 'gallery', id));
    },

    // --- Users ---
    getAllTeachers: async (): Promise<Teacher[]> => {
        try {
            const snapshot = await getDocs(collection(db, 'teachers'));
            return snapshot.docs.map(d => ({ id: d.id, ...d.data() } as Teacher));
        } catch(e) { return []; }
    },
    getAllStudents: async (): Promise<Student[]> => {
        try {
            const snapshot = await getDocs(collection(db, 'students'));
            return snapshot.docs.map(d => ({ id: d.id, ...d.data() } as Student));
        } catch(e) { return []; }
    },
    getStudentsByClass: async (className: string): Promise<Student[]> => {
        try {
            const q = query(collection(db, 'students'), where('class', '==', className));
            const snapshot = await getDocs(q);
            return snapshot.docs.map(d => ({ id: d.id, ...d.data() } as Student));
        } catch(e) { return []; }
    },
    getStudentById: async (studentId: string): Promise<Student | null> => {
        if(studentId === 'demo_student') return { id: 'demo_student', name: 'Student (Demo)', mobile: '8888888888', role: UserRole.STUDENT, class: '5', fatherName: 'Rajesh Singh', motherName: 'Anita Singh', parentId: 'demo_parent', gender: 'Male' } as Student;
        try {
            const d = await getDoc(doc(db, 'students', studentId));
            return d.exists() ? ({ id: d.id, ...d.data() } as Student) : null;
        } catch(e) { return null; }
    },
    
    addTeacher: async (teacherData: Omit<Teacher, 'id' | 'role'>): Promise<string> => {
        const password = generatePassword();
        const teacherRef = await addDoc(collection(db, 'teachers'), {
            ...teacherData,
            role: UserRole.TEACHER
        });
        
        await addDoc(collection(db, 'users'), {
            mobile: teacherData.mobile,
            password,
            role: UserRole.TEACHER,
            profileId: teacherRef.id,
            name: teacherData.name
        });
        return password;
    },
    
    updateStudentProfilePicture: async (studentId: string, imageData: string): Promise<void> => {
        let url = '';
        if (imageData) {
            url = await uploadFileToStorage(`profiles/${studentId}.jpg`, imageData);
        }
        await updateDoc(doc(db, 'students', studentId), { profilePicture: url });
    },

    addStudent: async (studentData: Omit<Student, 'id' | 'role' | 'parentId'>, parentMobile: string): Promise<{studentPass: string, parentPass: string, studentId: string, parentId: string}> => {
        const studentPass = generatePassword();
        const parentPass = generatePassword();
        
        let profilePicUrl = '';
        if (studentData.profilePicture) {
            profilePicUrl = await uploadFileToStorage(`profiles/${Date.now()}_student.jpg`, studentData.profilePicture);
        }

        const parentRef = await addDoc(collection(db, 'parents'), {
            name: sanitize(studentData.fatherName),
            mobile: parentMobile,
            role: UserRole.PARENT,
            childId: 'TEMP'
        });

        const studentRef = await addDoc(collection(db, 'students'), {
            ...studentData,
            profilePicture: profilePicUrl,
            name: sanitize(studentData.name),
            role: UserRole.STUDENT,
            parentId: parentRef.id
        });

        await updateDoc(doc(db, 'parents', parentRef.id), { childId: studentRef.id });

        await addDoc(collection(db, 'users'), {
            mobile: studentData.mobile,
            password: studentPass,
            role: UserRole.STUDENT,
            profileId: studentRef.id,
            name: studentData.name
        });

        await addDoc(collection(db, 'users'), {
            mobile: parentMobile,
            password: parentPass,
            role: UserRole.PARENT,
            profileId: parentRef.id,
            name: studentData.fatherName
        });

        return { studentPass, parentPass, studentId: studentRef.id, parentId: parentRef.id };
    },

    updateStudent: async (student: Student): Promise<void> => {
        const { id, ...data } = student;
        await updateDoc(doc(db, 'students', id), data);
        const q = query(collection(db, 'users'), where('profileId', '==', id), where('role', '==', UserRole.STUDENT));
        const snapshot = await getDocs(q);
        if(!snapshot.empty) {
             await updateDoc(doc(db, 'users', snapshot.docs[0].id), { mobile: student.mobile });
        }
    },

    // --- Attendance ---
    getAttendance: async (studentId: string): Promise<Attendance[]> => {
        try {
            const q = query(collection(db, 'attendance'), where('studentId', '==', studentId));
            const snapshot = await getDocs(q);
            return snapshot.docs.map(d => d.data() as Attendance);
        } catch(e) { return []; }
    },
    getAttendanceForClass: async (className: string, date: string): Promise<Attendance[]> => {
        try {
            const q = query(collection(db, 'attendance'), where('date', '==', date));
            const snapshot = await getDocs(q);
            const students = await api.getStudentsByClass(className);
            const ids = students.map(s => s.id);
            return snapshot.docs.map(d => d.data() as Attendance).filter(a => ids.includes(a.studentId));
        } catch(e) { return []; }
    },
    setAttendance: async (studentId: string, date: string, status: 'Present' | 'Absent', reason?: string): Promise<void> => {
        const q = query(collection(db, 'attendance'), where('studentId', '==', studentId), where('date', '==', date));
        const snapshot = await getDocs(q);
        if (!snapshot.empty) {
            await updateDoc(doc(db, 'attendance', snapshot.docs[0].id), { status, reason: reason || '' });
        } else {
            await addDoc(collection(db, 'attendance'), { studentId, date, status, reason });
        }
    },

    // --- Homework ---
    getHomeworkForClass: async (className: string): Promise<Homework[]> => {
        try {
            const q = query(collection(db, 'homeworks'), where('class', '==', className));
            const snapshot = await getDocs(q);
            return snapshot.docs.map(d => ({ id: d.id, ...d.data() } as Homework));
        } catch(e) { return []; }
    },
    getAllHomeworks: async (): Promise<Homework[]> => {
        try {
            const snapshot = await getDocs(collection(db, 'homeworks'));
            return snapshot.docs.map(d => ({ id: d.id, ...d.data() } as Homework));
        } catch(e) { return []; }
    },
    addHomework: async (className: string, date: string, subject: string, details: string, dueDate?: string, teacherId?: string, attachment?: string, attachmentName?: string): Promise<void> => {
        let fileUrl = attachment;
        if (attachment && attachment.startsWith('data:')) {
            fileUrl = await uploadFileToStorage(`homework/${Date.now()}_${attachmentName}`, attachment);
        }

        await addDoc(collection(db, 'homeworks'), { 
            class: className, 
            date, 
            subject: sanitize(subject), 
            details: sanitize(details), 
            dueDate, 
            teacherId, 
            attachment: fileUrl, 
            attachmentName 
        });
    },

    // --- Remarks ---
    getRemarksForClass: async (className: string, date: string): Promise<Remark[]> => {
        try {
            const q = query(collection(db, 'remarks'), where('date', '==', date));
            const snapshot = await getDocs(q);
            const students = await api.getStudentsByClass(className);
            const ids = students.map(s => s.id);
            return snapshot.docs.map(d => d.data() as Remark).filter(r => ids.includes(r.studentId));
        } catch(e) { return []; }
    },
    getRemarksForStudent: async (studentId: string): Promise<Remark[]> => {
        try {
            const q = query(collection(db, 'remarks'), where('studentId', '==', studentId));
            const snapshot = await getDocs(q);
            return snapshot.docs.map(d => d.data() as Remark);
        } catch(e) { return []; }
    },
    addRemark: async (studentId: string, homeworkId: string, remark: string, date: string): Promise<void> => {
        await addDoc(collection(db, 'remarks'), { studentId, homeworkId, remark: sanitize(remark), date });
    },

    // --- Results ---
    getResults: async (studentId: string): Promise<TestResult[]> => {
        return [];
    },

    // --- Fees ---
    getFinancialStats: async (): Promise<{ totalCollected: number }> => {
        try {
            const snapshot = await getDocs(collection(db, 'feeTransactions'));
            const totalCollected = snapshot.docs.reduce((sum, doc) => sum + doc.data().amount, 0);
            return { totalCollected };
        } catch(e) { return { totalCollected: 0 }; }
    },
    getAllFeeTransactions: async (): Promise<FeeTransaction[]> => {
        try {
            const snapshot = await getDocs(collection(db, 'feeTransactions'));
            return snapshot.docs.map(d => ({ id: d.id, ...d.data() } as FeeTransaction));
        } catch(e) { return []; }
    },
    getStudentFeeInfo: async (studentId: string): Promise<{
        structure: (FeeStructure & {total: number})[],
        transactions: FeeTransaction[],
        totalPayable: number,
        totalPaid: number,
        balance: number
    }> => {
        try {
            const student = await api.getStudentById(studentId);
            if (!student) return { structure: [], transactions: [], totalPayable: 0, totalPaid: 0, balance: 0 };
            
            const fsSnapshot = await getDocs(query(collection(db, 'feeStructures'), where('class', '==', student.class)));
            const structures = fsSnapshot.docs.map(d => d.data() as FeeStructure);
            
            const ftSnapshot = await getDocs(query(collection(db, 'feeTransactions'), where('studentId', '==', studentId)));
            const transactions = ftSnapshot.docs.map(d => ({ id: d.id, ...d.data() } as FeeTransaction));
            
            const totalPayable = structures.reduce((sum, s) => sum + s.amount, 0);
            const totalPaid = transactions.reduce((sum, t) => sum + t.amount, 0);
            
            const structureWithTotal = structures.map(s => ({...s, total: s.amount}));
            
            return { structure: structureWithTotal, transactions, totalPayable, totalPaid, balance: totalPayable - totalPaid };
        } catch(e) { return { structure: [], transactions: [], totalPayable: 0, totalPaid: 0, balance: 0 }; }
    },
    payFee: async (studentId: string, amount: number, type: 'Admission' | 'Tuition' | 'Exam' | 'Annual', paymentMethod: 'Cash' | 'Online' | 'UPI'): Promise<void> => {
        await addDoc(collection(db, 'feeTransactions'), { studentId, amount, type, date: today(), paymentMethod });
    },

    // --- Timetable ---
    getTimetableForClass: async (className: string): Promise<TimetableEntry[]> => {
        try {
            const q = query(collection(db, 'timetable'), where('class', '==', className));
            const snapshot = await getDocs(q);
            return snapshot.docs.map(d => ({ id: d.id, ...d.data() } as TimetableEntry));
        } catch(e) { return []; }
    },
    getTimetableForTeacher: async (teacherId: string): Promise<TimetableEntry[]> => {
        try {
            const q = query(collection(db, 'timetable'), where('teacherId', '==', teacherId));
            const snapshot = await getDocs(q);
            return snapshot.docs.map(d => ({ id: d.id, ...d.data() } as TimetableEntry));
        } catch(e) { return []; }
    },
    saveTimetableEntry: async (entry: Partial<TimetableEntry>): Promise<void> => {
        const q = query(
            collection(db, 'timetable'), 
            where('class', '==', entry.class), 
            where('day', '==', entry.day), 
            where('period', '==', entry.period)
        );
        const snapshot = await getDocs(q);
        if(!snapshot.empty) {
            await updateDoc(doc(db, 'timetable', snapshot.docs[0].id), entry);
        } else {
            await addDoc(collection(db, 'timetable'), entry);
        }
    },

    // --- Exams ---
    getAllExams: async (): Promise<Exam[]> => {
        try {
            const snapshot = await getDocs(collection(db, 'exams'));
            return snapshot.docs.map(d => ({ id: d.id, ...d.data() } as Exam));
        } catch(e) { return []; }
    },
    getExamSchedules: async (examId: string, className: string): Promise<ExamSchedule[]> => {
        try {
            const q = query(collection(db, 'examSchedules'), where('examId', '==', examId), where('class', '==', className));
            const snapshot = await getDocs(q);
            if (!snapshot.empty) return snapshot.docs.map(d => ({ id: d.id, ...d.data() } as ExamSchedule));
            
            const subjects = await api.getSubjectsForClass(className);
            return subjects.map(s => ({
                id: 'temp_' + s.id,
                examId,
                class: className,
                subject: s.subjectName,
                date: today(),
                maxMarks: 100, 
                startTime: '09:00',
                endTime: '12:00'
            }));
        } catch(e) { return []; }
    },
    getSubjectsForClass: async (className: string): Promise<ClassSubject[]> => {
         try {
             const q = query(collection(db, 'classSubjects'), where('class', '==', className));
             const snapshot = await getDocs(q);
             return snapshot.docs.map(d => ({ id: d.id, ...d.data() } as ClassSubject));
         } catch(e) { return []; }
    },
    getExamResultsForClass: async (examId: string, className: string, subject: string): Promise<ExamResult[]> => {
        try {
            const q = query(collection(db, 'examResults'), where('examId', '==', examId), where('subject', '==', subject));
            const snapshot = await getDocs(q);
            
            const students = await api.getStudentsByClass(className);
            const studentIds = students.map(s => s.id);
            
            return snapshot.docs.map(d => ({ id: d.id, ...d.data() } as ExamResult)).filter(r => studentIds.includes(r.studentId));
        } catch(e) { return []; }
    },
    getResultsForExamAndClass: async (examId: string, className: string): Promise<ExamResult[]> => {
        try {
            const q = query(collection(db, 'examResults'), where('examId', '==', examId));
            const snapshot = await getDocs(q);
            const students = await api.getStudentsByClass(className);
            const studentIds = students.map(s => s.id);
            return snapshot.docs.map(d => ({ id: d.id, ...d.data() } as ExamResult)).filter(r => studentIds.includes(r.studentId));
        } catch(e) { return []; }
    },
    getStudentExamResults: async (studentId: string): Promise<ExamResult[]> => {
        try {
            const q = query(collection(db, 'examResults'), where('studentId', '==', studentId));
            const snapshot = await getDocs(q);
            return snapshot.docs.map(d => ({ id: d.id, ...d.data() } as ExamResult));
        } catch(e) { return []; }
    },
    saveExamResult: async (examId: string, studentId: string, subject: string, marksObtained: number, maxMarks: number): Promise<void> => {
        const q = query(
            collection(db, 'examResults'), 
            where('examId', '==', examId), 
            where('studentId', '==', studentId),
            where('subject', '==', subject)
        );
        const snapshot = await getDocs(q);
        const resultData = {
            examId, studentId, subject, marksObtained, maxMarks,
            grade: calculateGrade(marksObtained, maxMarks)
        };
        if (!snapshot.empty) {
            await updateDoc(doc(db, 'examResults', snapshot.docs[0].id), resultData);
        } else {
            await addDoc(collection(db, 'examResults'), resultData);
        }
    },
    getConsolidatedMarks: async (studentId: string): Promise<any[]> => {
        const results = await api.getStudentExamResults(studentId);
        const subjects = [...new Set(results.map(r => r.subject))];
        
        return subjects.map(subject => {
            const q = results.find(r => r.examId === 'exam_q' && r.subject === subject) || { marksObtained: 0, maxMarks: 0 };
            const h = results.find(r => r.examId === 'exam_h' && r.subject === subject) || { marksObtained: 0, maxMarks: 0 };
            const a = results.find(r => r.examId === 'exam_a' && r.subject === subject) || { marksObtained: 0, maxMarks: 0 };
            
            const totalObtained = q.marksObtained + h.marksObtained + a.marksObtained;
            const totalMax = q.maxMarks + h.maxMarks + a.maxMarks;
            
            return {
                subject,
                quarterly: { obtained: q.marksObtained, max: q.maxMarks },
                halfYearly: { obtained: h.marksObtained, max: h.maxMarks },
                annual: { obtained: a.marksObtained, max: a.maxMarks },
                total: { obtained: totalObtained, max: totalMax },
                grade: calculateGrade(totalObtained, totalMax)
            };
        });
    },

    // --- Communication (Messages) ---
    getContacts: async (userId: string, role: string): Promise<{id: string, name: string, role: string, unread: number}[]> => {
        const contacts: any[] = [];
        if (role === UserRole.TEACHER) {
             const teachers = await api.getAllTeachers();
             const me = teachers.find(t => t.id === userId);
             
             if (me) {
                 const pSnapshot = await getDocs(collection(db, 'principals'));
                 if(!pSnapshot.empty) {
                     const p = pSnapshot.docs[0].data();
                     contacts.push({ id: pSnapshot.docs[0].id, name: p.name, role: 'Principal', unread: 0 });
                 }
                 for (const cls of me.assignedClasses) {
                     const students = await api.getStudentsByClass(cls);
                     for(const s of students) {
                         contacts.push({ id: s.id, name: s.name, role: 'Student', unread: 0 });
                         const parent = await getDoc(doc(db, 'parents', s.parentId));
                         if(parent.exists()) contacts.push({ id: parent.id, name: parent.data().name, role: 'Parent', unread: 0 });
                     }
                 }
             }
        }
        return contacts;
    },
    getMessages: async (userId: string, otherId: string): Promise<Message[]> => {
        try {
            const q = query(
                collection(db, 'messages'), 
                where('participants', 'array-contains', userId)
            );
            const snapshot = await getDocs(q);
            return snapshot.docs
                .map(d => ({ id: d.id, ...d.data() } as Message))
                .filter(m => (m.senderId === userId && m.receiverId === otherId) || (m.senderId === otherId && m.receiverId === userId))
                .sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime());
        } catch(e) { return []; }
    },
    sendMessage: async (senderId: string, receiverId: string, content: string): Promise<void> => {
        await addDoc(collection(db, 'messages'), {
            senderId,
            receiverId,
            content: sanitize(content),
            timestamp: new Date().toISOString(),
            isRead: false,
            participants: [senderId, receiverId]
        });
    },
    markMessagesAsRead: async (senderId: string, receiverId: string): Promise<void> => {
        try {
            const q = query(
                collection(db, 'messages'), 
                where('senderId', '==', senderId), 
                where('receiverId', '==', receiverId),
                where('isRead', '==', false)
            );
            const snapshot = await getDocs(q);
            const batch = writeBatch(db);
            snapshot.docs.forEach(d => {
                batch.update(doc(db, 'messages', d.id), { isRead: true });
            });
            await batch.commit();
        } catch(e) { /* ignore */ }
    },
    getUnreadCount: async (userId: string): Promise<number> => {
        try {
            const q = query(collection(db, 'messages'), where('receiverId', '==', userId), where('isRead', '==', false));
            const snapshot = await getDocs(q);
            return snapshot.size;
        } catch(e) { return 0; }
    },

    // --- HR ---
    getAllLeaves: async (): Promise<LeaveRequest[]> => {
        try {
            const snapshot = await getDocs(collection(db, 'leaves'));
            return snapshot.docs.map(d => ({ id: d.id, ...d.data() } as LeaveRequest));
        } catch(e) { return []; }
    },
    getLeavesByEmployee: async (employeeId: string): Promise<LeaveRequest[]> => {
        try {
            const q = query(collection(db, 'leaves'), where('employeeId', '==', employeeId));
            const snapshot = await getDocs(q);
            return snapshot.docs.map(d => ({ id: d.id, ...d.data() } as LeaveRequest));
        } catch(e) { return []; }
    },
    applyLeave: async (leave: any): Promise<void> => {
        await addDoc(collection(db, 'leaves'), {
            ...leave,
            status: 'Pending',
            requestDate: new Date().toISOString()
        });
    },
    updateLeaveStatus: async (id: string, status: string): Promise<void> => {
        await updateDoc(doc(db, 'leaves', id), { status });
    },

    // --- Payroll ---
    getPayrolls: async (month: string): Promise<Payroll[]> => {
         try {
             const q = query(collection(db, 'payrolls'), where('month', '==', month));
             const snapshot = await getDocs(q);
             return snapshot.docs.map(d => ({ id: d.id, ...d.data() } as Payroll));
         } catch(e) { return []; }
    },
    getEmployeePayrollHistory: async (employeeId: string): Promise<Payroll[]> => {
         try {
             const q = query(collection(db, 'payrolls'), where('employeeId', '==', employeeId));
             const snapshot = await getDocs(q);
             return snapshot.docs.map(d => ({ id: d.id, ...d.data() } as Payroll));
         } catch(e) { return []; }
    },
    createPayroll: async (payroll: any): Promise<void> => {
         await addDoc(collection(db, 'payrolls'), { ...payroll, status: 'Paid', paymentDate: today() });
    },

    // --- Student Leaves ---
    getStudentLeaves: async (parentId: string): Promise<StudentLeaveRequest[]> => {
        try {
            const q = query(collection(db, 'studentLeaves'), where('parentId', '==', parentId));
            const snapshot = await getDocs(q);
            return snapshot.docs.map(d => ({ id: d.id, ...d.data() } as StudentLeaveRequest));
        } catch(e) { return []; }
    },
    getAllStudentLeaves: async (): Promise<StudentLeaveRequest[]> => {
         try {
             const snapshot = await getDocs(collection(db, 'studentLeaves'));
             const leaves = snapshot.docs.map(d => ({ id: d.id, ...d.data() } as StudentLeaveRequest));
             
             const enriched = [];
             for(const l of leaves) {
                 const s = await api.getStudentById(l.studentId);
                 enriched.push({ ...l, studentName: s?.name || 'Unknown', class: s?.class || '-' });
             }
             return enriched;
         } catch(e) { return []; }
    },
    applyStudentLeave: async (request: any): Promise<void> => {
        await addDoc(collection(db, 'studentLeaves'), {
            ...request,
            status: 'Pending',
            requestDate: new Date().toISOString()
        });
    },
    updateStudentLeaveStatus: async (id: string, status: string): Promise<void> => {
        await updateDoc(doc(db, 'studentLeaves', id), { status });
    }
};

// --- INITIAL DATA SEEDING ---
async function seedDatabase() {
    console.log("Seeding Database...");
    const batch = writeBatch(db);

    // Idempotency check to prevent overwriting if partially successful
    const existingAdmin = await getDocs(query(collection(db, 'users'), where('mobile', '==', '9876543210')));
    if (!existingAdmin.empty) {
        console.log("Admin user already exists. Skipping seeding.");
        return;
    }

    const principalRef = doc(collection(db, 'principals'));
    batch.set(principalRef, { name: 'Principal (Admin)', mobile: '9876543210' });

    const userRef = doc(collection(db, 'users'));
    batch.set(userRef, {
        mobile: '9876543210',
        password: 'admin',
        role: UserRole.PRINCIPAL,
        profileId: principalRef.id,
        name: 'Principal (Admin)'
    });

    const exams = [
        { name: 'Monthly Test', startDate: today(), endDate: today(), status: 'Ongoing' },
        { name: 'Timahi Pariksha (Quarterly)', startDate: today(), endDate: today(), status: 'Upcoming' },
        { name: 'Chhimaahi Pariksha (Half Yearly)', startDate: today(), endDate: today(), status: 'Upcoming' },
        { name: 'Salana Pariksha (Annual)', startDate: today(), endDate: today(), status: 'Upcoming' }
    ];
    exams.forEach(e => {
        const ref = doc(collection(db, 'exams'));
        batch.set(ref, e);
    });

    const fees = [
        { class: 'Nursery', type: 'Admission', amount: 5000 },
        { class: 'Nursery', type: 'Tuition', amount: 1000 },
        { class: '1', type: 'Admission', amount: 6000 },
        { class: '1', type: 'Tuition', amount: 1200 },
    ];
    fees.forEach(f => {
        const ref = doc(collection(db, 'feeStructures'));
        batch.set(ref, f);
    });

    await batch.commit();
    console.log("Seeding Complete. Login with 9876543210 / admin");
}
