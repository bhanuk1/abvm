
export enum UserRole {
  PRINCIPAL = 'principal',
  TEACHER = 'teacher',
  PARENT = 'parent',
  STUDENT = 'student',
}

export interface User {
  id: string;
  name: string;
  mobile: string;
  role: UserRole;
}

export interface Teacher extends User {
  role: UserRole.TEACHER;
  assignedClasses: string[];
  subject?: string;
  qualification?: string;
  experience?: string; // e.g. "5 Years"
  performanceRating?: number; // 1 to 5
  email?: string;
  baseSalary?: number; // Monthly fixed salary
}

export interface Parent extends User {
  role: UserRole.PARENT;
  childId: string;
}

export interface Principal extends User {
  role: UserRole.PRINCIPAL;
}

export interface Student extends User {
  role: UserRole.STUDENT;
  fatherName: string;
  motherName: string;
  class: string;
  gender: 'Male' | 'Female';
  parentId: string;
  profilePicture?: string; // Base64 string or URL
  
  // Extended Details
  admissionNo?: string; // Scholar Number
  admissionDate?: string;
  dob?: string;
  bloodGroup?: string;
  aadharNo?: string;
  category?: 'General' | 'OBC' | 'SC' | 'ST' | 'Other';
  religion?: string;
  address?: string;
  city?: string;
  pincode?: string;
}

export type LoggedInUser = Principal | Teacher | Parent | Student | null;

export interface ClassSubject {
  id: string;
  class: string;
  subjectName: string;
}

export interface Attendance {
  studentId: string;
  date: string; // YYYY-MM-DD
  status: 'Present' | 'Absent';
  reason?: string;
}

export interface TeacherAttendance {
  teacherId: string;
  date: string; // YYYY-MM-DD
  status: 'Present' | 'Absent';
}

export interface Homework {
  id: string;
  class: string;
  date: string; // YYYY-MM-DD
  subject: string;
  details: string;
  dueDate?: string; // YYYY-MM-DD
  teacherId?: string; // To track work record
  attachment?: string; // Base64 string
  attachmentName?: string; // File name
}

export interface Remark {
  studentId: string;
  homeworkId: string;
  remark: string;
  date: string; // YYYY-MM-DD
}

export interface TestResult {
  studentId: string;
  subject: string;
  marks: number;
  maxMarks: number;
  date: string; // YYYY-MM-DD
}

export interface Notice {
  id: string;
  title: string;
  content: string;
  date: string; // YYYY-MM-DD
  audience: 'public' | 'teacher';
}

export interface FeeStructure {
  class: string;
  type: 'Admission' | 'Tuition' | 'Exam' | 'Annual';
  amount: number;
}

export interface FeeTransaction {
  id: string;
  studentId: string;
  amount: number;
  type: 'Admission' | 'Tuition' | 'Exam' | 'Annual';
  date: string; // YYYY-MM-DD
  paymentMethod: 'Cash' | 'Online' | 'UPI';
}

export interface TimetableEntry {
  id: string;
  class: string;
  day: string; // Monday, Tuesday...
  period: number;
  subject: string;
  teacherId?: string;
  startTime: string;
  endTime: string;
}

export interface Exam {
  id: string;
  name: string;
  startDate: string;
  endDate: string;
  status: 'Upcoming' | 'Ongoing' | 'Completed';
}

export interface ExamSchedule {
  id: string;
  examId: string;
  class: string;
  subject: string;
  date: string;
  maxMarks: number;
  startTime: string;
  endTime: string;
}

export interface ExamResult {
  id: string;
  examId: string;
  studentId: string;
  subject: string;
  marksObtained: number;
  maxMarks: number;
  grade: string;
}

export interface Message {
  id: string;
  senderId: string;
  receiverId: string;
  content: string;
  timestamp: string;
  isRead: boolean;
}

export interface LeaveRequest {
  id: string;
  employeeId: string;
  employeeName?: string;
  startDate: string;
  endDate: string;
  type: 'Sick' | 'Casual' | 'Emergency';
  reason: string;
  status: 'Pending' | 'Approved' | 'Rejected';
  requestDate: string;
}

export interface StudentLeaveRequest {
  id: string;
  studentId: string;
  studentName?: string;
  class?: string;
  parentId: string;
  startDate: string;
  endDate: string;
  reason: string;
  status: 'Pending' | 'Approved' | 'Rejected';
  requestDate: string;
}

export interface Payroll {
  id: string;
  employeeId: string;
  employeeName?: string;
  month: string; // YYYY-MM
  basicSalary: number;
  allowances: number;
  deductions: number;
  netSalary: number;
  status: 'Pending' | 'Paid';
  paymentDate?: string;
}

export interface GalleryItem {
  id: string;
  type: 'photo' | 'video';
  title: string;
  url: string; // Base64 or External Link
  date: string;
  description?: string;
}
