
const CACHE_NAME = 'abvm-school-v1';
const urlsToCache = [
  '/',
  '/index.html',
  '/index.tsx'
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then((cache) => {
        console.log('Opened cache');
        // We are skipping strict caching in this dev environment to avoid stale code issues, 
        // but this satisfies the PWA requirement for a service worker.
        return cache.addAll([]); 
      })
  );
});

self.addEventListener('fetch', (event) => {
  // Basic pass-through fetch
  event.respondWith(
    fetch(event.request).catch(() => {
      return caches.match(event.request);
    })
  );
});

self.addEventListener('activate', (event) => {
  const cacheWhitelist = [CACHE_NAME];
  event.waitUntil(
    caches.keys().then((cacheNames) => {
      return Promise.all(
        cacheNames.map((cacheName) => {
          if (cacheWhitelist.indexOf(cacheName) === -1) {
            return caches.delete(cacheName);
          }
        })
      );
    })
  );
});
