# Adarsh Bal Vidya Mandir (ABVM) App

## Project Setup

1.  Install dependencies:
    ```bash
    npm install
    ```

2.  Run development server:
    ```bash
    npm run dev
    ```

3.  Build for production:
    ```bash
    npm run build
    ```

## How to Push to GitHub (GitHub पर कैसे डालें)

### Step 1: Create Repository on GitHub
1. Go to [GitHub.com](https://github.com) and sign in.
2. Click the **+** icon (top right) -> **New repository**.
3. Name it (e.g., `abvm-school-app`).
4. Click **Create repository**.

### Step 2: Initialize Git locally
Open your terminal (VS Code terminal) and run these commands one by one:

```bash
# 1. Initialize Git
git init

# 2. Add all files
git add .

# 3. Commit files
git commit -m "Initial commit"

# 4. Rename branch to main
git branch -M main

# 5. Link to GitHub (Replace YOUR_USERNAME with your actual GitHub username)
# You will find the exact link on the page after creating the repository in Step 1.
git remote add origin https://github.com/YOUR_USERNAME/abvm-school-app.git

# 6. Push code
git push -u origin main
```

## Features

- **Principal Dashboard**: Manage students, teachers, fees, subjects, and results.
- **Teacher Dashboard**: Mark attendance, add homework, enter marks.
- **Parent Dashboard**: View child's progress, pay fees, view homework.
- **Student Dashboard**: View homework, results, notices.
