
import React, { useState, useEffect, useCallback, useRef } from 'react';
import { LoggedInUser, UserRole } from './types';
import LoginScreen from './screens/LoginScreen';
import PrincipalDashboard from './screens/PrincipalDashboard';
import TeacherDashboard from './screens/TeacherDashboard';
import ParentDashboard from './screens/ParentDashboard';
import StudentDashboard from './screens/StudentDashboard';
import { api } from './services/api';

const SESSION_TIMEOUT = 15 * 60 * 1000; // 15 Minutes in milliseconds

const App: React.FC = () => {
  const [currentUser, setCurrentUser] = useState<LoggedInUser>(null);
  const [loading, setLoading] = useState(true);
  const timeoutRef = useRef<any>(null);

  const handleLogout = useCallback(() => {
    api.logout();
    setCurrentUser(null);
    if (timeoutRef.current) clearTimeout(timeoutRef.current);
  }, []);

  // Session Timeout Logic
  const resetTimer = useCallback(() => {
    if (currentUser) {
      if (timeoutRef.current) clearTimeout(timeoutRef.current);
      timeoutRef.current = setTimeout(() => {
        alert("सुरक्षा कारणों से आपकी सत्र अवधि समाप्त हो गई है। कृपया पुनः लॉगिन करें।\n(Session expired due to inactivity)");
        handleLogout();
      }, SESSION_TIMEOUT);
    }
  }, [currentUser, handleLogout]);

  useEffect(() => {
    // Listen to events to detect activity
    const events = ['click', 'mousemove', 'keypress', 'scroll', 'touchstart'];
    const handleActivity = () => resetTimer();

    if (currentUser) {
      events.forEach(event => window.addEventListener(event, handleActivity));
      resetTimer(); // Start timer initially
    }

    return () => {
      events.forEach(event => window.removeEventListener(event, handleActivity));
      if (timeoutRef.current) clearTimeout(timeoutRef.current);
    };
  }, [currentUser, resetTimer]);

  const checkSession = useCallback(() => {
    const user = api.getCurrentUser();
    if (user) {
      setCurrentUser(user);
    }
    setLoading(false);
  }, []);

  useEffect(() => {
    checkSession();
  }, [checkSession]);

  const handleLogin = (user: LoggedInUser) => {
    setCurrentUser(user);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-screen bg-gray-100">
        <div className="text-2xl font-semibold text-gray-700">Loading...</div>
      </div>
    );
  }

  const renderDashboard = () => {
    if (!currentUser) return null;

    switch (currentUser.role) {
      case UserRole.PRINCIPAL:
        return <PrincipalDashboard user={currentUser} onLogout={handleLogout} />;
      case UserRole.TEACHER:
        return <TeacherDashboard user={currentUser} onLogout={handleLogout} />;
      case UserRole.PARENT:
        return <ParentDashboard user={currentUser} onLogout={handleLogout} />;
      case UserRole.STUDENT:
        return <StudentDashboard user={currentUser} onLogout={handleLogout} />;
      default:
        return <LoginScreen onLogin={handleLogin} />;
    }
  };

  return (
    <div className="min-h-screen bg-slate-100">
      {currentUser ? renderDashboard() : <LoginScreen onLogin={handleLogin} />}
    </div>
  );
};

export default App;
