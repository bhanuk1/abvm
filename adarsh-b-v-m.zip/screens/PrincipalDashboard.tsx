
import React, { useState, useEffect, useCallback } from 'react';
import { Principal, Teacher, Student, Notice, TimetableEntry, Homework, TeacherAttendance, FeeTransaction, Exam, ExamResult, LeaveRequest, Payroll, FeeStructure, ClassSubject, ExamSchedule, StudentLeaveRequest, GalleryItem } from '../types';
import { api, SCHOOL_LOGO_URL, ALL_CLASSES } from '../services/api';
import { LogoutIcon, SchoolIcon, UserIcon, PlusIcon, EditIcon, BellIcon, ReceiptIcon, LockIcon, CameraIcon, RupeeIcon, ClockIcon, BriefcaseIcon, FileTextIcon, SendIcon, SettingsIcon, TrashIcon, PaperClipIcon, SearchIcon, IdCardIcon, PhotoIcon, VideoIcon } from '../components/icons';
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';

interface PrincipalDashboardProps {
  user: Principal;
  onLogout: () => void;
}

const PrincipalDashboard: React.FC<PrincipalDashboardProps> = ({ user, onLogout }) => {
  const [activeTab, setActiveTab] = useState('overview');
  const [stats, setStats] = useState({ students: 0, teachers: 0, collection: 0 });
  const [teachers, setTeachers] = useState<Teacher[]>([]);
  const [students, setStudents] = useState<Student[]>([]);
  const [credentials, setCredentials] = useState<any[]>([]);
  const [homeworks, setHomeworks] = useState<Homework[]>([]);
  
  // Feature States
  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().split('T')[0]);
  const [attendanceSummary, setAttendanceSummary] = useState<{class: string, total: number, present: number, absent: number}[]>([]);
  const [feeTransactions, setFeeTransactions] = useState<(FeeTransaction & { studentName?: string, class?: string })[]>([]);
  const [notices, setNotices] = useState<Notice[]>([]);

  // Modals
  const [noticeModalOpen, setNoticeModalOpen] = useState(false);
  const [newNotice, setNewNotice] = useState({ title: '', content: '', audience: 'public' });
  
  // Student Management
  const [studentModalOpen, setStudentModalOpen] = useState(false);
  const [isEditingStudent, setIsEditingStudent] = useState(false);
  const [editingStudentId, setEditingStudentId] = useState<string | null>(null);
  const [studentPhoto, setStudentPhoto] = useState<string>('');
  const [newStudent, setNewStudent] = useState({ 
      name: '', fatherName: '', motherName: '', mobile: '', class: 'Nursery', gender: 'Male',
      admissionNo: '', dob: '', address: '', religion: 'Hindu', category: 'General', aadharNo: '', bloodGroup: 'B+',
      city: 'Bilgram', pincode: '241301'
  });

  const [teacherModalOpen, setTeacherModalOpen] = useState(false);
  const [newTeacher, setNewTeacher] = useState({ name: '', mobile: '', subject: '', qualification: '', experience: '', baseSalary: 20000, assignedClasses: [] as string[] });

  // Academics
  const [classSubjects, setClassSubjects] = useState<ClassSubject[]>([]);
  const [selectedSubjectClass, setSelectedSubjectClass] = useState('1');
  const [newSubjectName, setNewSubjectName] = useState('');

  // Results
  const [exams, setExams] = useState<Exam[]>([]);
  const [examResults, setExamResults] = useState<(ExamResult & { studentName: string })[]>([]);
  const [resultEntryModalOpen, setResultEntryModalOpen] = useState(false);
  const [selectedExamEntry, setSelectedExamEntry] = useState('');
  const [selectedClassEntry, setSelectedClassEntry] = useState('1');
  const [selectedSubjectEntry, setSelectedSubjectEntry] = useState('');
  const [availableSubjects, setAvailableSubjects] = useState<ExamSchedule[]>([]);
  const [studentMarksEntry, setStudentMarksEntry] = useState<Record<string, number>>({});
  const [allSubjectsMarksEntry, setAllSubjectsMarksEntry] = useState<Record<string, Record<string, number>>>({});

  // HR
  const [leaves, setLeaves] = useState<LeaveRequest[]>([]);
  const [payrolls, setPayrolls] = useState<Payroll[]>([]);
  const [payrollMonth, setPayrollMonth] = useState(new Date().toISOString().slice(0, 7));
  
  // Student Leaves
  const [studentLeaves, setStudentLeaves] = useState<StudentLeaveRequest[]>([]);

  // Timetable
  const [timetable, setTimetable] = useState<TimetableEntry[]>([]);
  const [selectedClassForTimetable, setSelectedClassForTimetable] = useState('1');
  const [timetableModalOpen, setTimetableModalOpen] = useState(false);
  const [timetableEntry, setTimetableEntry] = useState<{day: string, period: number, subject: string, teacherId: string, startTime: string, endTime: string}>({
      day: 'Monday', period: 1, subject: '', teacherId: '', startTime: '08:00', endTime: '09:00'
  });

  // Fee Collection (Admin)
  const [collectFeeModalOpen, setCollectFeeModalOpen] = useState(false);
  const [feeCollectionData, setFeeCollectionData] = useState({ class: '1', studentId: '', type: 'Tuition', amount: 0, method: 'Cash' });

  // Gallery
  const [galleryItems, setGalleryItems] = useState<GalleryItem[]>([]);
  const [galleryModalOpen, setGalleryModalOpen] = useState(false);
  const [newGalleryItem, setNewGalleryItem] = useState<{type: 'photo'|'video', title: string, url: string, description: string}>({
      type: 'photo', title: '', url: '', description: ''
  });
  const [galleryUploadType, setGalleryUploadType] = useState<'file' | 'url'>('file');

  // Settings
  const [lastSaveTime, setLastSaveTime] = useState('');

  const fetchData = useCallback(async () => {
    const allTeachers = await api.getAllTeachers();
    const allStudents = await api.getAllStudents();
    const finance = await api.getFinancialStats();
    const allNotices = await api.getAllNotices();
    
    setTeachers(allTeachers);
    setStudents(allStudents);
    setStats({
        students: allStudents.length,
        teachers: allTeachers.length,
        collection: finance.totalCollected
    });
    setNotices(allNotices);
    
    // Background fetch for credentials
    api.getAllUserCredentials().then(setCredentials);
  }, []);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  // Auto-refresh stats
  useEffect(() => {
      setLastSaveTime(api.getLastSaveTime());
      const interval = setInterval(() => setLastSaveTime(api.getLastSaveTime()), 10000);
      return () => clearInterval(interval);
  }, []);

  // Tab Data Loading
  useEffect(() => {
      const loadTabSpecificData = async () => {
          if (activeTab === 'timetable') {
             api.getTimetableForClass(selectedClassForTimetable).then(setTimetable);
          } else if (activeTab === 'attendance') {
              const summary = [];
              for (const cls of ALL_CLASSES) {
                  const classStudents = students.filter(s => s.class === cls);
                  if (classStudents.length === 0) continue;
                  const att = await api.getAttendanceForClass(cls, selectedDate);
                  const present = att.filter(a => a.status === 'Present').length;
                  summary.push({ class: cls, total: classStudents.length, present, absent: classStudents.length - present });
              }
              setAttendanceSummary(summary);
          } else if (activeTab === 'fees') {
              const txs = await api.getAllFeeTransactions();
              const enrichedTxs = txs.map(t => {
                  const s = students.find(stu => stu.id === t.studentId);
                  return { ...t, studentName: s?.name || 'Unknown', class: s?.class || '-' };
              }).sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
              setFeeTransactions(enrichedTxs);
          } else if (activeTab === 'hr') {
              const allLeaves = await api.getAllLeaves();
              const enrichedLeaves = allLeaves.map(l => {
                  const teacher = teachers.find(t => t.id === l.employeeId);
                  return { ...l, employeeName: teacher?.name || 'Unknown' };
              });
              setLeaves(enrichedLeaves as any);
              
              const monthPayrolls = await api.getPayrolls(payrollMonth);
              const enrichedPayrolls = monthPayrolls.map(p => {
                  const teacher = teachers.find(tr => tr.id === p.employeeId);
                  return { ...p, employeeName: teacher?.name || 'Unknown' };
              });
              setPayrolls(enrichedPayrolls as any);
          } else if (activeTab === 'student_leaves') {
              const leaves = await api.getAllStudentLeaves();
              setStudentLeaves(leaves);
          } else if (activeTab === 'academics') {
              setClassSubjects(await api.getAllClassSubjects());
          } else if (activeTab === 'results') {
              setExams(await api.getAllExams());
          } else if (activeTab === 'homework') {
              const hw = await api.getAllHomeworks();
              setHomeworks(hw.sort((a,b) => new Date(b.date).getTime() - new Date(a.date).getTime()));
          } else if (activeTab === 'gallery') {
              setGalleryItems(await api.getGalleryItems());
          }
      };
      
      if (activeTab !== 'overview') {
          loadTabSpecificData();
      }
  }, [activeTab, selectedClassForTimetable, selectedDate, students, payrollMonth, teachers]);

  // --- Handlers ---
  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
      const file = e.target.files?.[0];
      if (file) {
          const reader = new FileReader();
          reader.onloadend = () => {
              setStudentPhoto(reader.result as string);
          };
          reader.readAsDataURL(file);
      }
  };
  
  const handleGalleryUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
      const file = e.target.files?.[0];
      if (file) {
          if (file.size > 5 * 1024 * 1024) {
              alert("File is too large. Please upload files smaller than 5MB.");
              return;
          }
          const reader = new FileReader();
          reader.onloadend = () => {
              setNewGalleryItem({ ...newGalleryItem, url: reader.result as string });
          };
          reader.readAsDataURL(file);
      }
  };

  const handleAddGalleryItem = async (e: React.FormEvent) => {
      e.preventDefault();
      if (newGalleryItem.title && newGalleryItem.url) {
          await api.addGalleryItem(newGalleryItem);
          setGalleryItems(await api.getGalleryItems());
          setGalleryModalOpen(false);
          setNewGalleryItem({type: 'photo', title: '', url: '', description: ''});
          setGalleryUploadType('file');
      }
  };

  const handleDeleteGalleryItem = async (id: string) => {
      if (window.confirm('Delete this item from gallery?')) {
          await api.deleteGalleryItem(id);
          setGalleryItems(await api.getGalleryItems());
      }
  };

  const handleAddStudent = async (e: React.FormEvent) => {
    e.preventDefault();
    if (newStudent.name && newStudent.mobile) {
        const studentData = {
            ...newStudent,
            profilePicture: studentPhoto
        };

        if (isEditingStudent && editingStudentId) {
            // Update Existing
            const existing = students.find(s => s.id === editingStudentId);
            if(existing) {
                const updated: Student = { 
                    ...existing, 
                    ...studentData as any
                };
                await api.updateStudent(updated);
                alert("Student updated successfully!");
            }
        } else {
            // Add New
            const result = await api.addStudent(studentData as any, newStudent.mobile);
            
            // Show Credentials Popup
            alert(
              `✅ Admission Successful!\n\n` +
              `----------------------------------\n` +
              `STUDENT Login:\n` +
              `Mobile: ${newStudent.mobile}\n` +
              `Password: ${result.studentPass}\n` +
              `----------------------------------\n` +
              `PARENT Login:\n` +
              `Mobile: ${newStudent.mobile}\n` +
              `Password: ${result.parentPass}\n\n` +
              `Please share these credentials with the parent. They can login using the same mobile number by selecting their respective Role.`
            );
        }
        setStudentModalOpen(false);
        setIsEditingStudent(false);
        setEditingStudentId(null);
        setStudentPhoto('');
        setNewStudent({ 
             name: '', fatherName: '', motherName: '', mobile: '', class: 'Nursery', gender: 'Male',
             admissionNo: '', dob: '', address: '', religion: 'Hindu', category: 'General', aadharNo: '', bloodGroup: 'B+',
             city: 'Bilgram', pincode: '241301'
        });
        fetchData();
    }
  };

  const openEditStudentModal = (s: Student) => {
      setNewStudent({
          name: s.name,
          fatherName: s.fatherName,
          motherName: s.motherName,
          mobile: s.mobile,
          class: s.class,
          gender: s.gender,
          admissionNo: s.admissionNo || '',
          dob: s.dob || '',
          address: s.address || '',
          religion: s.religion || 'Hindu',
          category: s.category || 'General',
          aadharNo: s.aadharNo || '',
          bloodGroup: s.bloodGroup || '',
          city: s.city || 'Bilgram',
          pincode: s.pincode || '241301'
      });
      setStudentPhoto(s.profilePicture || '');
      setEditingStudentId(s.id);
      setIsEditingStudent(true);
      setStudentModalOpen(true);
  };

  const handleAddTeacher = async (e: React.FormEvent) => {
      e.preventDefault();
      if(newTeacher.name && newTeacher.mobile) {
          const pwd = await api.addTeacher({
              name: newTeacher.name,
              mobile: newTeacher.mobile,
              assignedClasses: newTeacher.assignedClasses,
              subject: newTeacher.subject,
              qualification: newTeacher.qualification,
              experience: newTeacher.experience,
              performanceRating: 5,
              baseSalary: Number(newTeacher.baseSalary)
          });
          setTeacherModalOpen(false);
          fetchData();
          alert(`Teacher added! Password: ${pwd}`);
      }
  };

  const handleAddNotice = async (e: React.FormEvent) => {
    e.preventDefault();
    if (newNotice.title && newNotice.content) {
        await api.createNotice(newNotice.title, newNotice.content, newNotice.audience as any);
        setNoticeModalOpen(false);
        setNewNotice({ title: '', content: '', audience: 'public' });
        fetchData();
    }
  };

  const handleDeleteNotice = async (id: string) => {
      if(window.confirm('Delete this notice?')) {
          await api.deleteNotice(id);
          fetchData();
      }
  };

  const handleAddSubject = async () => {
      if(newSubjectName && selectedSubjectClass) {
          await api.addClassSubject(selectedSubjectClass, newSubjectName);
          setNewSubjectName('');
          setClassSubjects(await api.getAllClassSubjects());
      }
  };

  const handleLeaveAction = async (id: string, status: 'Approved' | 'Rejected') => {
      await api.updateLeaveStatus(id, status);
      // refresh leaves
      const allLeaves = await api.getAllLeaves();
      const enrichedLeaves = allLeaves.map(l => {
          const teacher = teachers.find(t => t.id === l.employeeId);
          return { ...l, employeeName: teacher?.name || 'Unknown' };
      });
      setLeaves(enrichedLeaves as any);
  };
  
  const handleStudentLeaveAction = async (id: string, status: 'Approved' | 'Rejected') => {
      await api.updateStudentLeaveStatus(id, status);
      setStudentLeaves(await api.getAllStudentLeaves());
  };

  const handleGeneratePayroll = async (teacher: Teacher) => {
      if(confirm(`Generate payroll for ${teacher.name} for ${payrollMonth}?`)) {
          const baseSalary = teacher.baseSalary || 20000;
          const netSalary = baseSalary + 2000 - 500;
          
          const payrollEntry: Payroll = {
              id: '', // uid generated in api
              employeeId: teacher.id,
              employeeName: teacher.name,
              month: payrollMonth,
              basicSalary: baseSalary,
              allowances: 2000,
              deductions: 500,
              netSalary: netSalary,
              status: 'Paid'
          };

          await api.createPayroll(payrollEntry);
          // refresh
          const monthPayrolls = await api.getPayrolls(payrollMonth);
          const enrichedPayrolls = monthPayrolls.map(p => {
              const teacher = teachers.find(tr => tr.id === p.employeeId);
              return { ...p, employeeName: teacher?.name || 'Unknown' };
          });
          setPayrolls(enrichedPayrolls as any);
      }
  };
  
  // Timetable Edit
  const openTimetableModal = () => {
      setTimetableEntry({ day: 'Monday', period: 1, subject: '', teacherId: '', startTime: '08:00', endTime: '09:00' });
      setTimetableModalOpen(true);
  };
  const handleSaveTimetableEntry = async (e: React.FormEvent) => {
      e.preventDefault();
      await api.saveTimetableEntry({
          class: selectedClassForTimetable,
          ...timetableEntry
      });
      setTimetableModalOpen(false);
      setTimetable(await api.getTimetableForClass(selectedClassForTimetable));
      alert("Timetable updated!");
  };

  // Fee Collection
  const handleCollectFee = async (e: React.FormEvent) => {
      e.preventDefault();
      if (feeCollectionData.studentId && feeCollectionData.amount > 0) {
          await api.payFee(feeCollectionData.studentId, feeCollectionData.amount, feeCollectionData.type as any, feeCollectionData.method as any);
          setCollectFeeModalOpen(false);
          setActiveTab('fees'); // Refresh view
          alert("Fee collected successfully!");
          // Refresh transaction list
          const txs = await api.getAllFeeTransactions();
          const enrichedTxs = txs.map(t => {
               const s = students.find(stu => stu.id === t.studentId);
               return { ...t, studentName: s?.name || 'Unknown', class: s?.class || '-' };
          }).sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
          setFeeTransactions(enrichedTxs);
      }
  };

  // Result Entry
  const openResultEntryModal = async () => {
      setResultEntryModalOpen(true);
      if(selectedExamEntry && selectedClassEntry) {
          const subs = await api.getExamSchedules(selectedExamEntry, selectedClassEntry);
          setAvailableSubjects(subs);
      }
  };

  useEffect(() => {
      if (resultEntryModalOpen && selectedExamEntry && selectedClassEntry) {
          api.getExamSchedules(selectedExamEntry, selectedClassEntry).then(subs => {
             // Add "All Subjects" option to the list for bulk entry
             if (subs.length > 0) {
                 setAvailableSubjects([...subs, { subject: 'All Subjects', maxMarks: 0 } as any]);
             } else {
                 setAvailableSubjects([]);
             }
          });
      }
  }, [selectedExamEntry, selectedClassEntry, resultEntryModalOpen]);

  useEffect(() => {
      if(resultEntryModalOpen && selectedExamEntry && selectedClassEntry && selectedSubjectEntry) {
          if (selectedSubjectEntry === 'All Subjects') {
               // Fetch ALL results for the whole class
               api.getResultsForExamAndClass(selectedExamEntry, selectedClassEntry).then(results => {
                   const map: Record<string, Record<string, number>> = {};
                   results.forEach(r => {
                       if (!map[r.studentId]) map[r.studentId] = {};
                       map[r.studentId][r.subject] = r.marksObtained;
                   });
                   setAllSubjectsMarksEntry(map);
               });
          } else {
              // Load existing marks for single subject
              api.getExamResultsForClass(selectedExamEntry, selectedClassEntry, selectedSubjectEntry).then(results => {
                   const marks: Record<string, number> = {};
                   results.forEach(r => marks[r.studentId] = r.marksObtained);
                   setStudentMarksEntry(marks);
              });
          }
      }
  }, [selectedExamEntry, selectedClassEntry, selectedSubjectEntry, resultEntryModalOpen]);

  const handleSaveResults = async () => {
      if (selectedSubjectEntry === 'All Subjects') {
          const subjects = availableSubjects.filter(s => s.subject !== 'All Subjects');
          for (const student of students.filter(s => s.class === selectedClassEntry)) {
              for (const sub of subjects) {
                  const marks = allSubjectsMarksEntry[student.id]?.[sub.subject];
                  if (marks !== undefined) {
                      await api.saveExamResult(selectedExamEntry, student.id, sub.subject, Number(marks), sub.maxMarks);
                  }
              }
          }
          alert("Bulk marks saved successfully!");
      } else {
          const schedule = availableSubjects.find(s => s.subject === selectedSubjectEntry);
          if (!schedule) return;

          for (const [stuId, marks] of Object.entries(studentMarksEntry)) {
              await api.saveExamResult(selectedExamEntry, stuId, selectedSubjectEntry, marks, schedule.maxMarks);
          }
          alert("Marks saved successfully!");
      }
      setResultEntryModalOpen(false);
  };

  // Marksheet Generation
  const generateStudentMarksheet = async (student: Student) => {
       const consolidatedMarks = await api.getConsolidatedMarks(student.id);
       const doc: any = new jsPDF();
       const pageWidth = doc.internal.pageSize.width;
       
       // Header
       try {
           const img = new Image();
           img.src = SCHOOL_LOGO_URL;
           doc.addImage(img, 'PNG', 15, 10, 20, 20);
       } catch(e) {}

       doc.setFontSize(20);
       doc.setTextColor(63, 81, 181);
       doc.text("ADARSH BAL VIDYA MANDIR", pageWidth / 2, 20, { align: "center" } as any);
       doc.setFontSize(10);
       doc.setTextColor(0);
       doc.text("Bilgram - Hardoi | Annual Report Card 2024-25", pageWidth / 2, 28, { align: "center" } as any);

       // Details
       doc.rect(15, 35, pageWidth - 30, 25);
       doc.text(`Name: ${student.name}`, 20, 45);
       doc.text(`Father: ${student.fatherName}`, 20, 52);
       doc.text(`Class: ${student.class}`, 120, 45);
       doc.text(`Roll No: ${student.id.substring(0,6).toUpperCase()}`, 120, 52);

       // Table
       const tableData = consolidatedMarks.map(row => [
           String(row.subject),
           String(row.quarterly.obtained),
           String(row.halfYearly.obtained),
           String(row.annual.obtained),
           String(row.total.obtained),
           String(row.total.max),
           String(row.grade)
       ]);

       autoTable(doc, {
           startY: 70,
           head: [['Subject', 'Quarterly', 'Half Yearly', 'Annual', 'Total Obt', 'Max', 'Grade']],
           body: tableData,
           theme: 'grid',
           headStyles: { fillColor: [63, 81, 181] }
       });

       doc.save(`${student.name}_Marksheet.pdf`);
  };

  const generateIDCard = (student: Student) => {
      const doc: any = new jsPDF('p', 'mm', [54, 86]); // Credit card size portrait (approx)
      const width = 54;
      const height = 86;

      // Background
      doc.setFillColor(245, 247, 250);
      doc.rect(0, 0, width, height, 'F');

      // Header
      doc.setFillColor(63, 81, 181); // Indigo
      doc.rect(0, 0, width, 16, 'F');
      doc.setTextColor(255, 255, 255);
      doc.setFontSize(8);
      doc.setFont("helvetica", "bold");
      doc.text("ADARSH BAL VIDYA MANDIR", width / 2, 6, { align: "center" } as any);
      doc.setFontSize(5);
      doc.setFont("helvetica", "normal");
      doc.text("Bilgram - Hardoi, Uttar Pradesh", width / 2, 10, { align: "center" } as any);
      doc.text("Session 2024-25", width / 2, 13, { align: "center" } as any);

      // Photo
      const photoY = 20;
      const photoSize = 20;
      if (student.profilePicture) {
          doc.addImage(student.profilePicture, 'JPEG', (width - photoSize) / 2, photoY, photoSize, photoSize);
      } else {
          doc.setDrawColor(200);
          doc.setFillColor(255);
          doc.rect((width - photoSize) / 2, photoY, photoSize, photoSize, 'FD');
          doc.setFontSize(6);
          doc.setTextColor(150, 150, 150);
          doc.text("No Photo", width / 2, photoY + 10, { align: "center" } as any);
      }

      // Details
      const startY = photoY + photoSize + 5;
      doc.setTextColor(0, 0, 0);
      doc.setFontSize(10);
      doc.setFont("helvetica", "bold");
      doc.text(String(student.name).toUpperCase(), width / 2, startY, { align: "center" } as any);
      
      doc.setFontSize(7);
      doc.setFont("helvetica", "normal");
      doc.text(String(student.class), width / 2, startY + 4, { align: "center" } as any);

      const detailsY = startY + 10;
      const labelX = 4;
      const valX = 20;
      const lineHeight = 3.5;

      doc.setFontSize(6);
      
      doc.setFont("helvetica", "bold"); doc.text("Father:", labelX, detailsY);
      doc.setFont("helvetica", "normal"); doc.text(String(student.fatherName), valX, detailsY);
      
      doc.setFont("helvetica", "bold"); doc.text("DOB:", labelX, detailsY + lineHeight);
      doc.setFont("helvetica", "normal"); doc.text(String(student.dob || '-'), valX, detailsY + lineHeight);

      doc.setFont("helvetica", "bold"); doc.text("Mobile:", labelX, detailsY + lineHeight * 2);
      doc.setFont("helvetica", "normal"); doc.text(String(student.mobile), valX, detailsY + lineHeight * 2);

      doc.setFont("helvetica", "bold"); doc.text("Address:", labelX, detailsY + lineHeight * 3);
      doc.setFont("helvetica", "normal"); doc.text(String(student.city || 'Bilgram'), valX, detailsY + lineHeight * 3);

      // Footer / Signature
      doc.setFontSize(5);
      doc.text("Principal Signature", width - 5, height - 5, { align: "right" } as any);

      doc.save(`${student.name}_IDCard.pdf`);
  };
  
  const handleRestore = (e: React.ChangeEvent<HTMLInputElement>) => {
      const file = e.target.files?.[0];
      if(file) {
          api.restoreBackup(file).catch(err => alert('Restore Failed: ' + err.message));
      }
  };

  const renderContent = () => {
    switch(activeTab) {
      case 'overview':
        return (
          <div className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="bg-gradient-to-r from-blue-500 to-blue-600 text-white p-6 rounded-xl shadow-lg">
                    <h3 className="text-lg font-semibold opacity-80">Total Students</h3>
                    <p className="text-4xl font-bold mt-2">{stats.students}</p>
                </div>
                <div className="bg-gradient-to-r from-purple-500 to-purple-600 text-white p-6 rounded-xl shadow-lg">
                    <h3 className="text-lg font-semibold opacity-80">Total Teachers</h3>
                    <p className="text-4xl font-bold mt-2">{stats.teachers}</p>
                </div>
                <div className="bg-gradient-to-r from-green-500 to-green-600 text-white p-6 rounded-xl shadow-lg">
                    <h3 className="text-lg font-semibold opacity-80">Fee Collection</h3>
                    <p className="text-4xl font-bold mt-2 flex items-center"><RupeeIcon className="w-8 h-8 mr-2"/> {stats.collection.toLocaleString('en-IN')}</p>
                </div>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="bg-white p-6 rounded-lg shadow">
                      <h3 className="font-bold text-gray-700 mb-4">Quick Actions</h3>
                      <div className="grid grid-cols-2 gap-4">
                          <button onClick={() => { setStudentModalOpen(true); setIsEditingStudent(false); setStudentPhoto(''); }} className="p-4 border rounded-lg hover:bg-blue-50 flex flex-col items-center justify-center text-blue-600">
                              <PlusIcon className="w-6 h-6 mb-2" /> Add Student
                          </button>
                          <button onClick={() => setCollectFeeModalOpen(true)} className="p-4 border rounded-lg hover:bg-green-50 flex flex-col items-center justify-center text-green-600">
                              <RupeeIcon className="w-6 h-6 mb-2" /> Collect Fees
                          </button>
                          <button onClick={() => { setResultEntryModalOpen(true); }} className="p-4 border rounded-lg hover:bg-pink-50 flex flex-col items-center justify-center text-pink-600">
                              <FileTextIcon className="w-6 h-6 mb-2" /> Exam Marks
                          </button>
                          <button onClick={() => setNoticeModalOpen(true)} className="p-4 border rounded-lg hover:bg-yellow-50 flex flex-col items-center justify-center text-yellow-600">
                              <BellIcon className="w-6 h-6 mb-2" /> Post Notice
                          </button>
                      </div>
                  </div>
                  <div className="bg-white p-6 rounded-lg shadow">
                       <h3 className="font-bold text-gray-700 mb-4">Recent Notices</h3>
                       <div className="space-y-2">
                           {notices.slice(0, 3).map(n => (
                               <div key={n.id} className="border-l-2 border-indigo-500 pl-3 py-1">
                                   <p className="font-semibold text-sm">{n.title}</p>
                                   <p className="text-xs text-gray-500">{new Date(n.date).toLocaleDateString()}</p>
                               </div>
                           ))}
                       </div>
                  </div>
              </div>
          </div>
        );
      case 'gallery':
          return (
              <div className="bg-white rounded-lg shadow p-6">
                  <div className="flex justify-between items-center mb-6">
                      <h3 className="text-lg font-bold">School Gallery & Media</h3>
                      <button onClick={() => setGalleryModalOpen(true)} className="bg-pink-600 text-white px-4 py-2 rounded flex items-center hover:bg-pink-700 shadow">
                          <PlusIcon className="w-5 h-5 mr-2"/> Add Media
                      </button>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                      {galleryItems.length === 0 && <p className="text-gray-400 col-span-3 text-center py-10">No media uploaded yet.</p>}
                      {galleryItems.map(item => (
                          <div key={item.id} className="border rounded-lg overflow-hidden shadow-sm hover:shadow-md transition bg-gray-50">
                              <div className="h-48 bg-gray-200 relative">
                                  {item.type === 'photo' ? (
                                      <img src={item.url} alt={item.title} className="w-full h-full object-cover" />
                                  ) : (
                                      item.url.includes('youtube.com') || item.url.includes('youtu.be') ? (
                                          <div className="w-full h-full flex items-center justify-center bg-black">
                                              <iframe 
                                                  width="100%" 
                                                  height="100%" 
                                                  src={item.url.replace("watch?v=", "embed/").replace("youtu.be/", "youtube.com/embed/")} 
                                                  title={item.title}
                                                  frameBorder="0" 
                                                  allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" 
                                                  allowFullScreen
                                              ></iframe>
                                          </div>
                                      ) : (
                                          // Fallback for other video URLs (e.g., MP4 links or base64 if small)
                                          <video src={item.url} controls className="w-full h-full object-cover bg-black" />
                                      )
                                  )}
                                  <div className="absolute top-2 right-2">
                                      <button onClick={() => handleDeleteGalleryItem(item.id)} className="bg-red-600 text-white p-1.5 rounded-full shadow hover:bg-red-700">
                                          <TrashIcon className="w-4 h-4" />
                                      </button>
                                  </div>
                                  <div className="absolute top-2 left-2">
                                      <span className={`px-2 py-1 rounded text-xs font-bold ${item.type==='photo'?'bg-blue-500 text-white':'bg-red-500 text-white'}`}>
                                          {item.type.toUpperCase()}
                                      </span>
                                  </div>
                              </div>
                              <div className="p-4">
                                  <h4 className="font-bold text-gray-800 truncate" title={item.title}>{item.title}</h4>
                                  <p className="text-sm text-gray-500 mt-1 truncate">{item.description}</p>
                                  <p className="text-xs text-gray-400 mt-2">{new Date(item.date).toLocaleDateString()}</p>
                              </div>
                          </div>
                      ))}
                  </div>
              </div>
          );
      case 'students':
        return (
          <div className="bg-white rounded-lg shadow overflow-hidden">
            <div className="p-4 border-b flex justify-between items-center bg-gray-50">
              <h3 className="text-lg font-bold text-gray-700">Student Directory</h3>
              <button onClick={() => { setStudentModalOpen(true); setIsEditingStudent(false); setStudentPhoto(''); }} className="bg-indigo-600 text-white px-4 py-2 rounded flex items-center hover:bg-indigo-700"><PlusIcon className="w-5 h-5 mr-2" /> New Admission</button>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-left">
                <thead className="bg-gray-100 text-gray-600 font-semibold text-sm"><tr><th className="p-4">Photo</th><th className="p-4">Admn No</th><th className="p-4">Name</th><th className="p-4">Class</th><th className="p-4">Father</th><th className="p-4">Mobile</th><th className="p-4 text-right">Action</th></tr></thead>
                <tbody className="divide-y divide-gray-200">
                  {students.map((s, idx) => (
                    <tr key={s.id} className="hover:bg-gray-50">
                      <td className="p-4">
                          <div className="w-10 h-10 rounded-full bg-gray-200 overflow-hidden">
                              {s.profilePicture ? <img src={s.profilePicture} alt="" className="w-full h-full object-cover" /> : <UserIcon className="w-full h-full p-2 text-gray-400" />}
                          </div>
                      </td>
                      <td className="p-4 text-gray-500 text-sm">{s.admissionNo || s.id.substring(0,6)}</td>
                      <td className="p-4 font-medium">{s.name}</td>
                      <td className="p-4"><span className="bg-gray-100 px-2 py-1 rounded text-xs">{s.class}</span></td>
                      <td className="p-4 text-gray-600">{s.fatherName}</td>
                      <td className="p-4 text-gray-600">{s.mobile}</td>
                      <td className="p-4 text-right flex justify-end space-x-2">
                          <button onClick={() => openEditStudentModal(s)} className="text-blue-600 hover:bg-blue-50 p-2 rounded" title="Edit Student"><EditIcon className="w-4 h-4"/></button>
                          <button onClick={() => generateIDCard(s)} className="text-purple-600 hover:bg-purple-50 p-2 rounded" title="Generate ID Card"><IdCardIcon className="w-4 h-4"/></button>
                          <button onClick={() => generateStudentMarksheet(s)} className="text-green-600 hover:bg-green-50 p-2 rounded" title="Download Marksheet"><ReceiptIcon className="w-4 h-4"/></button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        );
      case 'student_leaves':
          return (
              <div className="bg-white rounded-lg shadow p-6">
                  <h3 className="text-lg font-bold mb-4 text-orange-600">Student Leave Requests</h3>
                  {studentLeaves.length === 0 && <p className="text-gray-400">No leave requests found.</p>}
                  <div className="space-y-4">
                      {studentLeaves.sort((a,b) => new Date(b.requestDate).getTime() - new Date(a.requestDate).getTime()).map(leave => (
                          <div key={leave.id} className="border p-4 rounded flex justify-between items-center bg-orange-50">
                              <div>
                                  <div className="flex items-center gap-2">
                                      <p className="font-bold text-indigo-900">{leave.studentName}</p>
                                      <span className="text-xs bg-white px-2 py-1 rounded border">Class {leave.class}</span>
                                  </div>
                                  <p className="text-sm text-gray-600 mt-1">
                                      {new Date(leave.startDate).toLocaleDateString()} to {new Date(leave.endDate).toLocaleDateString()}
                                  </p>
                                  <p className="text-sm text-gray-500 italic mt-1">Reason: "{leave.reason}"</p>
                                  <p className="text-xs text-gray-400 mt-1">Requested: {new Date(leave.requestDate).toLocaleDateString()}</p>
                              </div>
                              <div className="flex flex-col items-end gap-2">
                                  {leave.status === 'Pending' ? (
                                      <div className="flex gap-2">
                                          <button onClick={()=>handleStudentLeaveAction(leave.id, 'Approved')} className="bg-green-600 text-white px-3 py-1 rounded text-sm hover:bg-green-700">Approve</button>
                                          <button onClick={()=>handleStudentLeaveAction(leave.id, 'Rejected')} className="bg-red-600 text-white px-3 py-1 rounded text-sm hover:bg-red-700">Reject</button>
                                      </div>
                                  ) : (
                                      <span className={`px-3 py-1 rounded text-sm font-bold ${leave.status === 'Approved' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`}>
                                          {leave.status}
                                      </span>
                                  )}
                              </div>
                          </div>
                      ))}
                  </div>
              </div>
          );
      case 'teachers':
          return (
              <div className="bg-white rounded-lg shadow overflow-hidden">
                  <div className="p-4 border-b flex justify-between items-center bg-gray-50">
                      <h3 className="text-lg font-bold text-gray-700">Teacher Staff</h3>
                      <button onClick={() => setTeacherModalOpen(true)} className="bg-purple-600 text-white px-4 py-2 rounded flex items-center hover:bg-purple-700"><PlusIcon className="w-5 h-5 mr-2" /> Add Teacher</button>
                  </div>
                  <div className="overflow-x-auto">
                      <table className="w-full text-left">
                          <thead className="bg-gray-100 text-gray-600 font-semibold text-sm"><tr><th className="p-4">Name</th><th className="p-4">Subject</th><th className="p-4">Mobile</th><th className="p-4">Classes</th><th className="p-4">Salary</th></tr></thead>
                          <tbody className="divide-y divide-gray-200">
                              {teachers.map(t => (
                                  <tr key={t.id} className="hover:bg-gray-50">
                                      <td className="p-4 font-medium">{t.name}</td>
                                      <td className="p-4">{t.subject || '-'}</td>
                                      <td className="p-4">{t.mobile}</td>
                                      <td className="p-4 text-xs">{t.assignedClasses.join(', ')}</td>
                                      <td className="p-4">₹{t.baseSalary?.toLocaleString()}</td>
                                  </tr>
                              ))}
                          </tbody>
                      </table>
                  </div>
              </div>
          );
      case 'academics':
          return (
              <div className="space-y-6">
                  <div className="bg-white rounded-lg shadow p-6">
                      <h3 className="text-lg font-bold mb-6">Subject Management</h3>
                      <div className="flex gap-4 items-end border-b pb-6">
                          <div>
                              <label className="block text-sm font-bold mb-1">Select Class</label>
                              <select value={selectedSubjectClass} onChange={e=>setSelectedSubjectClass(e.target.value)} className="border p-2 rounded w-32 bg-gray-50">
                                  {ALL_CLASSES.map(c=><option key={c} value={c}>{c}</option>)}
                              </select>
                          </div>
                          <div className="flex-1">
                              <label className="block text-sm font-bold mb-1">New Subject Name</label>
                              <input type="text" value={newSubjectName} onChange={e=>setNewSubjectName(e.target.value)} className="border p-2 rounded w-full" placeholder="e.g. Computer Science, Mathematics"/>
                          </div>
                          <button onClick={handleAddSubject} className="bg-green-600 text-white px-6 py-2 rounded h-10 hover:bg-green-700 shadow">Add Subject</button>
                      </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
                      {ALL_CLASSES.map(cls => {
                          const clsSubjects = classSubjects.filter(cs => cs.class === cls);
                          const clsStudents = students.filter(s => s.class === cls).length;
                          const clsTeacher = teachers.find(t => t.assignedClasses.includes(cls));

                          return (
                              <div key={cls} className="bg-white rounded-lg shadow overflow-hidden border border-gray-100">
                                  <div className="bg-indigo-600 text-white p-3 flex justify-between items-center">
                                      <h4 className="font-bold text-lg">Class {cls}</h4>
                                      <span className="text-xs bg-indigo-500 px-2 py-1 rounded shadow-sm border border-indigo-400">{clsStudents} Students</span>
                                  </div>
                                  <div className="p-4">
                                      <div className="mb-4 text-sm flex justify-between items-center bg-gray-50 p-2 rounded">
                                          <span className="text-gray-500">Class Teacher:</span>
                                          <div className="font-medium text-gray-800">{clsTeacher ? clsTeacher.name : <span className="text-red-400 text-xs italic">Not Assigned</span>}</div>
                                      </div>
                                      
                                      <div>
                                          <span className="text-xs font-bold text-gray-400 uppercase tracking-wider">Subjects ({clsSubjects.length})</span>
                                          <div className="flex flex-wrap gap-2 mt-2 min-h-[40px]">
                                              {clsSubjects.map(cs => (
                                                  <span key={cs.id} className="bg-blue-50 text-blue-700 px-2 py-1 rounded text-xs flex items-center border border-blue-100">
                                                      {cs.subjectName}
                                                      <button 
                                                          onClick={async()=>{ 
                                                              if(confirm(`Remove ${cs.subjectName} from Class ${cls}?`)) {
                                                                  await api.removeClassSubject(cs.id); 
                                                                  setClassSubjects(await api.getAllClassSubjects()); 
                                                              }
                                                          }} 
                                                          className="ml-2 text-blue-300 hover:text-red-500 font-bold focus:outline-none"
                                                          title="Remove Subject"
                                                      >
                                                          &times;
                                                      </button>
                                                  </span>
                                              ))}
                                              {clsSubjects.length === 0 && <span className="text-gray-400 text-xs italic py-1">No subjects added yet. Use form above.</span>}
                                          </div>
                                      </div>
                                  </div>
                              </div>
                          );
                      })}
                  </div>
              </div>
          );
      case 'timetable':
          return (
              <div className="bg-white rounded-lg shadow p-6">
                  <div className="flex justify-between items-center mb-6">
                      <h3 className="text-lg font-bold">Class Timetable</h3>
                      <div className="flex space-x-2">
                          <select value={selectedClassForTimetable} onChange={e=>setSelectedClassForTimetable(e.target.value)} className="border p-2 rounded w-32">{ALL_CLASSES.map(c=><option key={c} value={c}>{c}</option>)}</select>
                          <button onClick={openTimetableModal} className="bg-indigo-600 text-white px-3 py-2 rounded text-sm flex items-center"><EditIcon className="w-4 h-4 mr-1" /> Edit</button>
                      </div>
                  </div>
                  <div className="overflow-x-auto">
                      <table className="w-full border-collapse border">
                          <thead className="bg-gray-100">
                              <tr><th className="border p-2">Day</th>{[1,2,3,4,5,6,7,8].map(p=><th key={p} className="border p-2 text-center">{p}</th>)}</tr>
                          </thead>
                          <tbody>
                              {['Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'].map(day => (
                                  <tr key={day}>
                                      <td className="border p-2 font-bold bg-gray-50">{day}</td>
                                      {[1,2,3,4,5,6,7,8].map(period => {
                                          const entry = timetable.find(t => t.day === day && t.period === period);
                                          return (
                                              <td key={period} className="border p-2 text-center text-sm min-h-[50px]">
                                                  {entry ? (
                                                      <div className="bg-blue-50 p-1 rounded border border-blue-100">
                                                          <div className="font-bold text-blue-800">{entry.subject}</div>
                                                          {entry.teacherId && <div className="text-xs text-gray-500 truncate">{teachers.find(t=>t.id===entry.teacherId)?.name}</div>}
                                                      </div>
                                                  ) : <span className="text-gray-300">-</span>}
                                              </td>
                                          )
                                      })}
                                  </tr>
                              ))}
                          </tbody>
                      </table>
                  </div>
              </div>
          );
      case 'attendance':
          return (
              <div className="bg-white rounded-lg shadow p-6">
                  <div className="flex justify-between items-center mb-6">
                      <h3 className="text-lg font-bold">Daily Attendance Summary</h3>
                      <input type="date" value={selectedDate} onChange={e=>setSelectedDate(e.target.value)} className="border p-2 rounded" />
                  </div>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                      {attendanceSummary.map(stat => (
                          <div key={stat.class} className="border rounded p-4 text-center hover:shadow-md transition">
                              <h4 className="font-bold text-gray-700 border-b pb-2 mb-2">Class {stat.class}</h4>
                              <div className="flex justify-center space-x-4 text-sm">
                                  <div className="text-green-600 font-bold">P: {stat.present}</div>
                                  <div className="text-red-500 font-bold">A: {stat.absent}</div>
                              </div>
                              <div className="mt-2 text-xs text-gray-400">Total: {stat.total}</div>
                          </div>
                      ))}
                  </div>
              </div>
          );
      case 'fees':
          return (
              <div className="bg-white rounded-lg shadow overflow-hidden">
                  <div className="p-4 border-b flex justify-between items-center bg-gray-50">
                      <h3 className="text-lg font-bold">Fee Transactions</h3>
                      <button onClick={() => setCollectFeeModalOpen(true)} className="bg-green-600 text-white px-4 py-2 rounded flex items-center hover:bg-green-700 shadow"><RupeeIcon className="w-5 h-5 mr-2"/> Collect Fee</button>
                  </div>
                  <div className="max-h-[500px] overflow-y-auto">
                      <table className="w-full text-left">
                          <thead className="bg-gray-100 sticky top-0"><tr><th className="p-3">Date</th><th className="p-3">Student</th><th className="p-3">Class</th><th className="p-3">Type</th><th className="p-3 text-right">Amount</th><th className="p-3">Method</th></tr></thead>
                          <tbody className="divide-y">
                              {feeTransactions.map(tx => (
                                  <tr key={tx.id}>
                                      <td className="p-3">{new Date(tx.date).toLocaleDateString()}</td>
                                      <td className="p-3 font-medium">{tx.studentName}</td>
                                      <td className="p-3">{tx.class}</td>
                                      <td className="p-3"><span className="bg-blue-100 text-blue-800 px-2 py-0.5 rounded text-xs">{tx.type}</span></td>
                                      <td className="p-3 text-right font-bold text-gray-800">₹{tx.amount}</td>
                                      <td className="p-3 text-sm text-gray-500">{tx.paymentMethod}</td>
                                  </tr>
                              ))}
                          </tbody>
                      </table>
                  </div>
              </div>
          );
      case 'results':
          return (
              <div className="bg-white rounded-lg shadow p-6">
                  <div className="flex justify-between items-center mb-6">
                      <h3 className="text-lg font-bold">Exam Results Management</h3>
                      <button onClick={openResultEntryModal} className="bg-pink-600 text-white px-4 py-2 rounded shadow hover:bg-pink-700 flex items-center">
                          <FileTextIcon className="w-5 h-5 mr-2"/> Enter Marks
                      </button>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      {exams.map(exam => (
                          <div key={exam.id} className="border rounded-lg p-4 hover:shadow-lg transition cursor-pointer border-indigo-100 bg-indigo-50">
                              <div className="flex justify-between">
                                  <h4 className="font-bold text-indigo-900">{exam.name}</h4>
                                  <span className={`px-2 py-1 text-xs rounded font-bold ${exam.status === 'Completed' ? 'bg-green-200 text-green-800' : 'bg-yellow-200 text-yellow-800'}`}>{exam.status}</span>
                              </div>
                              <p className="text-sm text-gray-600 mt-1">{new Date(exam.startDate).toLocaleDateString()} - {new Date(exam.endDate).toLocaleDateString()}</p>
                          </div>
                      ))}
                  </div>
              </div>
          );
      case 'homework':
          return (
              <div className="bg-white rounded-lg shadow p-6">
                  <h3 className="text-lg font-bold mb-4">Homework Monitor</h3>
                  <div className="space-y-3">
                      {homeworks.map(hw => (
                          <div key={hw.id} className="border p-3 rounded flex justify-between items-center bg-gray-50">
                              <div>
                                  <div className="flex items-center space-x-2">
                                      <span className="font-bold text-indigo-700">{hw.subject}</span>
                                      <span className="text-xs bg-gray-200 px-2 rounded">Class {hw.class}</span>
                                      <span className="text-xs text-gray-500">{new Date(hw.date).toLocaleDateString()}</span>
                                  </div>
                                  <p className="text-sm text-gray-800 mt-1">{hw.details}</p>
                              </div>
                              {hw.attachment && <PaperClipIcon className="w-4 h-4 text-gray-400"/>}
                          </div>
                      ))}
                      {homeworks.length === 0 && <p className="text-gray-400">No homework records found.</p>}
                  </div>
              </div>
          );
      case 'hr':
          return (
              <div className="space-y-6">
                  <div className="bg-white rounded-lg shadow p-6">
                      <h3 className="text-lg font-bold mb-4 text-orange-600">Teacher Leave Requests (Pending)</h3>
                      {leaves.filter(l => l.status === 'Pending').length === 0 && <p className="text-gray-400">No pending leave requests.</p>}
                      <div className="space-y-3">
                          {leaves.filter(l => l.status === 'Pending').map(leave => (
                              <div key={leave.id} className="border p-4 rounded flex justify-between items-center bg-orange-50">
                                  <div>
                                      <p className="font-bold">{leave.employeeName}</p>
                                      <p className="text-sm text-gray-600">{leave.type} Leave • {new Date(leave.startDate).toLocaleDateString()} to {new Date(leave.endDate).toLocaleDateString()}</p>
                                      <p className="text-xs text-gray-500 italic">"{leave.reason}"</p>
                                  </div>
                                  <div className="flex gap-2">
                                      <button onClick={()=>handleLeaveAction(leave.id, 'Approved')} className="bg-green-600 text-white px-3 py-1 rounded text-sm hover:bg-green-700">Approve</button>
                                      <button onClick={()=>handleLeaveAction(leave.id, 'Rejected')} className="bg-red-600 text-white px-3 py-1 rounded text-sm hover:bg-red-700">Reject</button>
                                  </div>
                              </div>
                          ))}
                      </div>
                  </div>

                  <div className="bg-white rounded-lg shadow p-6">
                      <div className="flex justify-between items-center mb-4">
                          <h3 className="text-lg font-bold text-indigo-600">Payroll Management</h3>
                          <input type="month" value={payrollMonth} onChange={e=>setPayrollMonth(e.target.value)} className="border p-2 rounded" />
                      </div>
                      <table className="w-full text-left border-collapse">
                          <thead className="bg-gray-100"><tr><th className="p-3">Teacher</th><th className="p-3">Salary</th><th className="p-3">Status</th><th className="p-3 text-right">Action</th></tr></thead>
                          <tbody className="divide-y">
                              {teachers.map(teacher => {
                                  const paid = payrolls.find(p => p.employeeId === teacher.id);
                                  return (
                                      <tr key={teacher.id}>
                                          <td className="p-3 font-medium">{teacher.name}</td>
                                          <td className="p-3">₹{(teacher.baseSalary || 0).toLocaleString()}</td>
                                          <td className="p-3">{paid ? <span className="text-green-600 font-bold text-xs bg-green-100 px-2 py-1 rounded">PAID</span> : <span className="text-gray-400 text-xs">PENDING</span>}</td>
                                          <td className="p-3 text-right">
                                              {!paid && <button onClick={()=>handleGeneratePayroll(teacher)} className="text-indigo-600 border border-indigo-600 px-3 py-1 rounded hover:bg-indigo-50 text-sm">Generate Slip</button>}
                                              {paid && <span className="text-gray-400 text-sm">Generated</span>}
                                          </td>
                                      </tr>
                                  )
                              })}
                          </tbody>
                      </table>
                  </div>
              </div>
          );
      case 'notices':
          return (
            <div className="bg-white rounded-lg shadow p-6">
               <div className="flex justify-between items-center mb-6">
                  <h3 className="text-lg font-bold text-gray-700">Notice Board Management</h3>
                  <button onClick={() => setNoticeModalOpen(true)} className="bg-indigo-600 text-white px-4 py-2 rounded flex items-center hover:bg-indigo-700">
                      <PlusIcon className="w-5 h-5 mr-2"/> Create Notice
                  </button>
               </div>
               <div className="grid gap-4">
                  {notices.map(notice => (
                      <div key={notice.id} className="border p-4 rounded-lg flex justify-between items-start hover:bg-gray-50">
                          <div>
                              <h4 className="font-bold text-lg text-indigo-900">{notice.title}</h4>
                              <p className="text-sm text-gray-500 mb-2">
                                  {new Date(notice.date).toLocaleDateString()} • 
                                  <span className={`ml-2 px-2 py-0.5 rounded-full text-xs ${notice.audience === 'public' ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'}`}>
                                      {notice.audience.toUpperCase()}
                                  </span>
                              </p>
                              <p className="text-gray-700">{notice.content}</p>
                          </div>
                          <button onClick={() => handleDeleteNotice(notice.id)} className="text-red-500 hover:bg-red-50 p-2 rounded">
                              <TrashIcon className="w-5 h-5" />
                          </button>
                      </div>
                  ))}
                  {notices.length === 0 && <p className="text-gray-500 text-center py-8">No notices posted yet.</p>}
               </div>
            </div>
          );
      case 'credentials':
          return (
              <div className="bg-white rounded-lg shadow p-6">
                  <h3 className="text-lg font-bold mb-4">User Credentials Directory</h3>
                  <div className="overflow-x-auto">
                      <table className="w-full text-left text-sm">
                          <thead className="bg-gray-100"><tr><th className="p-3">Role</th><th className="p-3">Name</th><th className="p-3">Mobile (Login ID)</th><th className="p-3">Password</th></tr></thead>
                          <tbody className="divide-y">
                              {credentials.map((c, i) => (
                                  <tr key={i} className="hover:bg-gray-50">
                                      <td className="p-3"><span className={`px-2 py-1 rounded text-xs font-bold ${c.role==='teacher'?'bg-purple-100 text-purple-800':c.role==='student'?'bg-blue-100 text-blue-800':'bg-gray-200'}`}>{c.role.toUpperCase()}</span></td>
                                      <td className="p-3 font-medium">{c.name}</td>
                                      <td className="p-3 font-mono">{c.mobile}</td>
                                      <td className="p-3 font-mono text-red-600 bg-red-50 inline-block rounded px-2 m-1">{c.password}</td>
                                  </tr>
                              ))}
                          </tbody>
                      </table>
                  </div>
              </div>
          );
      case 'settings':
          return (
              <div className="bg-white rounded-lg shadow p-6">
                  <h3 className="text-lg font-bold mb-6">System Settings</h3>
                  <div className="space-y-6">
                      <div className="border p-4 rounded-lg bg-blue-50 border-blue-200">
                          <h4 className="font-bold text-blue-900 mb-2">Backup Data</h4>
                          <p className="text-sm text-blue-700 mb-4">Download a JSON file containing all school data (Students, Fees, Results, etc).</p>
                          <button onClick={() => api.createBackup()} className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700">Download Backup</button>
                          {lastSaveTime && <p className="text-xs text-gray-500 mt-2">Last Auto-Saved: {new Date(lastSaveTime).toLocaleString()}</p>}
                      </div>
                      <div className="border p-4 rounded-lg bg-red-50 border-red-200">
                          <h4 className="font-bold text-red-900 mb-2">Restore Data</h4>
                          <p className="text-sm text-red-700 mb-4">Upload a previously backed up JSON file to restore system state.</p>
                          <input type="file" accept=".json" onChange={handleRestore} className="block w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-red-100 file:text-red-700 hover:file:bg-red-200"/>
                      </div>
                  </div>
              </div>
          );
      default: return null;
    }
  };

  return (
    <div className="min-h-screen bg-gray-100 flex">
      {/* Sidebar */}
      <aside className="w-64 bg-indigo-900 text-white flex-shrink-0 hidden md:flex flex-col">
        <div className="p-6 flex items-center space-x-3 border-b border-indigo-800">
          <div className="bg-white p-1.5 rounded-lg">
              <SchoolIcon className="w-6 h-6 text-indigo-900" />
          </div>
          <div>
             <h1 className="font-bold text-lg leading-none">Admin Panel</h1>
             <p className="text-xs text-indigo-300 mt-1">{user.name}</p>
          </div>
        </div>
        <nav className="mt-6 px-4 space-y-1 flex-1 overflow-y-auto custom-scrollbar">
            {[
                {id: 'overview', label: 'Overview', icon: SchoolIcon},
                {id: 'students', label: 'Admission & Students', icon: UserIcon},
                {id: 'gallery', label: 'Gallery & Media', icon: PhotoIcon},
                {id: 'student_leaves', label: 'Student Leaves', icon: ClockIcon},
                {id: 'fees', label: 'Fees Collection', icon: RupeeIcon},
                {id: 'academics', label: 'Academics', icon: FileTextIcon},
                {id: 'results', label: 'Results & Marksheets', icon: ReceiptIcon},
                {id: 'timetable', label: 'Timetable', icon: ClockIcon},
                {id: 'attendance', label: 'Attendance', icon: UserIcon},
                {id: 'homework', label: 'Homework Monitor', icon: FileTextIcon},
                {id: 'teachers', label: 'Teachers & Staff', icon: BriefcaseIcon},
                {id: 'hr', label: 'HR & Payroll', icon: UserIcon},
                {id: 'notices', label: 'Notice Board', icon: BellIcon},
                {id: 'credentials', label: 'IDs & Passwords', icon: LockIcon},
                {id: 'settings', label: 'Settings', icon: SettingsIcon},
            ].map(item => (
                <button key={item.id} onClick={() => setActiveTab(item.id)} className={`w-full flex items-center space-x-3 px-4 py-3 rounded-lg transition ${activeTab === item.id ? 'bg-indigo-800 text-white shadow' : 'text-indigo-200 hover:bg-indigo-800 hover:text-white'}`}>
                    <item.icon className="w-5 h-5" /> <span>{item.label}</span>
                </button>
            ))}
        </nav>
        <div className="p-4 border-t border-indigo-800">
            <button onClick={onLogout} className="w-full flex items-center justify-center space-x-2 bg-red-600 hover:bg-red-700 text-white py-2 rounded-lg transition shadow">
                <LogoutIcon className="w-5 h-5" /> <span>Logout</span>
            </button>
        </div>
      </aside>

      {/* Mobile Header & Main Content */}
      <div className="flex-1 flex flex-col h-screen overflow-hidden">
        <header className="bg-white shadow p-4 md:hidden flex justify-between items-center z-20">
             <div className="flex items-center space-x-2">
                 <SchoolIcon className="w-6 h-6 text-indigo-600" />
                 <h1 className="font-bold text-gray-800">Admin Panel</h1>
             </div>
             <button onClick={onLogout}><LogoutIcon className="w-6 h-6 text-gray-600" /></button>
        </header>
        
        <main className="flex-1 overflow-y-auto p-6">
             {/* Mobile Nav Pills */}
             <div className="md:hidden mb-6 flex overflow-x-auto space-x-2 pb-2 no-scrollbar">
                {['overview', 'gallery', 'students', 'student_leaves', 'fees', 'results', 'timetable'].map(tab => (
                    <button key={tab} onClick={() => setActiveTab(tab)} className={`px-4 py-2 rounded-full text-sm font-medium whitespace-nowrap ${activeTab === tab ? 'bg-indigo-600 text-white' : 'bg-white text-gray-600 border'}`}>
                        {tab.charAt(0).toUpperCase() + tab.slice(1).replace('_', ' ')}
                    </button>
                ))}
             </div>
             
             <div className="animate-fade-in">
                {renderContent()}
             </div>
        </main>
      </div>

      {/* --- MODALS --- */}

      {/* Gallery Modal */}
      {galleryModalOpen && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-50 px-4">
              <div className="bg-white p-6 rounded-lg shadow-xl w-full max-w-md">
                  <h2 className="text-xl font-bold mb-4 text-indigo-800">Add to Gallery</h2>
                  <form onSubmit={handleAddGalleryItem}>
                      <div className="mb-4">
                          <label className="block text-sm font-bold mb-1">Type</label>
                          <div className="flex space-x-4">
                              <label className="flex items-center">
                                  <input type="radio" name="type" checked={newGalleryItem.type === 'photo'} onChange={() => setNewGalleryItem({...newGalleryItem, type: 'photo'})} className="mr-2" />
                                  Photo
                              </label>
                              <label className="flex items-center">
                                  <input type="radio" name="type" checked={newGalleryItem.type === 'video'} onChange={() => setNewGalleryItem({...newGalleryItem, type: 'video'})} className="mr-2" />
                                  Video
                              </label>
                          </div>
                      </div>
                      
                      <div className="mb-4">
                          <label className="block text-sm font-bold mb-1">Title</label>
                          <input type="text" value={newGalleryItem.title} onChange={e => setNewGalleryItem({...newGalleryItem, title: e.target.value})} className="w-full p-2 border rounded" required />
                      </div>

                      {newGalleryItem.type === 'photo' && (
                          <div className="mb-4">
                              <label className="block text-sm font-bold mb-1">Upload Photo</label>
                              <input type="file" accept="image/*" onChange={handleGalleryUpload} className="w-full p-2 border rounded" required={!newGalleryItem.url} />
                          </div>
                      )}

                      {newGalleryItem.type === 'video' && (
                          <div className="mb-4">
                              <label className="block text-sm font-bold mb-1">Video Source</label>
                              <div className="flex space-x-2 mb-2 text-sm">
                                  <button type="button" onClick={() => setGalleryUploadType('file')} className={`px-3 py-1 rounded ${galleryUploadType === 'file' ? 'bg-indigo-100 text-indigo-700 font-bold' : 'text-gray-500'}`}>Upload File</button>
                                  <button type="button" onClick={() => setGalleryUploadType('url')} className={`px-3 py-1 rounded ${galleryUploadType === 'url' ? 'bg-indigo-100 text-indigo-700 font-bold' : 'text-gray-500'}`}>YouTube/Link</button>
                              </div>
                              
                              {galleryUploadType === 'file' ? (
                                  <>
                                    <input type="file" accept="video/*" onChange={handleGalleryUpload} className="w-full p-2 border rounded" />
                                    <p className="text-xs text-red-500 mt-1">Note: Max file size 5MB.</p>
                                  </>
                              ) : (
                                  <input type="text" placeholder="https://youtube.com/watch?v=..." value={newGalleryItem.url} onChange={e => setNewGalleryItem({...newGalleryItem, url: e.target.value})} className="w-full p-2 border rounded" />
                              )}
                          </div>
                      )}

                      <div className="mb-4">
                           <label className="block text-sm font-bold mb-1">Description</label>
                           <textarea value={newGalleryItem.description} onChange={e => setNewGalleryItem({...newGalleryItem, description: e.target.value})} className="w-full p-2 border rounded" rows={2}></textarea>
                      </div>

                      <div className="flex justify-end space-x-2">
                          <button type="button" onClick={() => setGalleryModalOpen(false)} className="px-4 py-2 border rounded">Cancel</button>
                          <button type="submit" className="px-4 py-2 bg-indigo-600 text-white rounded">Add Item</button>
                      </div>
                  </form>
              </div>
          </div>
      )}

      {/* Comprehensive Student Admission/Edit Modal */}
      {studentModalOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-50 px-4">
            <div className="bg-white p-6 rounded-lg shadow-xl w-full max-w-4xl max-h-[90vh] overflow-y-auto">
                <div className="flex justify-between items-center mb-4 border-b pb-2">
                    <h2 className="text-2xl font-bold text-indigo-800">{isEditingStudent ? 'Edit Student Details' : 'New Student Admission Form'}</h2>
                    <button onClick={() => setStudentModalOpen(false)} className="text-gray-500 hover:text-red-500 text-2xl">&times;</button>
                </div>
                <form onSubmit={handleAddStudent} className="space-y-6">
                    <div className="flex flex-col md:flex-row gap-6">
                        {/* Photo Upload Section */}
                        <div className="w-full md:w-1/4 flex flex-col items-center space-y-2">
                            <div className="w-32 h-32 rounded-full bg-gray-100 border-2 border-dashed border-gray-300 flex items-center justify-center overflow-hidden relative">
                                {studentPhoto ? (
                                    <img src={studentPhoto} alt="Preview" className="w-full h-full object-cover" />
                                ) : (
                                    <CameraIcon className="w-10 h-10 text-gray-400" />
                                )}
                            </div>
                            <label className="cursor-pointer bg-indigo-50 text-indigo-600 px-4 py-2 rounded text-sm hover:bg-indigo-100 font-medium">
                                Upload Photo
                                <input type="file" className="hidden" accept="image/*" onChange={handlePhotoUpload} />
                            </label>
                        </div>

                        <div className="flex-1 grid grid-cols-1 md:grid-cols-3 gap-4">
                            {/* Basic Info */}
                            <div><label className="block text-xs font-bold mb-1">Admission No</label><input type="text" value={newStudent.admissionNo} onChange={e=>setNewStudent({...newStudent, admissionNo: e.target.value})} className="w-full p-2 border rounded"/></div>
                            <div><label className="block text-xs font-bold mb-1">Full Name *</label><input type="text" value={newStudent.name} onChange={e=>setNewStudent({...newStudent, name: e.target.value})} className="w-full p-2 border rounded" required/></div>
                            <div><label className="block text-xs font-bold mb-1">Date of Birth</label><input type="date" value={newStudent.dob} onChange={e=>setNewStudent({...newStudent, dob: e.target.value})} className="w-full p-2 border rounded"/></div>
                            
                            <div><label className="block text-xs font-bold mb-1">Class *</label>
                                <select value={newStudent.class} onChange={e=>setNewStudent({...newStudent, class: e.target.value})} className="w-full p-2 border rounded">
                                    {ALL_CLASSES.map(c => <option key={c} value={c}>{c}</option>)}
                                </select>
                            </div>
                            <div><label className="block text-xs font-bold mb-1">Gender</label>
                                <select value={newStudent.gender} onChange={e=>setNewStudent({...newStudent, gender: e.target.value as any})} className="w-full p-2 border rounded">
                                    <option value="Male">Male</option>
                                    <option value="Female">Female</option>
                                </select>
                            </div>
                            <div><label className="block text-xs font-bold mb-1">Mobile (Login ID) *</label><input type="tel" value={newStudent.mobile} onChange={e=>setNewStudent({...newStudent, mobile: e.target.value})} className="w-full p-2 border rounded" required/></div>

                            {/* Parents Info */}
                            <div><label className="block text-xs font-bold mb-1">Father's Name *</label><input type="text" value={newStudent.fatherName} onChange={e=>setNewStudent({...newStudent, fatherName: e.target.value})} className="w-full p-2 border rounded" required/></div>
                            <div><label className="block text-xs font-bold mb-1">Mother's Name</label><input type="text" value={newStudent.motherName} onChange={e=>setNewStudent({...newStudent, motherName: e.target.value})} className="w-full p-2 border rounded"/></div>
                            
                            {/* Additional Info */}
                            <div><label className="block text-xs font-bold mb-1">Aadhar No</label><input type="text" value={newStudent.aadharNo} onChange={e=>setNewStudent({...newStudent, aadharNo: e.target.value})} className="w-full p-2 border rounded"/></div>
                            <div><label className="block text-xs font-bold mb-1">Religion</label>
                                <select value={newStudent.religion} onChange={e=>setNewStudent({...newStudent, religion: e.target.value})} className="w-full p-2 border rounded">
                                    <option value="Hindu">Hindu</option>
                                    <option value="Muslim">Muslim</option>
                                    <option value="Christian">Christian</option>
                                    <option value="Sikh">Sikh</option>
                                    <option value="Other">Other</option>
                                </select>
                            </div>
                            <div><label className="block text-xs font-bold mb-1">Category</label>
                                <select value={newStudent.category} onChange={e=>setNewStudent({...newStudent, category: e.target.value as any})} className="w-full p-2 border rounded">
                                    <option value="General">General</option>
                                    <option value="OBC">OBC</option>
                                    <option value="SC">SC</option>
                                    <option value="ST">ST</option>
                                </select>
                            </div>
                            <div><label className="block text-xs font-bold mb-1">Blood Group</label><input type="text" value={newStudent.bloodGroup} onChange={e=>setNewStudent({...newStudent, bloodGroup: e.target.value})} className="w-full p-2 border rounded"/></div>
                        </div>
                    </div>
                    
                    <div className="border-t pt-4">
                        <h4 className="font-bold text-sm text-gray-600 mb-2">Address Details</h4>
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                            <div className="md:col-span-2"><label className="block text-xs font-bold mb-1">Address</label><input type="text" value={newStudent.address} onChange={e=>setNewStudent({...newStudent, address: e.target.value})} className="w-full p-2 border rounded"/></div>
                            <div><label className="block text-xs font-bold mb-1">City</label><input type="text" value={newStudent.city} onChange={e=>setNewStudent({...newStudent, city: e.target.value})} className="w-full p-2 border rounded"/></div>
                        </div>
                    </div>

                    <div className="flex justify-end space-x-3 mt-6 border-t pt-4">
                        <button type="button" onClick={() => setStudentModalOpen(false)} className="px-4 py-2 border rounded text-gray-600 hover:bg-gray-50">Cancel</button>
                        <button type="submit" className="px-6 py-2 bg-indigo-600 text-white rounded hover:bg-indigo-700 font-bold">{isEditingStudent ? 'Update Student' : 'Submit Admission'}</button>
                    </div>
                </form>
            </div>
        </div>
      )}

      {/* Teacher Add Modal */}
      {teacherModalOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-50 px-4">
            <div className="bg-white p-6 rounded-lg shadow-xl w-full max-w-lg">
                <h2 className="text-2xl font-bold mb-4 text-purple-800">Add New Teacher</h2>
                <form onSubmit={handleAddTeacher} className="space-y-3">
                    <div className="grid grid-cols-2 gap-3">
                        <div><label className="block text-xs font-bold">Name</label><input type="text" value={newTeacher.name} onChange={e=>setNewTeacher({...newTeacher, name:e.target.value})} className="w-full p-2 border rounded" required/></div>
                        <div><label className="block text-xs font-bold">Mobile</label><input type="tel" value={newTeacher.mobile} onChange={e=>setNewTeacher({...newTeacher, mobile:e.target.value})} className="w-full p-2 border rounded" required/></div>
                    </div>
                    <div className="grid grid-cols-2 gap-3">
                        <div><label className="block text-xs font-bold">Subject</label><input type="text" value={newTeacher.subject} onChange={e=>setNewTeacher({...newTeacher, subject:e.target.value})} className="w-full p-2 border rounded"/></div>
                        <div><label className="block text-xs font-bold">Salary (₹)</label><input type="number" value={newTeacher.baseSalary} onChange={e=>setNewTeacher({...newTeacher, baseSalary:Number(e.target.value)})} className="w-full p-2 border rounded"/></div>
                    </div>
                    <div>
                        <label className="block text-xs font-bold mb-1">Assigned Classes</label>
                        <select multiple value={newTeacher.assignedClasses} onChange={e=>setNewTeacher({...newTeacher, assignedClasses: Array.from(e.target.selectedOptions, o => o.value)})} className="w-full p-2 border rounded h-24">
                            {ALL_CLASSES.map(c => <option key={c} value={c}>{c}</option>)}
                        </select>
                    </div>
                    <div className="flex justify-end space-x-3 mt-4">
                        <button type="button" onClick={() => setTeacherModalOpen(false)} className="px-4 py-2 border rounded">Cancel</button>
                        <button type="submit" className="px-4 py-2 bg-purple-600 text-white rounded">Save</button>
                    </div>
                </form>
            </div>
        </div>
      )}

      {/* Notice Modal */}
      {noticeModalOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-50 px-4">
            <div className="bg-white p-6 rounded-lg shadow-xl w-full max-w-md">
                <h2 className="text-xl font-bold mb-4">Create New Notice</h2>
                <form onSubmit={handleAddNotice}>
                    <div className="mb-4"><label className="block text-sm font-medium">Title</label><input type="text" value={newNotice.title} onChange={e => setNewNotice({...newNotice, title: e.target.value})} className="w-full p-2 border rounded" required /></div>
                    <div className="mb-4"><label className="block text-sm font-medium">Content</label><textarea value={newNotice.content} onChange={e => setNewNotice({...newNotice, content: e.target.value})} className="w-full p-2 border rounded" rows={4} required></textarea></div>
                    <div className="mb-6"><label className="block text-sm font-medium">Audience</label>
                        <select value={newNotice.audience} onChange={e => setNewNotice({...newNotice, audience: e.target.value as any})} className="w-full p-2 border rounded">
                            <option value="public">Public (Everyone)</option>
                            <option value="teacher">Teachers Only</option>
                        </select>
                    </div>
                    <div className="flex justify-end space-x-2"><button type="button" onClick={() => setNoticeModalOpen(false)} className="px-4 py-2 border rounded">Cancel</button><button type="submit" className="px-4 py-2 bg-indigo-600 text-white rounded">Post Notice</button></div>
                </form>
            </div>
        </div>
      )}
      
      {/* Timetable Edit Modal */}
      {timetableModalOpen && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-50 px-4">
              <div className="bg-white p-6 rounded-lg shadow-xl w-full max-w-md">
                  <h2 className="text-lg font-bold mb-4">Edit Timetable: Class {selectedClassForTimetable}</h2>
                  <form onSubmit={handleSaveTimetableEntry}>
                      <div className="grid grid-cols-2 gap-4 mb-4">
                          <div><label className="block text-xs font-bold">Day</label>
                              <select value={timetableEntry.day} onChange={e=>setTimetableEntry({...timetableEntry, day: e.target.value})} className="w-full p-2 border rounded">
                                  {['Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'].map(d=><option key={d} value={d}>{d}</option>)}
                              </select>
                          </div>
                          <div><label className="block text-xs font-bold">Period</label>
                               <select value={timetableEntry.period} onChange={e=>setTimetableEntry({...timetableEntry, period: Number(e.target.value)})} className="w-full p-2 border rounded">
                                   {[1,2,3,4,5,6,7,8].map(p=><option key={p} value={p}>{p}</option>)}
                               </select>
                          </div>
                      </div>
                      <div className="mb-4">
                          <label className="block text-xs font-bold">Subject</label>
                          <input type="text" value={timetableEntry.subject} onChange={e=>setTimetableEntry({...timetableEntry, subject: e.target.value})} className="w-full p-2 border rounded" required/>
                      </div>
                      <div className="mb-4">
                          <label className="block text-xs font-bold">Teacher</label>
                          <select value={timetableEntry.teacherId} onChange={e=>setTimetableEntry({...timetableEntry, teacherId: e.target.value})} className="w-full p-2 border rounded">
                              <option value="">-- Select Teacher --</option>
                              {teachers.map(t=><option key={t.id} value={t.id}>{t.name}</option>)}
                          </select>
                      </div>
                      <div className="grid grid-cols-2 gap-4 mb-4">
                          <div><label className="block text-xs font-bold">Start Time</label><input type="time" value={timetableEntry.startTime} onChange={e=>setTimetableEntry({...timetableEntry, startTime: e.target.value})} className="w-full p-2 border rounded"/></div>
                          <div><label className="block text-xs font-bold">End Time</label><input type="time" value={timetableEntry.endTime} onChange={e=>setTimetableEntry({...timetableEntry, endTime: e.target.value})} className="w-full p-2 border rounded"/></div>
                      </div>
                      <div className="flex justify-end gap-2">
                          <button type="button" onClick={()=>setTimetableModalOpen(false)} className="px-4 py-2 border rounded">Cancel</button>
                          <button type="submit" className="px-4 py-2 bg-indigo-600 text-white rounded">Save Entry</button>
                      </div>
                  </form>
              </div>
          </div>
      )}

      {/* Fee Collection Modal */}
      {collectFeeModalOpen && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-50 px-4">
              <div className="bg-white p-6 rounded-lg shadow-xl w-full max-w-md">
                  <h2 className="text-lg font-bold mb-4 text-green-700">Collect Fees</h2>
                  <form onSubmit={handleCollectFee}>
                      <div className="mb-4">
                          <label className="block text-xs font-bold">Select Class</label>
                          <select value={feeCollectionData.class} onChange={e=>setFeeCollectionData({...feeCollectionData, class: e.target.value})} className="w-full p-2 border rounded">
                              {ALL_CLASSES.map(c=><option key={c} value={c}>{c}</option>)}
                          </select>
                      </div>
                      <div className="mb-4">
                          <label className="block text-xs font-bold">Select Student</label>
                          <select value={feeCollectionData.studentId} onChange={e=>setFeeCollectionData({...feeCollectionData, studentId: e.target.value})} className="w-full p-2 border rounded" required>
                              <option value="">-- Select Student --</option>
                              {students.filter(s=>s.class === feeCollectionData.class).map(s=>(
                                  <option key={s.id} value={s.id}>{s.name} (F: {s.fatherName})</option>
                              ))}
                          </select>
                      </div>
                      <div className="mb-4">
                          <label className="block text-xs font-bold">Fee Type</label>
                          <select value={feeCollectionData.type} onChange={e=>setFeeCollectionData({...feeCollectionData, type: e.target.value})} className="w-full p-2 border rounded">
                              {['Admission','Tuition','Exam','Annual'].map(t=><option key={t} value={t}>{t}</option>)}
                          </select>
                      </div>
                      <div className="grid grid-cols-2 gap-4 mb-4">
                          <div>
                              <label className="block text-xs font-bold">Amount (₹)</label>
                              <input type="number" value={feeCollectionData.amount} onChange={e=>setFeeCollectionData({...feeCollectionData, amount: Number(e.target.value)})} className="w-full p-2 border rounded" required/>
                          </div>
                          <div>
                              <label className="block text-xs font-bold">Method</label>
                              <select value={feeCollectionData.method} onChange={e=>setFeeCollectionData({...feeCollectionData, method: e.target.value})} className="w-full p-2 border rounded">
                                  {['Cash','Online','UPI'].map(m=><option key={m} value={m}>{m}</option>)}
                              </select>
                          </div>
                      </div>
                      <div className="flex justify-end gap-2">
                          <button type="button" onClick={()=>setCollectFeeModalOpen(false)} className="px-4 py-2 border rounded">Cancel</button>
                          <button type="submit" className="px-4 py-2 bg-green-600 text-white rounded">Collect Payment</button>
                      </div>
                  </form>
              </div>
          </div>
      )}
      
      {/* Result Entry Modal */}
      {resultEntryModalOpen && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-50 px-4">
              <div className="bg-white p-6 rounded-lg shadow-xl w-full max-w-5xl max-h-[95vh] overflow-y-auto">
                  <div className="flex justify-between items-center mb-4 border-b pb-2">
                      <h2 className="text-xl font-bold text-pink-700">Enter Exam Results (Class-wise)</h2>
                      <button onClick={()=>setResultEntryModalOpen(false)} className="text-2xl">&times;</button>
                  </div>
                  <div className="grid grid-cols-3 gap-4 mb-6">
                      <div>
                          <label className="block text-xs font-bold">Select Exam</label>
                          <select value={selectedExamEntry} onChange={e=>setSelectedExamEntry(e.target.value)} className="w-full p-2 border rounded">
                              <option value="">-- Select Exam --</option>
                              {exams.map(e=><option key={e.id} value={e.id}>{e.name}</option>)}
                          </select>
                      </div>
                      <div>
                          <label className="block text-xs font-bold">Select Class</label>
                          <select value={selectedClassEntry} onChange={e=>setSelectedClassEntry(e.target.value)} className="w-full p-2 border rounded">
                              {ALL_CLASSES.map(c=><option key={c} value={c}>{c}</option>)}
                          </select>
                      </div>
                      <div>
                          <label className="block text-xs font-bold">Select Subject</label>
                          <select value={selectedSubjectEntry} onChange={e=>setSelectedSubjectEntry(e.target.value)} className="w-full p-2 border rounded" disabled={!selectedExamEntry}>
                              <option value="">-- Select Subject --</option>
                              {availableSubjects.map(s=><option key={s.subject} value={s.subject}>{s.subject} {(s as any).maxMarks ? `(Max: ${s.maxMarks})` : ''}</option>)}
                          </select>
                      </div>
                  </div>

                  {selectedSubjectEntry && selectedSubjectEntry !== 'All Subjects' && (
                      <div className="overflow-x-auto">
                          <table className="w-full border text-sm">
                              <thead className="bg-gray-100">
                                  <tr>
                                      <th className="p-3 border text-left">Student Name</th>
                                      <th className="p-3 border text-left">Father Name</th>
                                      <th className="p-3 border text-center w-32">Marks Obtained</th>
                                      <th className="p-3 border text-center">Max Marks</th>
                                  </tr>
                              </thead>
                              <tbody>
                                  {students.filter(s=>s.class === selectedClassEntry).map(s => (
                                      <tr key={s.id} className="hover:bg-gray-50">
                                          <td className="p-3 border font-medium">{s.name}</td>
                                          <td className="p-3 border text-gray-500">{s.fatherName}</td>
                                          <td className="p-3 border text-center">
                                              <input 
                                                  type="number" 
                                                  className="w-full p-1 border rounded text-center"
                                                  value={studentMarksEntry[s.id] || ''}
                                                  onChange={e=>setStudentMarksEntry({...studentMarksEntry, [s.id]: Number(e.target.value)})}
                                                  max={availableSubjects.find(sub=>sub.subject===selectedSubjectEntry)?.maxMarks}
                                              />
                                          </td>
                                          <td className="p-3 border text-center text-gray-500">{availableSubjects.find(sub=>sub.subject===selectedSubjectEntry)?.maxMarks}</td>
                                      </tr>
                                  ))}
                              </tbody>
                          </table>
                          <div className="mt-6 flex justify-end">
                              <button onClick={handleSaveResults} className="bg-pink-600 text-white px-6 py-2 rounded shadow hover:bg-pink-700 font-bold">Save All Marks</button>
                          </div>
                      </div>
                  )}

                  {selectedSubjectEntry === 'All Subjects' && (
                      <div className="overflow-x-auto">
                          <table className="w-full border text-sm whitespace-nowrap">
                              <thead className="bg-gray-100">
                                  <tr>
                                      <th className="p-3 border text-left sticky left-0 bg-gray-100 z-10">Student Name</th>
                                      {availableSubjects.filter(s => s.subject !== 'All Subjects').map(sub => (
                                          <th key={sub.subject} className="p-3 border text-center w-24">
                                              {sub.subject} <br/> <span className="text-xs font-normal text-gray-500">(Max: {sub.maxMarks})</span>
                                          </th>
                                      ))}
                                  </tr>
                              </thead>
                              <tbody>
                                  {students.filter(s=>s.class === selectedClassEntry).map(s => (
                                      <tr key={s.id} className="hover:bg-gray-50">
                                          <td className="p-3 border font-medium sticky left-0 bg-white z-10">{s.name}</td>
                                          {availableSubjects.filter(sub => sub.subject !== 'All Subjects').map(sub => (
                                              <td key={sub.subject} className="p-2 border text-center">
                                                  <input 
                                                      type="number" 
                                                      className="w-16 p-1 border rounded text-center mx-auto"
                                                      value={allSubjectsMarksEntry[s.id]?.[sub.subject] || ''}
                                                      onChange={e => {
                                                          const val = Number(e.target.value);
                                                          setAllSubjectsMarksEntry(prev => ({
                                                              ...prev,
                                                              [s.id]: { ...prev[s.id], [sub.subject]: val }
                                                          }));
                                                      }}
                                                  />
                                              </td>
                                          ))}
                                      </tr>
                                  ))}
                              </tbody>
                          </table>
                          <div className="mt-6 flex justify-end">
                              <button onClick={handleSaveResults} className="bg-purple-600 text-white px-6 py-2 rounded shadow hover:bg-purple-700 font-bold">Save Bulk Marks</button>
                          </div>
                      </div>
                  )}
              </div>
          </div>
      )}
    </div>
  );
};

export default PrincipalDashboard;
