
import React, { useState, useEffect, useCallback } from 'react';
import { Student, Attendance, Homework, Notice, TimetableEntry, ExamResult, Exam, GalleryItem } from '../types';
import { api, SCHOOL_LOGO_URL } from '../services/api';
import { LogoutIcon, SchoolIcon, UserIcon, ReceiptIcon, PaperClipIcon, PhotoIcon } from '../components/icons';
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';

interface StudentDashboardProps {
  user: Student;
  onLogout: () => void;
}

const StudentDashboard: React.FC<StudentDashboardProps> = ({ user, onLogout }) => {
  const [attendance, setAttendance] = useState<Attendance[]>([]);
  const [homework, setHomework] = useState<(Homework & { remark?: string })[]>([]);
  const [notices, setNotices] = useState<Notice[]>([]);
  const [timetable, setTimetable] = useState<TimetableEntry[]>([]);
  const [activeTab, setActiveTab] = useState('homework');
  const [examResults, setExamResults] = useState<ExamResult[]>([]);
  const [exams, setExams] = useState<Exam[]>([]);
  const [consolidatedMarks, setConsolidatedMarks] = useState<any[]>([]);
  const [isGeneratingPDF, setIsGeneratingPDF] = useState(false);
  const [galleryItems, setGalleryItems] = useState<GalleryItem[]>([]);

  const fetchData = useCallback(async () => {
      const attendanceData = await api.getAttendance(user.id);
      setAttendance(attendanceData);

      const homeworkData = await api.getHomeworkForClass(user.class);
      const remarksData = await api.getRemarksForStudent(user.id);
      const publicNotices = await api.getPublicNotices();
      const timetableData = await api.getTimetableForClass(user.class);

      const combinedHomework = homeworkData.map(hw => {
        const remark = remarksData.find(r => r.homeworkId === hw.id);
        return { ...hw, remark: remark?.remark };
      }).sort((a,b) => new Date(b.date).getTime() - new Date(a.date).getTime());
      
      setHomework(combinedHomework);
      setNotices(publicNotices);
      setTimetable(timetableData);
      
      setExamResults(await api.getStudentExamResults(user.id));
      setExams(await api.getAllExams());
      
      // Fetch detailed marksheet data
      setConsolidatedMarks(await api.getConsolidatedMarks(user.id));

      setGalleryItems(await api.getGalleryItems());
  }, [user.id, user.class]);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  const todaysAttendance = attendance.find(a => a.date === new Date().toISOString().split('T')[0]);

  const downloadFinalMarksheet = async () => {
      setIsGeneratingPDF(true);
      try {
          const doc = new jsPDF();
          const pageWidth = doc.internal.pageSize.width;
          const pageHeight = doc.internal.pageSize.height;
          
          // --- Page Border ---
          doc.setDrawColor(63, 81, 181); // Indigo border
          doc.setLineWidth(1.5);
          doc.rect(5, 5, pageWidth - 10, pageHeight - 10);
          doc.setLineWidth(0.5);
          doc.rect(7, 7, pageWidth - 14, pageHeight - 14);
          
          // --- Header Section ---
          // Try to load logo
          try {
              const img = new Image();
              img.src = SCHOOL_LOGO_URL;
              await new Promise((resolve, reject) => {
                  img.onload = resolve;
                  img.onerror = reject;
              });
              doc.addImage(img, 'PNG', 15, 12, 25, 25);
          } catch (e) {
              console.warn("Logo loading failed for PDF", e);
          }

          doc.setFont("helvetica", "bold");
          doc.setFontSize(24);
          doc.setTextColor(63, 81, 181); // Indigo brand color
          doc.text("ADARSH BAL VIDYA MANDIR", pageWidth / 2, 22, { align: "center" });
          
          doc.setFontSize(10);
          doc.setTextColor(80);
          doc.setFont("helvetica", "normal");
          doc.text("Bilgram - Hardoi, Uttar Pradesh | Estd. 1995", pageWidth / 2, 28, { align: "center" });
          doc.text("Affiliated to State Board of Education", pageWidth / 2, 33, { align: "center" });

          doc.setDrawColor(200);
          doc.line(15, 40, pageWidth - 15, 40);

          doc.setFontSize(16);
          doc.setTextColor(0);
          doc.setFont("helvetica", "bold");
          doc.text("ANNUAL PROGRESS REPORT", pageWidth / 2, 50, { align: "center" });
          doc.setFontSize(12);
          doc.setFont("helvetica", "normal");
          doc.text("ACADEMIC SESSION: 2024-2025", pageWidth / 2, 57, { align: "center" });

          // --- Student Profile Section ---
          doc.setFillColor(248, 250, 252); // Light gray-blue background
          doc.setDrawColor(226, 232, 240);
          doc.roundedRect(15, 65, pageWidth - 30, 32, 2, 2, 'FD');

          doc.setFontSize(10);
          doc.setTextColor(0);
          
          const leftColX = 22;
          const rightColX = 120;
          const row1Y = 73;
          const row2Y = 81;
          const row3Y = 89;

          doc.setFont("helvetica", "bold");
          doc.text("Student Name:", leftColX, row1Y);
          doc.setFont("helvetica", "normal");
          doc.text(user.name.toUpperCase(), leftColX + 30, row1Y);

          doc.setFont("helvetica", "bold");
          doc.text("Father's Name:", rightColX, row1Y);
          doc.setFont("helvetica", "normal");
          doc.text(user.fatherName.toUpperCase(), rightColX + 30, row1Y);

          doc.setFont("helvetica", "bold");
          doc.text("Class & Section:", leftColX, row2Y);
          doc.setFont("helvetica", "normal");
          doc.text(user.class, leftColX + 30, row2Y);

          doc.setFont("helvetica", "bold");
          doc.text("Roll Number:", rightColX, row2Y);
          doc.setFont("helvetica", "normal");
          doc.text(user.id.substring(0, 6).toUpperCase(), rightColX + 30, row2Y);
          
          doc.setFont("helvetica", "bold");
          doc.text("Date of Issue:", leftColX, row3Y);
          doc.setFont("helvetica", "normal");
          doc.text(new Date().toLocaleDateString('en-IN'), leftColX + 30, row3Y);

          doc.setFont("helvetica", "bold");
          doc.text("Mobile:", rightColX, row3Y);
          doc.setFont("helvetica", "normal");
          doc.text(user.mobile, rightColX + 30, row3Y);

          // --- Marks Table ---
          const tableData = consolidatedMarks.map(row => [
              row.subject,
              `${row.quarterly.obtained} / ${row.quarterly.max}`,
              `${row.halfYearly.obtained} / ${row.halfYearly.max}`,
              `${row.annual.obtained} / ${row.annual.max}`,
              row.total.obtained,
              row.total.max,
              row.grade
          ]);

          const grandTotalObtained = consolidatedMarks.reduce((acc, row) => acc + row.total.obtained, 0);
          const grandTotalMax = consolidatedMarks.reduce((acc, row) => acc + row.total.max, 0);
          const percentage = grandTotalMax > 0 ? ((grandTotalObtained / grandTotalMax) * 100).toFixed(2) : '0';

          autoTable(doc, {
              startY: 105,
              head: [['Subject', 'Quarterly', 'Half Yearly', 'Annual', 'Total Obt.', 'Max Marks', 'Grade']],
              body: tableData,
              theme: 'grid',
              headStyles: { 
                  fillColor: [63, 81, 181], 
                  textColor: 255, 
                  halign: 'center',
                  fontStyle: 'bold',
                  lineWidth: 0.1,
                  lineColor: [255, 255, 255]
              },
              columnStyles: {
                  0: { halign: 'left', fontStyle: 'bold' }, // Subject
                  1: { halign: 'center' },
                  2: { halign: 'center' },
                  3: { halign: 'center' },
                  4: { halign: 'center', fontStyle: 'bold', textColor: [63, 81, 181] },
                  5: { halign: 'center' },
                  6: { halign: 'center', fontStyle: 'bold' } // Grade
              },
              foot: [['GRAND TOTAL', '', '', '', grandTotalObtained, grandTotalMax, '']],
              footStyles: {
                  fillColor: [240, 240, 240],
                  textColor: 0,
                  fontStyle: 'bold',
                  halign: 'center'
              },
              styles: {
                  fontSize: 10,
                  cellPadding: 4
              }
          });

          // --- Performance Summary ---
          const finalY = (doc as any).lastAutoTable.finalY + 15;
          
          // Summary Box
          doc.setDrawColor(200);
          doc.setFillColor(240, 253, 244); // Light green tint
          doc.roundedRect(15, finalY, pageWidth - 30, 25, 2, 2, 'F');
          
          doc.setFontSize(12);
          doc.setTextColor(0);
          
          // Percentage
          doc.setFont("helvetica", "bold");
          doc.text(`Overall Percentage:`, 30, finalY + 10);
          doc.setFontSize(14);
          doc.setTextColor(63, 81, 181);
          doc.text(`${percentage}%`, 75, finalY + 10);
          
          // Attendance
          doc.setFontSize(12);
          doc.setTextColor(0);
          const presentDays = attendance.filter(a => a.status === 'Present').length;
          doc.text(`Total Attendance:`, 30, finalY + 18);
          doc.setFont("helvetica", "normal");
          doc.text(`${presentDays} / ${attendance.length} Days`, 75, finalY + 18);

          // Result Status
          const passed = parseFloat(percentage) >= 33;
          doc.setFont("helvetica", "bold");
          doc.setFontSize(14);
          doc.text("FINAL RESULT:", 120, finalY + 14);
          doc.setTextColor(passed ? 22 : 220, passed ? 163 : 38, passed ? 74 : 38); // Green or Red
          doc.text(passed ? "PASSED" : "NEEDS IMPROVEMENT", 160, finalY + 14);

          // --- Footer Signatures ---
          const signY = pageHeight - 35;
          doc.setDrawColor(0);
          doc.setLineWidth(0.5);
          doc.setTextColor(0);
          doc.setFontSize(10);
          doc.setFont("helvetica", "normal");

          // Teacher
          doc.line(30, signY, 80, signY);
          doc.text("Class Teacher Signature", 55, signY + 5, { align: "center" });
          
          // Principal
          doc.line(pageWidth - 80, signY, pageWidth - 30, signY);
          doc.text("Principal Signature", pageWidth - 55, signY + 5, { align: "center" });

          // Disclaimer
          doc.setFontSize(8);
          doc.setTextColor(150);
          doc.text(`Report Generated on: ${new Date().toLocaleString()}`, 15, pageHeight - 10);
          doc.text("This is a computer-generated document and does not require a physical seal.", pageWidth - 15, pageHeight - 10, { align: "right" });
          
          doc.save(`${user.name.replace(/\s+/g, '_')}_Final_Marksheet.pdf`);
      } catch (error) {
          console.error("Error generating PDF", error);
          alert("Failed to generate PDF. Please try again.");
      } finally {
          setIsGeneratingPDF(false);
      }
  };

  const renderContent = () => {
      switch(activeTab) {
          case 'homework':
              return (
                <div className="bg-white p-6 rounded-lg shadow-md">
                    <h3 className="text-xl font-bold mb-4">मेरा होमवर्क और रिमार्क्स</h3>
                    <div className="space-y-4">
                        {homework.length === 0 && <p className="text-gray-500">कोई होमवर्क नहीं मिला।</p>}
                        {homework.map(hw => (
                            <div key={hw.id} className="border-l-4 border-indigo-500 bg-gray-50 p-4 rounded-r-lg hover:bg-gray-100 transition">
                                <div className="flex justify-between items-start">
                                    <div>
                                        <h4 className="font-semibold text-gray-800">{hw.subject}</h4>
                                        <span className="text-sm text-gray-500">{new Date(hw.date).toLocaleDateString('hi-IN')}</span>
                                    </div>
                                    {hw.dueDate && (
                                        <span className="text-xs font-medium text-red-600 bg-white px-2 py-1 rounded border border-red-200 shadow-sm">
                                            Due: {new Date(hw.dueDate).toLocaleDateString('hi-IN')}
                                        </span>
                                    )}
                                </div>
                                <p className="text-gray-700 mt-2">{hw.details}</p>
                                {hw.attachment && (
                                    <div className="mt-2">
                                        <a href={hw.attachment} download={hw.attachmentName || 'download'} className="text-indigo-600 hover:underline text-sm flex items-center font-medium">
                                            <PaperClipIcon className="w-4 h-4 mr-1" /> {hw.attachmentName || 'Download Attachment'}
                                        </a>
                                    </div>
                                )}
                                {hw.remark && (
                                    <p className="mt-3 text-sm bg-yellow-100 text-yellow-800 p-2 rounded border border-yellow-200"><strong>टीचर का रिमार्क:</strong> {hw.remark}</p>
                                )}
                            </div>
                        ))}
                    </div>
                </div>
              );
          case 'gallery':
               return (
                   <div className="bg-white p-6 rounded-lg shadow-md">
                       <h3 className="text-xl font-bold mb-6">School Gallery</h3>
                       <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                           {galleryItems.length === 0 && <p className="text-gray-500 col-span-full">No media available.</p>}
                           {galleryItems.map(item => (
                               <div key={item.id} className="border rounded overflow-hidden shadow-sm">
                                   <div className="h-48 bg-gray-100">
                                       {item.type === 'photo' ? (
                                           <img src={item.url} alt={item.title} className="w-full h-full object-cover" />
                                       ) : (
                                          item.url.includes('youtube.com') || item.url.includes('youtu.be') ? (
                                              <iframe 
                                                  width="100%" 
                                                  height="100%" 
                                                  src={item.url.replace("watch?v=", "embed/").replace("youtu.be/", "youtube.com/embed/")} 
                                                  title={item.title}
                                                  frameBorder="0" 
                                                  allowFullScreen
                                              ></iframe>
                                          ) : (
                                              <video src={item.url} controls className="w-full h-full object-cover bg-black" />
                                          )
                                       )}
                                   </div>
                                   <div className="p-3">
                                       <h4 className="font-bold truncate">{item.title}</h4>
                                       <p className="text-sm text-gray-500">{new Date(item.date).toLocaleDateString()}</p>
                                   </div>
                               </div>
                           ))}
                       </div>
                   </div>
               );
          case 'attendance':
              return (
                <div className="bg-white p-6 rounded-lg shadow-md">
                    <div className="flex justify-between items-center mb-4">
                        <h3 className="text-xl font-bold">मेरी उपस्थिति</h3>
                        <div className="text-sm">
                            <span className="inline-block w-3 h-3 bg-green-500 rounded-full mr-1"></span> उपस्थित
                            <span className="inline-block w-3 h-3 bg-red-500 rounded-full ml-3 mr-1"></span> अनुपस्थित
                        </div>
                    </div>
                    <div className="max-h-96 overflow-y-auto">
                        <table className="w-full text-left border-collapse">
                            <thead className="bg-gray-100 sticky top-0">
                                <tr>
                                    <th className="p-3 border-b">दिनांक</th>
                                    <th className="p-3 border-b">स्थिति</th>
                                    <th className="p-3 border-b">विवरण</th>
                                </tr>
                            </thead>
                            <tbody className="divide-y">
                                {attendance.sort((a,b) => new Date(b.date).getTime() - new Date(a.date).getTime()).map((att, index) => (
                                    <tr key={index}>
                                        <td className="p-3">{new Date(att.date).toLocaleDateString('hi-IN', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}</td>
                                        <td className="p-3">
                                            <span className={`px-2 py-1 rounded-full text-xs font-bold ${att.status === 'Present' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`}>
                                                {att.status === 'Present' ? 'उपस्थित' : 'अनुपस्थित'}
                                            </span>
                                        </td>
                                        <td className="p-3 text-gray-600 text-sm">{att.reason || '-'}</td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                </div>
              );
          case 'timetable':
              const days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
              const periods = [1, 2, 3, 4, 5, 6, 7, 8];
              return (
                  <div className="bg-white p-6 rounded-lg shadow-md overflow-x-auto">
                      <h3 className="text-xl font-bold mb-4">Time Table</h3>
                      <table className="w-full border-collapse border border-gray-200">
                          <thead>
                              <tr className="bg-indigo-600 text-white">
                                  <th className="p-3 border w-24">Day</th>
                                  {periods.map(p => <th key={p} className="p-3 border text-center">{p}</th>)}
                              </tr>
                          </thead>
                          <tbody>
                              {days.map(day => (
                                  <tr key={day} className="bg-white hover:bg-gray-50">
                                      <td className="p-3 border font-bold bg-gray-100">{day}</td>
                                      {periods.map(period => {
                                          const entry = timetable.find(t => t.day === day && t.period === period);
                                          return (
                                              <td key={period} className="p-2 border text-center h-16 align-middle">
                                                  {entry ? (
                                                      <div className="bg-indigo-50 p-1 rounded border border-indigo-100">
                                                          <div className="font-bold text-indigo-800 text-sm">{entry.subject}</div>
                                                          <div className="text-[10px] text-gray-400">{entry.startTime}-{entry.endTime}</div>
                                                      </div>
                                                  ) : <span className="text-gray-200">-</span>}
                                              </td>
                                          );
                                      })}
                                  </tr>
                              ))}
                          </tbody>
                      </table>
                  </div>
              );
          case 'results':
               return (
                <div className="bg-white p-6 rounded-lg shadow-md">
                    <div className="flex flex-col sm:flex-row justify-between items-center mb-6 border-b pb-4">
                        <div>
                            <h3 className="text-xl font-bold text-gray-800">Annual Report Card</h3>
                            <p className="text-sm text-gray-500">Download the official marksheet comprising all exam terms.</p>
                        </div>
                        <button 
                            onClick={downloadFinalMarksheet} 
                            disabled={isGeneratingPDF || consolidatedMarks.length === 0}
                            className={`mt-4 sm:mt-0 bg-indigo-600 text-white px-6 py-3 rounded-lg shadow-lg flex items-center transition-all transform hover:scale-105 ${isGeneratingPDF || consolidatedMarks.length === 0 ? 'opacity-60 cursor-not-allowed' : 'hover:bg-indigo-700'}`}
                        >
                             {isGeneratingPDF ? (
                                 <span className="flex items-center">
                                     <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                                         <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                                         <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                                     </svg>
                                     Preparing PDF...
                                 </span>
                             ) : (
                                 <>
                                    <ReceiptIcon className="w-5 h-5 mr-2" /> Download Consolidated Marksheet
                                 </>
                             )}
                        </button>
                    </div>
                    
                    <div className="overflow-x-auto">
                        <table className="w-full border-collapse border">
                            <thead>
                                <tr className="bg-indigo-50 text-indigo-900">
                                    <th className="p-3 border border-indigo-200 text-left">Subject</th>
                                    <th className="p-3 border border-indigo-200 text-center">Timahi (Quarterly)</th>
                                    <th className="p-3 border border-indigo-200 text-center">Chhimahi (Half Yearly)</th>
                                    <th className="p-3 border border-indigo-200 text-center">Salana (Annual)</th>
                                    <th className="p-3 border border-indigo-200 text-center font-bold">Total</th>
                                    <th className="p-3 border border-indigo-200 text-center font-bold">Grade</th>
                                </tr>
                            </thead>
                            <tbody>
                                {consolidatedMarks.map((row, idx) => (
                                    <tr key={idx} className="hover:bg-gray-50">
                                        <td className="p-3 border font-medium">{row.subject}</td>
                                        <td className="p-3 border text-center">
                                            {row.quarterly.obtained} <span className="text-gray-400 text-xs">/ {row.quarterly.max}</span>
                                        </td>
                                        <td className="p-3 border text-center">
                                            {row.halfYearly.obtained} <span className="text-gray-400 text-xs">/ {row.halfYearly.max}</span>
                                        </td>
                                        <td className="p-3 border text-center">
                                            {row.annual.obtained} <span className="text-gray-400 text-xs">/ {row.annual.max}</span>
                                        </td>
                                        <td className="p-3 border text-center font-bold text-indigo-700">
                                            {row.total.obtained} / {row.total.max}
                                        </td>
                                        <td className="p-3 border text-center font-bold">
                                            <span className={`px-2 py-1 rounded text-xs ${['A+','A'].includes(row.grade) ? 'bg-green-100 text-green-800' : 'bg-gray-100'}`}>{row.grade}</span>
                                        </td>
                                    </tr>
                                ))}
                                {consolidatedMarks.length > 0 && (
                                    <tr className="bg-gray-100 font-bold">
                                        <td className="p-3 border">GRAND TOTAL</td>
                                        <td className="p-3 border text-center" colSpan={3}></td>
                                        <td className="p-3 border text-center text-lg text-indigo-800">
                                            {consolidatedMarks.reduce((acc, r) => acc + r.total.obtained, 0)} / {consolidatedMarks.reduce((acc, r) => acc + r.total.max, 0)}
                                        </td>
                                        <td className="p-3 border text-center"></td>
                                    </tr>
                                )}
                            </tbody>
                        </table>
                        {consolidatedMarks.length === 0 && <div className="p-8 text-center text-gray-500 border-2 border-dashed border-gray-200 rounded mt-4">No exam data available for marksheet generation yet.</div>}
                    </div>
                </div>
               );
          case 'notices':
               return (
                <div className="bg-white p-6 rounded-lg shadow-md">
                    <h3 className="text-xl font-bold mb-4">सूचनाएं</h3>
                    <div className="space-y-4">
                        {notices.map(notice => (
                            <div key={notice.id} className="p-4 border-l-4 border-blue-500 bg-blue-50 rounded-r-lg">
                                <div className="flex justify-between items-center mb-2">
                                    <h4 className="text-lg font-semibold text-blue-800">{notice.title}</h4>
                                    <span className="text-xs font-medium text-gray-500">{new Date(notice.date).toLocaleDateString('hi-IN')}</span>
                                </div>
                                <p className="text-gray-700">{notice.content}</p>
                            </div>
                        ))}
                    </div>
                </div>
               );
          default: return null;
      }
  };

  return (
    <div className="min-h-screen bg-gray-100">
      <header className="bg-white shadow-md p-4 flex justify-between items-center sticky top-0 z-20">
        <div className="flex items-center space-x-3">
            <div className="bg-indigo-100 p-2 rounded-full">
                <SchoolIcon className="w-6 h-6 text-indigo-600" />
            </div>
            <div>
                <h1 className="text-lg font-bold text-gray-800 leading-tight">आदर्श बाल विद्या मन्दिर</h1>
                <p className="text-xs text-gray-500 font-medium">छात्र डैशबोर्ड | {user.name}</p>
            </div>
        </div>
        <button onClick={onLogout} className="flex items-center space-x-2 bg-red-500 text-white px-4 py-2 rounded hover:bg-red-600">
          <LogoutIcon className="w-5 h-5" />
          <span className="hidden md:inline">लॉगआउट</span>
        </button>
      </header>

      <main className="p-6 max-w-6xl mx-auto">
        {/* Student Profile Summary */}
        <div className="bg-white p-6 rounded-lg shadow-md mb-6">
            <div className="flex flex-col md:flex-row items-center md:items-start space-y-4 md:space-y-0 md:space-x-6">
                <div className="w-24 h-24 rounded-full overflow-hidden border-4 border-indigo-100 shadow-sm flex-shrink-0">
                    {user.profilePicture ? (
                        <img src={user.profilePicture} alt={user.name} className="w-full h-full object-cover" />
                    ) : (
                        <div className="w-full h-full bg-indigo-50 flex items-center justify-center">
                            <UserIcon className="w-12 h-12 text-indigo-300" />
                        </div>
                    )}
                </div>
                <div className="flex-1 text-center md:text-left">
                    <h2 className="text-2xl font-bold text-gray-800">{user.name}</h2>
                    <div className="mt-2 grid grid-cols-1 sm:grid-cols-2 gap-x-8 gap-y-2 text-sm text-gray-600">
                        <p><span className="font-semibold">कक्षा:</span> {user.class}</p>
                        <p><span className="font-semibold">मोबाइल:</span> {user.mobile}</p>
                        <p><span className="font-semibold">पिता का नाम:</span> {user.fatherName}</p>
                        <p><span className="font-semibold">माता का नाम:</span> {user.motherName}</p>
                    </div>
                </div>
                 <div className="text-center bg-gray-50 p-4 rounded-lg border border-gray-100">
                    <p className="text-xs font-semibold text-gray-500 uppercase tracking-wide mb-1">आज की उपस्थिति</p>
                    <span className={`px-4 py-1.5 text-sm font-bold rounded-full ${todaysAttendance?.status === 'Present' ? 'bg-green-500 text-white shadow-green-200' : todaysAttendance?.status === 'Absent' ? 'bg-red-500 text-white shadow-red-200' : 'bg-gray-200 text-gray-600'}`}>
                        {todaysAttendance?.status === 'Present' ? 'उपस्थित' : todaysAttendance?.status === 'Absent' ? 'अनुपस्थित' : 'अचिह्नित'}
                    </span>
                 </div>
            </div>
        </div>

        {/* Navigation Tabs */}
        <div className="flex overflow-x-auto space-x-4 mb-6 pb-2">
            {[
                { id: 'homework', label: 'होमवर्क' },
                { id: 'gallery', label: 'Gallery (Media)' },
                { id: 'timetable', label: 'Time Table' },
                { id: 'attendance', label: 'उपस्थिति' },
                { id: 'results', label: 'Marksheet (Result)' },
                { id: 'notices', label: 'सूचनाएं' }
            ].map(tab => (
                <button
                    key={tab.id}
                    onClick={() => setActiveTab(tab.id)}
                    className={`px-6 py-2 rounded-full font-semibold whitespace-nowrap transition-all ${
                        activeTab === tab.id 
                        ? 'bg-indigo-600 text-white shadow-lg transform scale-105' 
                        : 'bg-white text-gray-600 hover:bg-gray-50'
                    }`}
                >
                    {tab.label}
                </button>
            ))}
        </div>

        {/* Tab Content */}
        <div className="animate-fade-in">
            {renderContent()}
        </div>
      </main>
    </div>
  );
};

export default StudentDashboard;
