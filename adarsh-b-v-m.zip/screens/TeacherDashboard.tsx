
import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { Teacher, Student, Attendance, Homework, Remark, Notice, TimetableEntry, Exam, ExamSchedule, ExamResult, Message, LeaveRequest, Payroll } from '../types';
import { api } from '../services/api';
import { LogoutIcon, SchoolIcon, ClockIcon, BellIcon, ChatBubbleIcon, SendIcon, UserIcon, PlusIcon, EditIcon, ReceiptIcon, PaperClipIcon, SearchIcon } from '../components/icons';
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';

interface TeacherDashboardProps {
  user: Teacher;
  onLogout: () => void;
}

const predefinedRemarks = [
  "Excellent work!",
  "Needs improvement in handwriting.",
  "Participated well in class.",
  "Late submission.",
  "Very creative approach.",
  "Please focus more during lessons.",
  "Great progress shown.",
  "Incomplete homework."
];

const TeacherDashboard: React.FC<TeacherDashboardProps> = ({ user, onLogout }) => {
  const [selectedClass, setSelectedClass] = useState<string>(user.assignedClasses[0] || '');
  const [students, setStudents] = useState<Student[]>([]);
  const [attendance, setAttendance] = useState<Attendance[]>([]);
  const [homeworks, setHomeworks] = useState<Homework[]>([]);
  const [remarks, setRemarks] = useState<Remark[]>([]);
  const [notices, setNotices] = useState<Notice[]>([]);
  const [activeTab, setActiveTab] = useState('students'); // Changed default to students for better visibility of new feature
  
  // Timetable
  const [myTimetable, setMyTimetable] = useState<TimetableEntry[]>([]);
  const [classTimetable, setClassTimetable] = useState<TimetableEntry[]>([]);

  // Exam Marks State
  const [exams, setExams] = useState<Exam[]>([]);
  const [selectedExamId, setSelectedExamId] = useState('');
  const [examSubjects, setExamSubjects] = useState<ExamSchedule[]>([]);
  const [selectedSubject, setSelectedSubject] = useState('');
  const [studentMarks, setStudentMarks] = useState<Record<string, number>>({});
  
  // Communication
  const [unreadCount, setUnreadCount] = useState(0);
  const [showNotifications, setShowNotifications] = useState(false);
  const [contacts, setContacts] = useState<{id: string, name: string, role: string, unread: number}[]>([]);
  const [selectedContact, setSelectedContact] = useState<string | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [newMessage, setNewMessage] = useState('');
  const [contactSearch, setContactSearch] = useState('');

  // HR States
  const [myLeaves, setMyLeaves] = useState<LeaveRequest[]>([]);
  const [myPayrolls, setMyPayrolls] = useState<Payroll[]>([]);
  const [newLeave, setNewLeave] = useState({ startDate: '', endDate: '', type: 'Sick', reason: '' });

  // Modal State
  const [homeworkModalOpen, setHomeworkModalOpen] = useState(false);
  const [remarkModalOpen, setRemarkModalOpen] = useState(false);
  const [remarkModalStudent, setRemarkModalStudent] = useState<Student | null>(null);
  
  // Student Details Modal State
  const [selectedStudentProfile, setSelectedStudentProfile] = useState<Student | null>(null);
  const [profileExamResults, setProfileExamResults] = useState<ExamResult[]>([]);
  
  // Form States
  const [newHomework, setNewHomework] = useState({ subject: '', details: '', dueDate: '' });
  const [newRemark, setNewRemark] = useState({ remark: '' });
  
  // File Upload State for Homework
  const [attachment, setAttachment] = useState<string>('');
  const [attachmentName, setAttachmentName] = useState<string>('');
  const [uploadingFile, setUploadingFile] = useState(false);

  const today = new Date().toISOString().split('T')[0];

  const fetchData = useCallback(async () => {
    if (!selectedClass) return;
    setStudents(await api.getStudentsByClass(selectedClass));
    setAttendance(await api.getAttendanceForClass(selectedClass, today));
    const allHomeworks = await api.getHomeworkForClass(selectedClass);
    setHomeworks(allHomeworks.sort((a,b) => new Date(b.date).getTime() - new Date(a.date).getTime()));
    setRemarks(await api.getRemarksForClass(selectedClass, today));
    setNotices(await api.getTeacherNotices());
    
    setMyTimetable(await api.getTimetableForTeacher(user.id));
    setClassTimetable(await api.getTimetableForClass(selectedClass));
    setExams(await api.getAllExams());
    
    setContacts(await api.getContacts(user.id, user.role));
    setUnreadCount(await api.getUnreadCount(user.id));

    // HR Data
    setMyLeaves(await api.getLeavesByEmployee(user.id));
    setMyPayrolls(await api.getEmployeePayrollHistory(user.id));

  }, [selectedClass, today, user.id, user.role]);

  useEffect(() => {
    fetchData();
    const interval = setInterval(fetchData, 10000);
    return () => clearInterval(interval);
  }, [fetchData]);

  // Load subjects when exam changes
  useEffect(() => {
    if(activeTab === 'marks' && selectedExamId && selectedClass) {
        api.getExamSchedules(selectedExamId, selectedClass).then(setExamSubjects);
        setSelectedSubject('');
        setStudentMarks({});
    }
  }, [activeTab, selectedExamId, selectedClass]);

  // Load marks when subject changes
  useEffect(() => {
    if(activeTab === 'marks' && selectedExamId && selectedClass && selectedSubject) {
        api.getExamResultsForClass(selectedExamId, selectedClass, selectedSubject).then(results => {
             const marksMap: Record<string, number> = {};
             results.forEach(r => marksMap[r.studentId] = r.marksObtained);
             setStudentMarks(marksMap);
        });
    }
  }, [selectedExamId, selectedClass, selectedSubject, activeTab]);

  // Chat logic
  useEffect(() => {
      if (selectedContact) {
          api.getMessages(user.id, selectedContact).then(setMessages);
          api.markMessagesAsRead(selectedContact, user.id).then(() => fetchData());
      }
  }, [selectedContact, user.id, fetchData]);

  const handleSendMessage = async (e: React.FormEvent) => {
      e.preventDefault();
      if (selectedContact && newMessage.trim()) {
          await api.sendMessage(user.id, selectedContact, newMessage);
          setNewMessage('');
          setMessages(await api.getMessages(user.id, selectedContact));
      }
  };
  
  // Helper to jump to chat
  const startChat = (contactId: string) => {
      // Ensure the contact exists in our contact list (it should if logic is correct)
      // Even if not visually in list (edge case), setting ID allows API to fetch msgs
      setSelectedContact(contactId);
      setActiveTab('messages');
  };
  
  // View Student Profile Handler
  const handleViewStudentProfile = async (student: Student) => {
      const results = await api.getStudentExamResults(student.id);
      setProfileExamResults(results);
      setSelectedStudentProfile(student);
  };

  const handleMarksChange = (studentId: string, val: string) => {
      setStudentMarks(prev => ({ ...prev, [studentId]: parseInt(val) || 0 }));
  };

  const handleSaveMarks = async () => {
      if(selectedExamId && selectedSubject) {
          const schedule = examSubjects.find(s => s.subject === selectedSubject);
          if(!schedule) return;
          
          for (const studentId of Object.keys(studentMarks)) {
              await api.saveExamResult(selectedExamId, studentId, selectedSubject, studentMarks[studentId], schedule.maxMarks);
          }
          alert("Marks saved successfully!");
      }
  };

  const handleSetAttendance = async (studentId: string, status: 'Present' | 'Absent') => {
    await api.setAttendance(studentId, today, status);
    fetchData();
  };
  
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
      const file = e.target.files?.[0];
      if (file) {
          if (file.size > 2 * 1024 * 1024) { // 2MB limit for storage safety
              alert("File size too large! Please select a file smaller than 2MB.");
              return;
          }
          setUploadingFile(true);
          const reader = new FileReader();
          reader.onload = (e) => {
              setAttachment(e.target?.result as string);
              setAttachmentName(file.name);
              setUploadingFile(false);
          };
          reader.readAsDataURL(file);
      }
  };

  const handleAddHomework = async (e: React.FormEvent) => {
    e.preventDefault();
    if(newHomework.subject && newHomework.details && selectedClass) {
        await api.addHomework(selectedClass, today, newHomework.subject, newHomework.details, newHomework.dueDate, user.id, attachment, attachmentName);
        
        // Reset Form
        setNewHomework({ subject: '', details: '', dueDate: '' });
        setAttachment('');
        setAttachmentName('');
        setHomeworkModalOpen(false);
        fetchData();
    }
  };
  
  const openRemarkModal = (student: Student) => {
    setRemarkModalStudent(student);
    setNewRemark({ remark: '' });
    setRemarkModalOpen(true);
  };

  const handleSaveRemark = async (e: React.FormEvent) => {
      e.preventDefault();
      if (remarkModalStudent && newRemark.remark) {
          await api.addRemark(remarkModalStudent.id, 'general', newRemark.remark, today);
          setRemarkModalOpen(false);
          setRemarkModalStudent(null);
          fetchData();
      }
  };

  const handleNotifyIncomplete = async () => {
      if (remarkModalStudent) {
          // 1. Save the remark to history
          await api.addRemark(remarkModalStudent.id, 'general', "Incomplete homework.", today);

          // 2. Notify Parent
          if (remarkModalStudent.parentId) {
              const message = "Your child has incomplete homework.";
              await api.sendMessage(user.id, remarkModalStudent.parentId, message);
              alert(`Remark saved and notification sent to ${remarkModalStudent.name}'s parent.`);
          } else {
              alert("Remark saved. Parent contact information is missing for this student.");
          }
          
          setRemarkModalOpen(false);
          setRemarkModalStudent(null);
          fetchData();
      }
  };

  const handleApplyLeave = async (e: React.FormEvent) => {
      e.preventDefault();
      
      if (!newLeave.reason.trim()) {
          alert("Please provide a reason for your leave request.");
          return;
      }

      if(newLeave.startDate && newLeave.endDate) {
          if (new Date(newLeave.endDate) < new Date(newLeave.startDate)) {
              alert("End date cannot be before start date.");
              return;
          }
          await api.applyLeave({
              employeeId: user.id,
              startDate: newLeave.startDate,
              endDate: newLeave.endDate,
              reason: newLeave.reason,
              type: newLeave.type as any
          });

          // Notify Principal about the new leave request
          const principal = contacts.find(c => c.role === 'Principal');
          if (principal) {
            await api.sendMessage(
                user.id, 
                principal.id, 
                `Leave Application: ${newLeave.type} leave from ${newLeave.startDate} to ${newLeave.endDate}.\nReason: ${newLeave.reason}`
            );
          }

          setNewLeave({ startDate: '', endDate: '', type: 'Sick', reason: '' });
          alert("Leave application submitted to Principal.");
          fetchData();
      } else {
          alert("Please select both start and end dates.");
      }
  };

  const handleDownloadSlip = (payroll: Payroll) => {
      const doc = new jsPDF();
      doc.setFontSize(22);
      doc.text("Adarsh Bal Vidya Mandir", 105, 20, { align: "center" });
      doc.setFontSize(12);
      doc.text("Salary Slip", 105, 30, { align: "center" });
      
      doc.setFontSize(10);
      doc.text(`Employee: ${user.name}`, 14, 45);
      doc.text(`Month: ${payroll.month}`, 150, 45);
      doc.text(`Status: ${payroll.status}`, 150, 50);
      if(payroll.paymentDate) doc.text(`Paid On: ${new Date(payroll.paymentDate).toLocaleDateString()}`, 150, 55);

      autoTable(doc, {
          startY: 60,
          head: [['Description', 'Amount']],
          body: [
              ['Basic Salary', `Rs. ${payroll.basicSalary}`],
              ['Allowances', `Rs. ${payroll.allowances}`],
              ['Deductions', `(Rs. ${payroll.deductions})`],
              [{ content: 'Net Salary', styles: { fontStyle: 'bold' } }, { content: `Rs. ${payroll.netSalary}`, styles: { fontStyle: 'bold' } }]
          ]
      });
      
      doc.save(`Salary_${user.name}_${payroll.month}.pdf`);
  };

  const leaveDuration = useMemo(() => {
      if (newLeave.startDate && newLeave.endDate) {
          const start = new Date(newLeave.startDate);
          const end = new Date(newLeave.endDate);
          if (end >= start) {
              const diffTime = Math.abs(end.getTime() - start.getTime());
              const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24)) + 1; 
              return diffDays;
          }
      }
      return 0;
  }, [newLeave.startDate, newLeave.endDate]);

  const getDaysCount = (start: string, end: string) => {
    const s = new Date(start);
    const e = new Date(end);
    return Math.ceil((e.getTime() - s.getTime()) / (1000 * 60 * 60 * 24)) + 1;
  };

  const renderContent = () => {
      switch(activeTab) {
        case 'students':
            return (
                <div className="bg-white p-6 rounded-lg shadow-md">
                    <div className="flex justify-between items-center mb-6">
                        <h3 className="text-xl font-bold text-gray-800">Student Directory (Class {selectedClass})</h3>
                    </div>
                    {students.length === 0 ? (
                        <div className="text-center text-gray-500 py-8">No students found in this class.</div>
                    ) : (
                        <div className="overflow-x-auto">
                            <table className="w-full text-left border-collapse">
                                <thead className="bg-gray-100">
                                    <tr>
                                        <th className="p-3 border-b">Roll</th>
                                        <th className="p-3 border-b">Name</th>
                                        <th className="p-3 border-b">Father's Name</th>
                                        <th className="p-3 border-b">Mobile</th>
                                        <th className="p-3 border-b text-right">Quick Actions</th>
                                    </tr>
                                </thead>
                                <tbody className="divide-y">
                                    {students.map((student, idx) => (
                                        <tr key={student.id} className="hover:bg-gray-50">
                                            <td className="p-3">{idx + 1}</td>
                                            <td 
                                              className="p-3 font-medium text-indigo-900 flex items-center cursor-pointer hover:text-indigo-600 transition"
                                              onClick={() => handleViewStudentProfile(student)}
                                            >
                                                <div className="w-8 h-8 rounded-full bg-indigo-100 flex items-center justify-center text-indigo-600 text-xs font-bold mr-2">
                                                    {student.name.charAt(0)}
                                                </div>
                                                <div className="underline decoration-dotted decoration-indigo-300 underline-offset-2">{student.name}</div>
                                            </td>
                                            <td className="p-3 text-gray-600">{student.fatherName}</td>
                                            <td className="p-3 text-gray-600 text-sm">{student.mobile}</td>
                                            <td className="p-3 text-right">
                                                <div className="flex justify-end space-x-2">
                                                    <button 
                                                        onClick={() => startChat(student.id)} 
                                                        className="flex items-center text-xs bg-blue-50 text-blue-700 px-3 py-1.5 rounded-full border border-blue-200 hover:bg-blue-100 transition"
                                                        title="Message Student"
                                                    >
                                                        <ChatBubbleIcon className="w-3 h-3 mr-1" /> Student
                                                    </button>
                                                    <button 
                                                        onClick={() => startChat(student.parentId)} 
                                                        className="flex items-center text-xs bg-green-50 text-green-700 px-3 py-1.5 rounded-full border border-green-200 hover:bg-green-100 transition"
                                                        title="Message Parent"
                                                    >
                                                        <ChatBubbleIcon className="w-3 h-3 mr-1" /> Parent
                                                    </button>
                                                </div>
                                            </td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        </div>
                    )}
                </div>
            );
        case 'hr':
            return (
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                    {/* Leave Application */}
                    <div className="space-y-6">
                        <div className="bg-white p-6 rounded-lg shadow border-t-4 border-indigo-600">
                            <h3 className="text-xl font-bold mb-4 flex items-center">
                                <span className="bg-indigo-100 p-2 rounded-full mr-3 text-indigo-600">
                                    <ClockIcon className="w-6 h-6" />
                                </span>
                                Apply for Leave
                            </h3>
                            <form onSubmit={handleApplyLeave} className="space-y-4">
                                <div className="grid grid-cols-2 gap-4">
                                    <div><label className="block text-xs font-bold mb-1 text-gray-600">Start Date</label><input type="date" value={newLeave.startDate} onChange={e => setNewLeave({...newLeave, startDate: e.target.value})} className="w-full p-2 border rounded focus:ring-2 focus:ring-indigo-200 focus:outline-none" required /></div>
                                    <div><label className="block text-xs font-bold mb-1 text-gray-600">End Date</label><input type="date" value={newLeave.endDate} onChange={e => setNewLeave({...newLeave, endDate: e.target.value})} className="w-full p-2 border rounded focus:ring-2 focus:ring-indigo-200 focus:outline-none" required /></div>
                                </div>
                                
                                {leaveDuration > 0 && (
                                    <div className="bg-blue-50 text-blue-700 px-3 py-2 rounded text-sm flex items-center">
                                        <ClockIcon className="w-4 h-4 mr-2" />
                                        Duration: <strong>{leaveDuration} Days</strong>
                                    </div>
                                )}

                                <div>
                                    <label className="block text-xs font-bold mb-1 text-gray-600">Leave Type</label>
                                    <select value={newLeave.type} onChange={e => setNewLeave({...newLeave, type: e.target.value})} className="w-full p-2 border rounded focus:ring-2 focus:ring-indigo-200 focus:outline-none">
                                        <option value="Sick">Sick Leave</option>
                                        <option value="Casual">Casual Leave</option>
                                        <option value="Emergency">Emergency Leave</option>
                                    </select>
                                </div>
                                <div>
                                    <label className="block text-xs font-bold mb-1 text-gray-600">Reason <span className="text-red-500">*</span></label>
                                    <textarea 
                                        value={newLeave.reason} 
                                        onChange={e => setNewLeave({...newLeave, reason: e.target.value})} 
                                        className="w-full p-2 border rounded focus:ring-2 focus:ring-indigo-200 focus:outline-none" 
                                        rows={3} 
                                        placeholder="Please describe the reason for your leave..." 
                                        required
                                    ></textarea>
                                </div>
                                <button type="submit" className="w-full bg-indigo-600 text-white py-2.5 rounded font-semibold hover:bg-indigo-700 transition shadow">Submit Application</button>
                            </form>
                        </div>

                        <div className="bg-white p-6 rounded-lg shadow">
                            <h3 className="text-lg font-bold mb-4 text-gray-800">Leave History</h3>
                            <div className="space-y-3 max-h-80 overflow-y-auto pr-1">
                                {myLeaves.length === 0 ? <div className="text-center py-8 text-gray-400">No leave applications found.</div> : myLeaves.map(leave => (
                                    <div key={leave.id} className="border border-gray-200 p-3 rounded-lg hover:bg-gray-50 transition">
                                        <div className="flex justify-between items-start mb-1">
                                            <span className={`text-xs font-bold px-2 py-1 rounded ${leave.type === 'Sick' ? 'bg-red-100 text-red-700' : leave.type === 'Casual' ? 'bg-blue-100 text-blue-700' : 'bg-yellow-100 text-yellow-700'}`}>{leave.type}</span>
                                            <span className={`text-xs px-2 py-1 rounded font-bold ${leave.status === 'Approved' ? 'bg-green-100 text-green-800' : leave.status === 'Rejected' ? 'bg-red-100 text-red-800' : 'bg-gray-200 text-gray-700'}`}>{leave.status}</span>
                                        </div>
                                        <div className="text-sm font-medium text-gray-800 mt-2">{new Date(leave.startDate).toLocaleDateString()} - {new Date(leave.endDate).toLocaleDateString()}</div>
                                        <div className="text-xs text-gray-500 mt-0.5">{getDaysCount(leave.startDate, leave.endDate)} Days</div>
                                        <p className="text-xs text-gray-600 mt-2 italic bg-white p-2 rounded border border-gray-100">"{leave.reason}"</p>
                                    </div>
                                ))}
                            </div>
                        </div>
                    </div>

                    {/* Salary History */}
                    <div className="bg-white p-6 rounded-lg shadow h-fit">
                        <h3 className="text-xl font-bold mb-4 text-gray-800 flex items-center"><ReceiptIcon className="w-6 h-6 mr-2 text-green-600"/> Salary History</h3>
                        <div className="overflow-x-auto">
                            <table className="w-full text-left">
                                <thead className="bg-gray-100 text-sm text-gray-600"><tr><th className="p-3 rounded-l">Month</th><th className="p-3">Net Pay</th><th className="p-3">Status</th><th className="p-3 rounded-r">Slip</th></tr></thead>
                                <tbody className="divide-y">
                                    {myPayrolls.map(p => (
                                        <tr key={p.id} className="hover:bg-gray-50">
                                            <td className="p-3 font-medium">{p.month}</td>
                                            <td className="p-3 font-bold text-gray-800">₹{p.netSalary.toLocaleString('en-IN')}</td>
                                            <td className="p-3"><span className={`text-xs px-2 py-1 rounded-full font-bold ${p.status === 'Paid' ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'}`}>{p.status}</span></td>
                                            <td className="p-3">
                                                {p.status === 'Paid' && <button onClick={() => handleDownloadSlip(p)} className="text-indigo-600 hover:bg-indigo-100 p-1.5 rounded transition" title="Download Slip"><ReceiptIcon className="w-5 h-5" /></button>}
                                            </td>
                                        </tr>
                                    ))}
                                    {myPayrolls.length === 0 && <tr><td colSpan={4} className="p-6 text-center text-gray-400">No payroll records found.</td></tr>}
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            );
        case 'messages':
              const filteredContacts = contacts.filter(c => 
                  c.name.toLowerCase().includes(contactSearch.toLowerCase()) || 
                  c.role.toLowerCase().includes(contactSearch.toLowerCase())
              );

              return (
                  <div className="flex h-[600px] bg-white rounded-lg shadow overflow-hidden">
                      <div className="w-1/3 border-r bg-gray-50 flex flex-col">
                          <div className="p-4 border-b bg-white">
                              <h3 className="font-bold text-gray-700 mb-3">Contacts</h3>
                              <div className="relative">
                                  <input 
                                      type="text" 
                                      placeholder="Search students, parents..." 
                                      className="w-full pl-9 p-2 bg-gray-100 border-transparent focus:bg-white focus:border-indigo-300 focus:ring-0 rounded-lg text-sm transition-colors"
                                      value={contactSearch}
                                      onChange={e => setContactSearch(e.target.value)}
                                  />
                                  <SearchIcon className="w-4 h-4 text-gray-400 absolute left-3 top-2.5" />
                              </div>
                          </div>
                          <div className="flex-1 overflow-y-auto">
                              {filteredContacts.length === 0 && (
                                  <div className="p-4 text-center text-gray-400 text-sm">No contacts found</div>
                              )}
                              {filteredContacts.map(c => (
                                  <div key={c.id} onClick={() => setSelectedContact(c.id)} className={`p-4 border-b cursor-pointer hover:bg-gray-100 ${selectedContact === c.id ? 'bg-indigo-50' : ''}`}>
                                      <div className="flex justify-between items-center">
                                          <div><p className="font-semibold text-gray-800">{c.name}</p><p className="text-xs text-gray-500">{c.role}</p></div>
                                          {c.unread > 0 && <span className="bg-red-500 text-white text-xs rounded-full px-2 py-1">{c.unread}</span>}
                                      </div>
                                  </div>
                              ))}
                          </div>
                      </div>
                      <div className="w-2/3 flex flex-col">
                          {selectedContact ? (
                              <>
                                  <div className="p-4 border-b bg-white flex items-center"><UserIcon className="w-8 h-8 text-gray-400 mr-2" /><h3 className="font-bold text-gray-800">{contacts.find(c => c.id === selectedContact)?.name}</h3></div>
                                  <div className="flex-1 p-4 overflow-y-auto space-y-3 bg-gray-100">
                                      {messages.map(msg => {
                                          const isMe = msg.senderId === user.id;
                                          return (
                                              <div key={msg.id} className={`flex ${isMe ? 'justify-end' : 'justify-start'}`}>
                                                  <div className={`max-w-[70%] p-3 rounded-lg shadow-sm ${isMe ? 'bg-indigo-100 text-indigo-900' : 'bg-white text-gray-800'}`}>
                                                      <p>{msg.content}</p>
                                                      <p className="text-[10px] text-gray-500 text-right mt-1">{new Date(msg.timestamp).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}</p>
                                                  </div>
                                              </div>
                                          );
                                      })}
                                  </div>
                                  <form onSubmit={handleSendMessage} className="p-4 bg-white border-t flex gap-2">
                                      <input type="text" value={newMessage} onChange={e => setNewMessage(e.target.value)} placeholder="Type a message..." className="flex-1 p-2 border rounded-full px-4 focus:outline-none focus:ring-2 focus:ring-indigo-500" />
                                      <button type="submit" className="bg-indigo-600 text-white p-2 rounded-full hover:bg-indigo-700"><SendIcon className="w-5 h-5" /></button>
                                  </form>
                              </>
                          ) : (
                              <div className="flex-1 flex flex-col items-center justify-center text-gray-400"><ChatBubbleIcon className="w-16 h-16 mb-2" /><p>Select a contact to start chatting</p></div>
                          )}
                      </div>
                  </div>
              );
        case 'attendance':
              return (
                  <div className="bg-white p-6 rounded-lg shadow-md">
                      <div className="flex justify-between items-center mb-4">
                          <h3 className="text-xl font-bold text-gray-800">Attendance ({today})</h3>
                          <div className="text-sm"><span className="font-bold text-green-600">P</span>: Present, <span className="font-bold text-red-600">A</span>: Absent</div>
                      </div>
                      <table className="w-full text-left border-collapse">
                          <thead className="bg-gray-100"><tr><th className="p-3">Roll No</th><th className="p-3">Name</th><th className="p-3 text-center">Status</th><th className="p-3 text-right">Action</th></tr></thead>
                          <tbody className="divide-y">
                              {students.map((student, index) => {
                                  const status = attendance.find(a => a.studentId === student.id)?.status;
                                  return (
                                      <tr key={student.id}>
                                          <td className="p-3">{index + 1}</td>
                                          <td 
                                              className="p-3 font-medium text-indigo-900 cursor-pointer hover:text-indigo-600 transition"
                                              onClick={() => handleViewStudentProfile(student)}
                                          >
                                              <span className="border-b border-dotted border-indigo-400">{student.name}</span>
                                          </td>
                                          <td className="p-3 text-center"><span className={`px-3 py-1 rounded-full text-xs font-bold ${status === 'Present' ? 'bg-green-100 text-green-800' : status === 'Absent' ? 'bg-red-100 text-red-800' : 'bg-gray-100 text-gray-600'}`}>{status || 'Not Marked'}</span></td>
                                          <td className="p-3 text-right flex justify-end items-center">
                                              <button onClick={() => handleSetAttendance(student.id, 'Present')} className={`mr-2 px-3 py-1 rounded ${status === 'Present' ? 'bg-green-600 text-white' : 'bg-gray-200 hover:bg-green-200'}`}>P</button>
                                              <button onClick={() => handleSetAttendance(student.id, 'Absent')} className={`px-3 py-1 rounded ${status === 'Absent' ? 'bg-red-600 text-white' : 'bg-gray-200 hover:bg-red-200'}`}>A</button>
                                              <button 
                                                  onClick={() => startChat(student.parentId)} 
                                                  className="ml-3 p-1.5 rounded-full text-indigo-400 hover:bg-indigo-50 hover:text-indigo-600"
                                                  title="Message Parent regarding attendance"
                                              >
                                                  <ChatBubbleIcon className="w-4 h-4" />
                                              </button>
                                          </td>
                                      </tr>
                                  );
                              })}
                          </tbody>
                      </table>
                  </div>
              );
        case 'homework':
              return (
                  <div>
                      <div className="flex justify-between items-center mb-4">
                          <h3 className="text-xl font-bold text-gray-800">Homework History</h3>
                          <button onClick={() => setHomeworkModalOpen(true)} className="bg-indigo-600 text-white px-4 py-2 rounded flex items-center shadow hover:bg-indigo-700"><PlusIcon className="w-5 h-5 mr-2" /> Add Homework</button>
                      </div>
                      <div className="space-y-4">
                          {homeworks.map(hw => (
                              <div key={hw.id} className="bg-white p-4 rounded shadow border-l-4 border-indigo-500">
                                  <div className="flex justify-between">
                                      <h4 className="font-bold text-lg">{hw.subject}</h4>
                                      <span className="text-sm text-gray-500">{new Date(hw.date).toLocaleDateString()}</span>
                                  </div>
                                  <p className="text-gray-700 mt-1">{hw.details}</p>
                                  {hw.attachment && (
                                    <div className="mt-2">
                                        <a href={hw.attachment} download={hw.attachmentName || 'download'} className="text-indigo-600 hover:underline text-sm flex items-center">
                                            <PaperClipIcon className="w-4 h-4 mr-1" /> {hw.attachmentName || 'View Attachment'}
                                        </a>
                                    </div>
                                  )}
                                  {hw.dueDate && <p className="text-xs text-red-500 mt-2 font-medium">Due: {new Date(hw.dueDate).toLocaleDateString()}</p>}
                              </div>
                          ))}
                      </div>
                  </div>
              );
        case 'remarks':
              return (
                  <div className="bg-white p-6 rounded-lg shadow-md">
                      <h3 className="text-xl font-bold mb-4">Student Remarks</h3>
                      <table className="w-full text-left">
                          <thead className="bg-gray-100"><tr><th className="p-3">Name</th><th className="p-3">Recent Remark</th><th className="p-3 text-right">Action</th></tr></thead>
                          <tbody className="divide-y">
                              {students.map(student => {
                                  const studentRemark = remarks.find(r => r.studentId === student.id);
                                  return (
                                      <tr key={student.id}>
                                          <td 
                                              className="p-3 font-medium text-indigo-900 cursor-pointer hover:text-indigo-600 transition"
                                              onClick={() => handleViewStudentProfile(student)}
                                          >
                                              {student.name}
                                          </td>
                                          <td className="p-3 text-sm text-gray-600">{studentRemark ? studentRemark.remark : '-'}</td>
                                          <td className="p-3 text-right">
                                              <button onClick={() => openRemarkModal(student)} className="text-indigo-600 hover:bg-indigo-50 p-2 rounded"><EditIcon className="w-4 h-4" /></button>
                                          </td>
                                      </tr>
                                  );
                              })}
                          </tbody>
                      </table>
                  </div>
              );
        case 'marks':
              return (
                  <div className="bg-white p-6 rounded-lg shadow-md">
                      <h3 className="text-xl font-bold mb-6">Exam Marks Entry</h3>
                      <div className="flex space-x-4 mb-6">
                          <div className="flex-1">
                              <label className="block text-sm font-medium text-gray-700 mb-1">Select Exam</label>
                              <select value={selectedExamId} onChange={e => setSelectedExamId(e.target.value)} className="w-full p-2 border rounded">
                                  <option value="">-- Choose Exam --</option>
                                  {exams.filter(e => e.status !== 'Completed').map(e => <option key={e.id} value={e.id}>{e.name}</option>)}
                              </select>
                          </div>
                          <div className="flex-1">
                              <label className="block text-sm font-medium text-gray-700 mb-1">Select Subject</label>
                              <select value={selectedSubject} onChange={e => setSelectedSubject(e.target.value)} className="w-full p-2 border rounded" disabled={!selectedExamId}>
                                  <option value="">-- Choose Subject --</option>
                                  {examSubjects.map(s => <option key={s.subject} value={s.subject}>{s.subject} (Max: {s.maxMarks})</option>)}
                              </select>
                          </div>
                      </div>

                      {selectedExamId && selectedSubject && (
                          <div className="animate-fade-in">
                              <table className="w-full text-left border mb-4">
                                  <thead className="bg-gray-100"><tr><th className="p-3">Student Name</th><th className="p-3 w-32">Marks Obtained</th><th className="p-3">Max Marks</th></tr></thead>
                                  <tbody className="divide-y">
                                      {students.map(student => (
                                          <tr key={student.id}>
                                              <td 
                                                  className="p-3 font-medium text-indigo-900 cursor-pointer hover:text-indigo-600 transition"
                                                  onClick={() => handleViewStudentProfile(student)}
                                              >
                                                  {student.name}
                                              </td>
                                              <td className="p-3">
                                                  <input 
                                                      type="number" 
                                                      value={studentMarks[student.id] || ''} 
                                                      onChange={(e) => handleMarksChange(student.id, e.target.value)}
                                                      className="w-full p-1 border rounded text-center"
                                                      max={examSubjects.find(s => s.subject === selectedSubject)?.maxMarks}
                                                  />
                                              </td>
                                              <td className="p-3 text-gray-500">{examSubjects.find(s => s.subject === selectedSubject)?.maxMarks}</td>
                                          </tr>
                                      ))}
                                  </tbody>
                              </table>
                              <div className="text-right">
                                  <button onClick={handleSaveMarks} className="bg-green-600 text-white px-6 py-2 rounded shadow hover:bg-green-700">Save Marks</button>
                              </div>
                          </div>
                      )}
                      {(!selectedExamId || !selectedSubject) && <div className="text-center py-10 text-gray-400">Please select an exam and subject to enter marks.</div>}
                  </div>
              );
        case 'timetable':
              return (
                  <div className="space-y-6">
                      <div className="bg-white p-6 rounded-lg shadow-md">
                          <h3 className="text-xl font-bold mb-4">My Timetable</h3>
                          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                              {myTimetable.map(t => (
                                  <div key={t.id} className="bg-indigo-50 p-3 rounded border border-indigo-100">
                                      <div className="font-bold text-indigo-800">{t.day} - Period {t.period}</div>
                                      <div className="text-gray-700">{t.subject} ({t.class})</div>
                                      <div className="text-xs text-gray-500">{t.startTime} - {t.endTime}</div>
                                  </div>
                              ))}
                              {myTimetable.length === 0 && <p className="text-gray-500">No classes assigned.</p>}
                          </div>
                      </div>
                      <div className="bg-white p-6 rounded-lg shadow-md">
                          <h3 className="text-xl font-bold mb-4">Class Timetable ({selectedClass})</h3>
                          <div className="overflow-x-auto">
                             <table className="w-full border-collapse border">
                                 <thead>
                                     <tr className="bg-gray-100"><th className="p-2 border">Day</th>{[1,2,3,4,5,6,7,8].map(p=><th key={p} className="p-2 border">{p}</th>)}</tr>
                                 </thead>
                                 <tbody>
                                     {['Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'].map(day => (
                                         <tr key={day}><td className="p-2 border font-bold">{day}</td>
                                             {[1,2,3,4,5,6,7,8].map(p => {
                                                 const entry = classTimetable.find(t => t.day === day && t.period === p);
                                                 return <td key={p} className="p-2 border text-center text-xs">{entry ? entry.subject : '-'}</td>
                                             })}
                                         </tr>
                                     ))}
                                 </tbody>
                             </table>
                          </div>
                      </div>
                  </div>
              );
        case 'notices':
              return (
                  <div className="bg-white p-6 rounded-lg shadow-md">
                      <h3 className="text-xl font-bold mb-4">Notices</h3>
                      <div className="space-y-4">
                          {notices.map(n => (
                              <div key={n.id} className="p-4 border border-gray-200 rounded hover:shadow-sm">
                                  <div className="flex justify-between"><h4 className="font-bold text-lg">{n.title}</h4><span className="text-sm text-gray-500">{new Date(n.date).toLocaleDateString()}</span></div>
                                  <p className="text-gray-700 mt-1">{n.content}</p>
                              </div>
                          ))}
                          {notices.length === 0 && <p className="text-gray-500">No notices.</p>}
                      </div>
                  </div>
              );
        default: return null;
      }
  };

  return (
    <div className="min-h-screen bg-gray-100">
      <header className="bg-white shadow-md p-4 flex justify-between items-center sticky top-0 z-20">
        <div className="flex items-center space-x-3">
            <SchoolIcon className="w-8 h-8 text-indigo-600" />
            <div>
                <h1 className="text-lg font-bold">आदर्श बाल विद्या मन्दिर</h1>
                <p className="text-xs text-gray-500">Teacher Dashboard | {user.name}</p>
            </div>
        </div>
        
        <div className="flex items-center space-x-4">
            <select value={selectedClass} onChange={e => setSelectedClass(e.target.value)} className="p-2 border rounded bg-indigo-50 text-indigo-700 font-medium focus:outline-none focus:ring-2 focus:ring-indigo-500">
                {user.assignedClasses.map(cls => <option key={cls} value={cls}>Class {cls}</option>)}
            </select>
            
            <div className="relative">
                <button onClick={() => setShowNotifications(!showNotifications)} className="relative text-gray-600 hover:text-indigo-600">
                    <BellIcon className="w-6 h-6" />
                    {unreadCount > 0 && <span className="absolute -top-1 -right-1 bg-red-500 text-white text-[10px] w-4 h-4 flex items-center justify-center rounded-full">{unreadCount}</span>}
                </button>
                {showNotifications && (
                    <div className="absolute right-0 mt-2 w-64 bg-white rounded shadow-xl border z-50 p-2">
                        <p className="text-sm font-bold text-gray-700 border-b pb-1 mb-1">Notifications</p>
                        {unreadCount > 0 ? <div className="p-2 text-sm cursor-pointer hover:bg-gray-50 text-indigo-600" onClick={() => {setActiveTab('messages'); setShowNotifications(false);}}>You have {unreadCount} new messages.</div> : <div className="p-2 text-sm text-gray-500">No new notifications</div>}
                    </div>
                )}
            </div>

            <button onClick={onLogout} className="bg-red-50 text-red-600 p-2 rounded hover:bg-red-100"><LogoutIcon className="w-5 h-5" /></button>
        </div>
      </header>

      <main className="p-6">
          <div className="flex overflow-x-auto space-x-2 mb-6 bg-white p-2 rounded shadow">
              {[
                  {id: 'students', label: 'Student Directory'},
                  {id: 'attendance', label: 'Attendance'},
                  {id: 'homework', label: 'Homework'},
                  {id: 'marks', label: 'Exam Marks'},
                  {id: 'hr', label: 'HR / Leave'},
                  {id: 'remarks', label: 'Remarks'},
                  {id: 'timetable', label: 'Timetable'},
                  {id: 'messages', label: 'Messages'},
                  {id: 'notices', label: 'Notices'}
              ].map(tab => (
                  <button key={tab.id} onClick={() => setActiveTab(tab.id)} className={`px-4 py-2 rounded whitespace-nowrap font-medium ${activeTab === tab.id ? 'bg-indigo-600 text-white' : 'text-gray-600 hover:bg-gray-100'}`}>
                      {tab.label} {tab.id === 'messages' && unreadCount > 0 && `(${unreadCount})`}
                  </button>
              ))}
          </div>
          
          {renderContent()}
      </main>

      {/* Modals */}
      {homeworkModalOpen && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-50 px-4">
              <div className="bg-white p-6 rounded-lg shadow-xl w-full max-w-md">
                  <h2 className="text-xl font-bold mb-4">Add Homework for Class {selectedClass}</h2>
                  <form onSubmit={handleAddHomework}>
                      <div className="mb-4"><label className="block text-sm font-medium">Subject</label><input type="text" value={newHomework.subject} onChange={e => setNewHomework({...newHomework, subject: e.target.value})} className="w-full p-2 border rounded" required /></div>
                      <div className="mb-4"><label className="block text-sm font-medium">Details</label><textarea value={newHomework.details} onChange={e => setNewHomework({...newHomework, details: e.target.value})} className="w-full p-2 border rounded" rows={3} required></textarea></div>
                      
                      <div className="mb-4">
                          <label className="block text-sm font-medium">Attachment (Optional)</label>
                          <div className="flex items-center mt-1">
                              <label className="cursor-pointer bg-gray-100 hover:bg-gray-200 text-gray-700 py-2 px-4 rounded border flex items-center">
                                  <PaperClipIcon className="w-4 h-4 mr-2" /> {attachmentName ? 'Change File' : 'Select File'}
                                  <input type="file" className="hidden" onChange={handleFileUpload} accept=".pdf,.doc,.docx,.jpg,.jpeg,.png" disabled={uploadingFile} />
                              </label>
                              {attachmentName && <span className="ml-3 text-sm text-gray-600 truncate max-w-[150px]">{attachmentName}</span>}
                          </div>
                          {uploadingFile && <p className="text-xs text-blue-500 mt-1">Uploading...</p>}
                      </div>

                      <div className="mb-6"><label className="block text-sm font-medium">Due Date</label><input type="date" value={newHomework.dueDate} onChange={e => setNewHomework({...newHomework, dueDate: e.target.value})} className="w-full p-2 border rounded" /></div>
                      <div className="flex justify-end space-x-2"><button type="button" onClick={() => setHomeworkModalOpen(false)} className="px-4 py-2 border rounded">Cancel</button><button type="submit" className="px-4 py-2 bg-indigo-600 text-white rounded" disabled={uploadingFile}>Add</button></div>
                  </form>
              </div>
          </div>
      )}
      
      {remarkModalOpen && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-50 px-4">
              <div className="bg-white p-6 rounded-lg shadow-xl w-full max-w-md">
                  <h2 className="text-xl font-bold mb-4">Add Remark for {remarkModalStudent?.name}</h2>
                  <form onSubmit={handleSaveRemark}>
                      <div className="mb-4">
                          <label className="block text-sm font-medium mb-2">Quick Select:</label>
                          <div className="flex flex-wrap gap-2">
                              {predefinedRemarks.map((rem, idx) => (
                                  <button 
                                    type="button" 
                                    key={idx} 
                                    onClick={() => setNewRemark({ ...newRemark, remark: rem })}
                                    className="text-xs bg-indigo-50 text-indigo-700 px-3 py-1 rounded-full hover:bg-indigo-100 border border-indigo-200"
                                  >
                                      {rem}
                                  </button>
                              ))}
                          </div>
                      </div>
                      <div className="mb-6">
                          <label className="block text-sm font-medium">Remark</label>
                          <textarea value={newRemark.remark} onChange={e => setNewRemark({...newRemark, remark: e.target.value})} className="w-full p-2 border rounded" rows={3} placeholder="e.g. Good progress in Math" required></textarea>
                          <div className="mt-2 flex justify-end">
                             <button 
                                type="button" 
                                onClick={handleNotifyIncomplete} 
                                className="text-xs bg-orange-50 text-orange-600 px-3 py-1.5 rounded border border-orange-200 hover:bg-orange-100 flex items-center transition"
                                title="Send 'Incomplete Homework' alert to parent"
                             >
                                <BellIcon className="w-3 h-3 mr-1" /> Notify Parent: Incomplete Homework
                             </button>
                          </div>
                      </div>
                      <div className="flex justify-end space-x-2"><button type="button" onClick={() => setRemarkModalOpen(false)} className="px-4 py-2 border rounded">Cancel</button><button type="submit" className="px-4 py-2 bg-indigo-600 text-white rounded">Save</button></div>
                  </form>
              </div>
          </div>
      )}

      {/* Student Details Modal */}
      {selectedStudentProfile && (
          <div className="fixed inset-0 bg-black bg-opacity-60 flex justify-center items-center z-50 p-4">
              <div className="bg-white rounded-xl shadow-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto">
                  <div className="flex justify-between items-center p-6 bg-indigo-600 text-white">
                      <div className="flex items-center space-x-4">
                          <div className="w-16 h-16 bg-white rounded-full flex items-center justify-center border-2 border-indigo-300 overflow-hidden">
                              {selectedStudentProfile.profilePicture ? (
                                  <img src={selectedStudentProfile.profilePicture} alt="Profile" className="w-full h-full object-cover" />
                              ) : (
                                  <span className="text-2xl font-bold text-indigo-600">{selectedStudentProfile.name.charAt(0)}</span>
                              )}
                          </div>
                          <div>
                              <h2 className="text-2xl font-bold">{selectedStudentProfile.name}</h2>
                              <p className="text-indigo-100">Class {selectedStudentProfile.class} | Roll No: {selectedStudentProfile.id.substring(0,4).toUpperCase()}</p>
                          </div>
                      </div>
                      <button 
                          onClick={() => setSelectedStudentProfile(null)}
                          className="text-white hover:bg-indigo-700 p-2 rounded-full transition"
                      >
                          <span className="text-2xl">&times;</span>
                      </button>
                  </div>

                  <div className="p-6">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
                          <div className="space-y-3">
                              <h4 className="font-bold text-gray-500 text-sm uppercase border-b pb-1">Personal Details</h4>
                              <div className="grid grid-cols-3 gap-2 text-sm">
                                  <span className="text-gray-500">Father:</span>
                                  <span className="col-span-2 font-medium text-gray-800">{selectedStudentProfile.fatherName}</span>
                                  
                                  <span className="text-gray-500">Mother:</span>
                                  <span className="col-span-2 font-medium text-gray-800">{selectedStudentProfile.motherName}</span>
                                  
                                  <span className="text-gray-500">Gender:</span>
                                  <span className="col-span-2 font-medium text-gray-800">{selectedStudentProfile.gender}</span>
                                  
                                  <span className="text-gray-500">Mobile:</span>
                                  <span className="col-span-2 font-medium text-gray-800">{selectedStudentProfile.mobile}</span>
                              </div>
                          </div>
                          
                          <div className="space-y-3">
                              <h4 className="font-bold text-gray-500 text-sm uppercase border-b pb-1">Actions</h4>
                              <div className="flex space-x-2">
                                  <button 
                                      onClick={() => { startChat(selectedStudentProfile.id); setSelectedStudentProfile(null); }}
                                      className="flex-1 bg-blue-50 text-blue-700 py-2 rounded border border-blue-200 hover:bg-blue-100 transition flex justify-center items-center text-sm font-medium"
                                  >
                                      <ChatBubbleIcon className="w-4 h-4 mr-2" /> Message Student
                                  </button>
                                  <button 
                                      onClick={() => { startChat(selectedStudentProfile.parentId); setSelectedStudentProfile(null); }}
                                      className="flex-1 bg-green-50 text-green-700 py-2 rounded border border-green-200 hover:bg-green-100 transition flex justify-center items-center text-sm font-medium"
                                  >
                                      <ChatBubbleIcon className="w-4 h-4 mr-2" /> Message Parent
                                  </button>
                              </div>
                          </div>
                      </div>

                      <div>
                          <h4 className="font-bold text-gray-800 text-lg mb-4 flex items-center">
                              <ReceiptIcon className="w-5 h-5 mr-2 text-indigo-600" /> Academic Performance
                          </h4>
                          {profileExamResults.length > 0 ? (
                              <div className="overflow-hidden rounded-lg border border-gray-200">
                                  <table className="w-full text-left text-sm">
                                      <thead className="bg-gray-50">
                                          <tr>
                                              <th className="p-3 border-b font-semibold text-gray-600">Subject</th>
                                              <th className="p-3 border-b font-semibold text-gray-600 text-center">Marks</th>
                                              <th className="p-3 border-b font-semibold text-gray-600 text-center">Max</th>
                                              <th className="p-3 border-b font-semibold text-gray-600 text-center">Grade</th>
                                          </tr>
                                      </thead>
                                      <tbody className="divide-y divide-gray-100">
                                          {profileExamResults.map((res, idx) => (
                                              <tr key={idx} className="hover:bg-gray-50">
                                                  <td className="p-3 font-medium text-gray-800">{res.subject}</td>
                                                  <td className="p-3 text-center font-bold text-indigo-600">{res.marksObtained}</td>
                                                  <td className="p-3 text-center text-gray-500">{res.maxMarks}</td>
                                                  <td className="p-3 text-center">
                                                      <span className={`px-2 py-0.5 rounded text-xs font-bold ${['A+', 'A'].includes(res.grade) ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-700'}`}>
                                                          {res.grade}
                                                      </span>
                                                  </td>
                                              </tr>
                                          ))}
                                      </tbody>
                                  </table>
                              </div>
                          ) : (
                              <div className="text-center py-6 bg-gray-50 rounded border border-dashed border-gray-300 text-gray-500 text-sm">
                                  No exam results found for this student.
                              </div>
                          )}
                      </div>
                  </div>
                  <div className="bg-gray-50 p-4 flex justify-end border-t">
                      <button 
                          onClick={() => setSelectedStudentProfile(null)} 
                          className="bg-gray-200 hover:bg-gray-300 text-gray-800 px-6 py-2 rounded font-medium transition"
                      >
                          Close
                      </button>
                  </div>
              </div>
          </div>
      )}
    </div>
  );
};

export default TeacherDashboard;
