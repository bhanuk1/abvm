import React, { useState, useEffect } from 'react';
import { UserRole, LoggedInUser, Notice } from '../types';
import { api, SCHOOL_LOGO_URL } from '../services/api';
import { UserIcon, LockIcon, WhatsAppIcon, BellIcon, DownloadIcon } from '../components/icons';

interface LoginScreenProps {
  onLogin: (user: LoggedInUser) => void;
}

const LoginScreen: React.FC<LoginScreenProps> = ({ onLogin }) => {
  const [selectedRole, setSelectedRole] = useState<UserRole>(UserRole.TEACHER);
  const [mobile, setMobile] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [notices, setNotices] = useState<Notice[]>([]);
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);
  const [isInstallable, setIsInstallable] = useState(false);

  useEffect(() => {
    const fetchNotices = async () => {
      try {
         const publicNotices = await api.getPublicNotices();
         setNotices(publicNotices);
      } catch(e) {
         console.log("Failed to fetch notices on login screen (likely permission issue until logged in)");
      }
    };
    fetchNotices();

    // PWA Install Prompt Listener
    const handleBeforeInstallPrompt = (e: any) => {
      e.preventDefault();
      setDeferredPrompt(e);
      setIsInstallable(true);
    };

    window.addEventListener('beforeinstallprompt', handleBeforeInstallPrompt);

    return () => {
      window.removeEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
    };
  }, []);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    const loginPromise = api.login(mobile.trim(), password.trim(), selectedRole);
    
    // Matches API timeout
    const timeoutPromise = new Promise((_, reject) => {
        setTimeout(() => reject(new Error("Connection Timeout")), 31000);
    });

    try {
      if (!navigator.onLine) {
          throw new Error("इंटरनेट कनेक्शन नहीं है। कृपया नेट ऑन करें। (No Internet)");
      }

      // Race against timeout
      const user = await Promise.race([loginPromise, timeoutPromise]) as LoggedInUser;
      
      if (user) {
        onLogin(user);
      } else {
        setError('अमान्य मोबाइल नंबर या पासवर्ड।');
      }
    } catch (err: any) {
      console.error("Login Screen Error:", err);
      
      let msg = "अज्ञात त्रुटि (Unknown Error)";
      
      if (err.message === "Connection Timeout" || err.message === "DB_TIMEOUT") {
          msg = "सर्वर से कनेक्ट होने में समस्या आ रही है। कृपया इंटरनेट कनेक्शन चेक करें।";
      } else if (err.message) {
          msg = err.message;
      } else if (typeof err === 'string') {
          msg = err;
      } else if (err.code) {
          msg = `Firebase Error: ${err.code}`;
      }
      
      setError(msg);
    } finally {
      setLoading(false);
    }
  };

  const handleInstallClick = () => {
    if (deferredPrompt) {
      deferredPrompt.prompt();
      deferredPrompt.userChoice.then((choiceResult: any) => {
        if (choiceResult.outcome === 'accepted') {
          console.log('User accepted the install prompt');
        } else {
          console.log('User dismissed the install prompt');
        }
        setDeferredPrompt(null);
        setIsInstallable(false);
      });
    }
  };

  const roles = [
    { id: UserRole.TEACHER, label: 'टीचर' },
    { id: UserRole.PARENT, label: 'पेरेंट' },
    { id: UserRole.STUDENT, label: 'छात्र' },
    { id: UserRole.PRINCIPAL, label: 'प्रिंसिपल' },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-100 to-indigo-200 flex flex-col md:flex-row items-center justify-center p-4">
      <div className="w-full md:w-1/2 lg:w-2/5 p-8">
        <div className="bg-white rounded-2xl shadow-2xl p-8 max-w-md mx-auto relative">
          
          {isInstallable && (
             <button 
               onClick={handleInstallClick}
               className="absolute top-4 right-4 bg-indigo-600 text-white px-3 py-1 rounded-full shadow-lg hover:bg-indigo-700 transition flex items-center text-sm font-bold animate-pulse"
               title="Install App on Phone"
             >
               <DownloadIcon className="w-4 h-4 mr-1" /> Install App
             </button>
          )}

          <div className="text-center mb-8">
            <div className="flex justify-center items-center mb-6">
              <div className="bg-indigo-50 p-4 rounded-full shadow-lg ring-4 ring-indigo-50 w-28 h-28 flex items-center justify-center overflow-hidden">
                <img 
                  src={SCHOOL_LOGO_URL} 
                  alt="School Logo" 
                  className="w-full h-full object-contain"
                />
              </div>
            </div>
            <h1 className="text-3xl font-bold text-gray-900 tracking-tight">आदर्श बाल विद्या मन्दिर</h1>
            <p className="text-gray-600 mt-2 font-medium">बिलग्राम - हरदोई</p>
          </div>

          <div className="flex justify-center mb-6">
            <div className="flex bg-gray-200 rounded-full p-1 overflow-x-auto max-w-full">
              {roles.map((role) => (
                <button
                  key={role.id}
                  onClick={() => setSelectedRole(role.id)}
                  className={`px-4 py-2 text-sm font-semibold rounded-full transition-colors duration-300 whitespace-nowrap ${
                    selectedRole === role.id ? 'bg-indigo-600 text-white shadow' : 'text-gray-600'
                  }`}
                >
                  {role.label}
                </button>
              ))}
            </div>
          </div>

          <form onSubmit={handleLogin}>
            <div className="mb-4 relative">
              <UserIcon className="w-5 h-5 text-gray-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="tel"
                placeholder="मोबाइल नंबर"
                value={mobile}
                onChange={(e) => setMobile(e.target.value)}
                className="w-full pl-10 p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition"
                required
              />
            </div>
            <div className="mb-6 relative">
              <LockIcon className="w-5 h-5 text-gray-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="password"
                placeholder="पासवर्ड"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full pl-10 p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition"
                required
              />
            </div>
            {error && (
              <div className="bg-red-50 border-l-4 border-red-500 p-3 mb-4 rounded animate-pulse">
                  <p className="text-red-700 text-sm font-medium whitespace-pre-line text-center">{error}</p>
                  {error.includes("Permission Error") && (
                     <button 
                       type="button"
                       onClick={() => window.location.reload()}
                       className="text-xs text-indigo-600 underline block w-full text-center mt-1"
                     >
                        Fix: Click to Fix Login & Reload
                     </button>
                  )}
              </div>
            )}
            <button
              type="submit"
              disabled={loading}
              className="w-full bg-indigo-600 text-white py-3 rounded-lg font-semibold hover:bg-indigo-700 transition-all duration-300 transform hover:scale-105 disabled:bg-gray-400 disabled:cursor-not-allowed disabled:scale-100 shadow-lg"
            >
              {loading ? (
                  <span className="flex items-center justify-center">
                      <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                          <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                          <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                      </svg>
                      कनेक्ट हो रहा है... (Online)
                  </span>
              ) : 'लॉगिन करें'}
            </button>
          </form>
          
          <div className="text-center mt-6">
            <a href="https://wa.me/919876543210" target="_blank" rel="noopener noreferrer" className="inline-flex items-center text-sm text-green-600 hover:text-green-700 font-semibold">
              <WhatsAppIcon className="w-5 h-5 mr-2"/>
              पासवर्ड भूल गए? सहायता के लिए संपर्क करें।
            </a>
          </div>
        </div>
      </div>
      
      <div className="w-full md:w-1/2 lg:w-3/5 mt-8 md:mt-0 p-4 hidden md:block">
        <div className="bg-white rounded-2xl shadow-2xl p-8 max-h-[80vh] overflow-y-auto">
          <h2 className="text-2xl font-bold text-gray-800 mb-6 border-b-2 border-indigo-500 pb-2">सूचना पट्ट (Notice Board)</h2>
          {notices.length > 0 ? (
            <div className="space-y-6">
              {notices.map(notice => (
                <div key={notice.id} className="p-4 border-l-4 border-indigo-500 bg-indigo-50 rounded-r-lg">
                  <div className="flex justify-between items-center">
                    <h3 className="text-lg font-semibold text-indigo-800">{notice.title}</h3>
                    <span className="text-xs font-medium text-gray-500">{new Date(notice.date).toLocaleDateString('hi-IN')}</span>
                  </div>
                  <p className="mt-2 text-gray-700">{notice.content}</p>
                </div>
              ))}
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center text-gray-400 py-10">
                <BellIcon className="w-12 h-12 mb-2 opacity-20"/>
                <p>अभी कोई सूचना उपलब्ध नहीं है।</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default LoginScreen;