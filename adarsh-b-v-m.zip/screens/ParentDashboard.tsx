
import React, { useState, useEffect, useCallback } from 'react';
import { Parent, Student, Attendance, Homework, Remark, TestResult, FeeStructure, FeeTransaction, TimetableEntry, StudentLeaveRequest, GalleryItem } from '../types';
import { api, SCHOOL_LOGO_URL } from '../services/api';
import { LogoutIcon, UserIcon, SchoolIcon, CameraIcon, RupeeIcon, ReceiptIcon, BellIcon, TrashIcon, PaperClipIcon, ClockIcon, SendIcon } from '../components/icons';
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';

interface ParentDashboardProps {
  user: Parent;
  onLogout: () => void;
}

const ParentDashboard: React.FC<ParentDashboardProps> = ({ user, onLogout }) => {
  const [activeTab, setActiveTab] = useState('homework');
  const [child, setChild] = useState<Student | null>(null);
  const [attendance, setAttendance] = useState<Attendance[]>([]);
  const [homework, setHomework] = useState<(Homework & { remark?: string })[]>([]);
  const [results, setResults] = useState<TestResult[]>([]);
  const [timetable, setTimetable] = useState<TimetableEntry[]>([]);
  const [uploadingPhoto, setUploadingPhoto] = useState(false);
  
  // Result State
  const [consolidatedMarks, setConsolidatedMarks] = useState<any[]>([]);
  const [isGeneratingPDF, setIsGeneratingPDF] = useState(false);
  
  // Leave State
  const [leaves, setLeaves] = useState<StudentLeaveRequest[]>([]);
  const [newLeave, setNewLeave] = useState({ startDate: '', endDate: '', reason: '' });

  // Fee State
  const [feeInfo, setFeeInfo] = useState<{
      structure: (FeeStructure & {total: number})[],
      transactions: FeeTransaction[],
      totalPayable: number,
      totalPaid: number,
      balance: number
  } | null>(null);
  const [paymentModalOpen, setPaymentModalOpen] = useState(false);
  const [paymentAmount, setPaymentAmount] = useState<number>(0);
  const [paymentType, setPaymentType] = useState<'Admission' | 'Tuition' | 'Exam'>('Tuition');

  // Gallery
  const [galleryItems, setGalleryItems] = useState<GalleryItem[]>([]);

  const fetchData = useCallback(async () => {
    const studentData = await api.getStudentById(user.childId);
    setChild(studentData);
    if (studentData) {
      const attendanceData = await api.getAttendance(studentData.id);
      setAttendance(attendanceData);

      const homeworkData = await api.getHomeworkForClass(studentData.class);
      const remarksData = await api.getRemarksForStudent(studentData.id);
      const timetableData = await api.getTimetableForClass(studentData.class);

      const combinedHomework = homeworkData.map(hw => {
        const remark = remarksData.find(r => r.homeworkId === hw.id);
        return { ...hw, remark: remark?.remark };
      }).sort((a,b) => new Date(b.date).getTime() - new Date(a.date).getTime());
      
      setHomework(combinedHomework);
      setResults(await api.getResults(studentData.id));
      setFeeInfo(await api.getStudentFeeInfo(studentData.id));
      setTimetable(timetableData);
      setConsolidatedMarks(await api.getConsolidatedMarks(studentData.id));
      
      setLeaves(await api.getStudentLeaves(user.id));
      setGalleryItems(await api.getGalleryItems());
    }
  }, [user.childId, user.id]);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  // Consecutive Absence Alert Logic
  useEffect(() => {
      const checkConsecutiveAbsences = async () => {
          if (!child || !attendance.length) return;

          // Sort attendance by date descending
          const sortedAttendance = [...attendance]
              .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

          // We need at least 3 records to check for 3 consecutive absences
          if (sortedAttendance.length < 3) return;

          // Take the last 3 recorded attendance days
          const last3 = sortedAttendance.slice(0, 3);

          // Check if all 3 statuses are 'Absent'
          const allAbsent = last3.every(a => a.status === 'Absent');

          if (allAbsent) {
              // Now check if they are consecutive SCHOOL days (ignoring Sundays)
              let isConsecutive = true;
              
              for (let i = 0; i < last3.length - 1; i++) {
                  const current = new Date(last3[i].date);
                  const next = new Date(last3[i+1].date);
                  
                  // Calculate difference in days
                  const diffTime = Math.abs(current.getTime() - next.getTime());
                  const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
                  
                  if (diffDays === 1) {
                      // Consecutive calendar days
                      continue;
                  } else {
                      // If gap is > 1, check if the gap consists ONLY of Sundays
                      let gapOnlySundays = true;
                      // Check all days between next and current
                      const tempDate = new Date(next);
                      tempDate.setDate(tempDate.getDate() + 1);
                      
                      while (tempDate < current) {
                          if (tempDate.getDay() !== 0) { // 0 is Sunday
                              gapOnlySundays = false;
                              break;
                          }
                          tempDate.setDate(tempDate.getDate() + 1);
                      }
                      
                      if (!gapOnlySundays) {
                          isConsecutive = false;
                          break;
                      }
                  }
              }

              if (isConsecutive) {
                   // Check if we already alerted today to prevent spam
                   const alertKey = `absence_alert_${child.id}_${new Date().toISOString().split('T')[0]}`;
                   const alreadyAlerted = localStorage.getItem(alertKey);
                   
                   if (!alreadyAlerted) {
                       try {
                           // Send automated message from Principal (ID: principal1) to Parent (user.id)
                           // Assuming principal1 exists as per seed data
                           await api.sendMessage('principal1', user.id, `ALERT: Your child ${child.name} has been absent for 3 consecutive school days.`);
                           
                           localStorage.setItem(alertKey, 'true');
                           alert(`Notice: An automated alert has been sent to your registered mobile regarding ${child.name}'s 3 consecutive absences.`);
                       } catch (e) {
                           console.error("Failed to send absence alert", e);
                       }
                   }
              }
          }
      };
      
      checkConsecutiveAbsences();
  }, [child, attendance, user.id]);

  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file && child) {
        setUploadingPhoto(true);
        
        const compressImage = (file: File): Promise<string> => {
            return new Promise((resolve, reject) => {
                const reader = new FileReader();
                reader.readAsDataURL(file);
                reader.onload = (event) => {
                    const img = new Image();
                    img.src = event.target?.result as string;
                    img.onload = () => {
                        const canvas = document.createElement('canvas');
                        const MAX_WIDTH = 400;
                        const MAX_HEIGHT = 400;
                        let width = img.width;
                        let height = img.height;

                        if (width > height) {
                            if (width > MAX_WIDTH) {
                                height *= MAX_WIDTH / width;
                                width = MAX_WIDTH;
                            }
                        } else {
                            if (height > MAX_HEIGHT) {
                                width *= MAX_HEIGHT / height;
                                height = MAX_HEIGHT;
                            }
                        }

                        canvas.width = width;
                        canvas.height = height;
                        const ctx = canvas.getContext('2d');
                        ctx?.drawImage(img, 0, 0, width, height);
                        resolve(canvas.toDataURL('image/jpeg', 0.8));
                    };
                    img.onerror = reject;
                };
                reader.onerror = reject;
            });
        };

        try {
            const base64String = await compressImage(file);
            await api.updateStudentProfilePicture(child.id, base64String);
            setChild({...child, profilePicture: base64String});
        } catch (error) {
            console.error("Error uploading image", error);
            alert("फोटो अपलोड करने में त्रुटि हुई। कृपया पुनः प्रयास करें।");
        } finally {
            setUploadingPhoto(false);
        }
    }
  };

  const handleRemovePhoto = async () => {
    if (child && child.profilePicture) {
        if (window.confirm("क्या आप निश्चित रूप से प्रोफ़ाइल फ़ोटो हटाना चाहते हैं?")) {
            try {
                await api.updateStudentProfilePicture(child.id, '');
                setChild({ ...child, profilePicture: undefined });
            } catch (error) {
                console.error("Error removing image", error);
            }
        }
    }
  };

  const handlePayment = async (e: React.FormEvent) => {
      e.preventDefault();
      if(child && paymentAmount > 0) {
          await api.payFee(child.id, paymentAmount, paymentType, 'Online');
          alert('Payment Recorded Successfully!');
          setPaymentModalOpen(false);
          fetchData();
      }
  };
  
  const handleApplyLeave = async (e: React.FormEvent) => {
      e.preventDefault();
      if(newLeave.startDate && newLeave.endDate && newLeave.reason && child) {
           if(new Date(newLeave.endDate) < new Date(newLeave.startDate)) {
               alert("End date cannot be before start date.");
               return;
           }
           await api.applyStudentLeave({
               parentId: user.id,
               studentId: child.id,
               startDate: newLeave.startDate,
               endDate: newLeave.endDate,
               reason: newLeave.reason
           });
           alert("Leave application submitted successfully!");
           setNewLeave({ startDate: '', endDate: '', reason: '' });
           fetchData();
      }
  };

  const downloadReceipt = (tx: FeeTransaction) => {
      if(!child) return;
      const doc = new jsPDF();
      doc.setDrawColor(79, 70, 229);
      doc.setLineWidth(1.5);
      doc.rect(10, 10, 190, 100);
      
      doc.setFontSize(20);
      doc.setTextColor(79, 70, 229);
      doc.text("Adarsh Bal Vidya Mandir", 105, 25, { align: "center" });
      doc.setFontSize(10);
      doc.setTextColor(100);
      doc.text("FEE RECEIPT", 105, 32, { align: "center" });
      
      doc.setFontSize(12);
      doc.setTextColor(0);
      doc.text(`Receipt No: ${tx.id.toUpperCase().substring(0,8)}`, 20, 45);
      doc.text(`Date: ${new Date(tx.date).toLocaleDateString()}`, 150, 45);
      
      doc.text(`Student Name: ${child.name}`, 20, 55);
      doc.text(`Class: ${child.class}`, 150, 55);
      
      doc.line(20, 60, 190, 60);
      
      doc.text("Description", 20, 70);
      doc.text("Amount", 170, 70, { align: "right" });
      
      doc.text(`${tx.type} Fee`, 20, 80);
      doc.text(`${tx.amount.toFixed(2)}`, 170, 80, { align: "right" });
      
      doc.line(20, 85, 190, 85);
      doc.setFont("helvetica", "bold");
      doc.text("Total Paid:", 120, 95);
      doc.text(`Rs. ${tx.amount.toFixed(2)}`, 170, 95, { align: "right" });
      
      doc.setFont("helvetica", "normal");
      doc.setFontSize(10);
      doc.text("Authorized Signatory", 170, 105, { align: "right" });
      
      doc.save(`Receipt_${tx.id}.pdf`);
  };

  const downloadFinalMarksheet = async () => {
      if(!child) return;
      setIsGeneratingPDF(true);
      try {
          const doc = new jsPDF();
          const pageWidth = doc.internal.pageSize.width;
          const pageHeight = doc.internal.pageSize.height;
          
          // --- Page Border ---
          doc.setDrawColor(63, 81, 181); // Indigo border
          doc.setLineWidth(1.5);
          doc.rect(5, 5, pageWidth - 10, pageHeight - 10);
          doc.setLineWidth(0.5);
          doc.rect(7, 7, pageWidth - 14, pageHeight - 14);
          
          // --- Header Section ---
          try {
              const img = new Image();
              img.src = SCHOOL_LOGO_URL;
              await new Promise((resolve, reject) => {
                  img.onload = resolve;
                  img.onerror = reject;
              });
              doc.addImage(img, 'PNG', 15, 12, 25, 25);
          } catch (e) {
              console.warn("Logo loading failed for PDF", e);
          }

          doc.setFont("helvetica", "bold");
          doc.setFontSize(24);
          doc.setTextColor(63, 81, 181);
          doc.text("ADARSH BAL VIDYA MANDIR", pageWidth / 2, 22, { align: "center" });
          
          doc.setFontSize(10);
          doc.setTextColor(80);
          doc.setFont("helvetica", "normal");
          doc.text("Bilgram - Hardoi, Uttar Pradesh | Estd. 1995", pageWidth / 2, 28, { align: "center" });
          doc.text("Affiliated to State Board of Education", pageWidth / 2, 33, { align: "center" });

          doc.setDrawColor(200);
          doc.line(15, 40, pageWidth - 15, 40);

          doc.setFontSize(16);
          doc.setTextColor(0);
          doc.setFont("helvetica", "bold");
          doc.text("ANNUAL PROGRESS REPORT", pageWidth / 2, 50, { align: "center" });
          doc.setFontSize(12);
          doc.setFont("helvetica", "normal");
          doc.text("ACADEMIC SESSION: 2024-2025", pageWidth / 2, 57, { align: "center" });

          // --- Student Profile Section ---
          doc.setFillColor(248, 250, 252); // Light gray-blue background
          doc.setDrawColor(226, 232, 240);
          doc.roundedRect(15, 65, pageWidth - 30, 32, 2, 2, 'FD');

          doc.setFontSize(10);
          doc.setTextColor(0);
          
          const leftColX = 22;
          const rightColX = 120;
          const row1Y = 73;
          const row2Y = 81;
          const row3Y = 89;

          doc.setFont("helvetica", "bold");
          doc.text("Student Name:", leftColX, row1Y);
          doc.setFont("helvetica", "normal");
          doc.text(child.name.toUpperCase(), leftColX + 30, row1Y);

          doc.setFont("helvetica", "bold");
          doc.text("Father's Name:", rightColX, row1Y);
          doc.setFont("helvetica", "normal");
          doc.text(child.fatherName.toUpperCase(), rightColX + 30, row1Y);

          doc.setFont("helvetica", "bold");
          doc.text("Class & Section:", leftColX, row2Y);
          doc.setFont("helvetica", "normal");
          doc.text(child.class, leftColX + 30, row2Y);

          doc.setFont("helvetica", "bold");
          doc.text("Roll Number:", rightColX, row2Y);
          doc.setFont("helvetica", "normal");
          doc.text(child.id.substring(0, 6).toUpperCase(), rightColX + 30, row2Y);
          
          doc.setFont("helvetica", "bold");
          doc.text("Date of Issue:", leftColX, row3Y);
          doc.setFont("helvetica", "normal");
          doc.text(new Date().toLocaleDateString('en-IN'), leftColX + 30, row3Y);

          doc.setFont("helvetica", "bold");
          doc.text("Mobile:", rightColX, row3Y);
          doc.setFont("helvetica", "normal");
          doc.text(child.mobile, rightColX + 30, row3Y);

          // --- Marks Table ---
          const tableData = consolidatedMarks.map(row => [
              row.subject,
              `${row.quarterly.obtained} / ${row.quarterly.max}`,
              `${row.halfYearly.obtained} / ${row.halfYearly.max}`,
              `${row.annual.obtained} / ${row.annual.max}`,
              row.total.obtained,
              row.total.max,
              row.grade
          ]);

          const grandTotalObtained = consolidatedMarks.reduce((acc, row) => acc + row.total.obtained, 0);
          const grandTotalMax = consolidatedMarks.reduce((acc, row) => acc + row.total.max, 0);
          const percentage = grandTotalMax > 0 ? ((grandTotalObtained / grandTotalMax) * 100).toFixed(2) : '0';

          autoTable(doc, {
              startY: 105,
              head: [['Subject', 'Quarterly', 'Half Yearly', 'Annual', 'Total Obt.', 'Max Marks', 'Grade']],
              body: tableData,
              theme: 'grid',
              headStyles: { 
                  fillColor: [63, 81, 181], 
                  textColor: 255, 
                  halign: 'center',
                  fontStyle: 'bold',
                  lineWidth: 0.1,
                  lineColor: [255, 255, 255]
              },
              columnStyles: {
                  0: { halign: 'left', fontStyle: 'bold' }, // Subject
                  1: { halign: 'center' },
                  2: { halign: 'center' },
                  3: { halign: 'center' },
                  4: { halign: 'center', fontStyle: 'bold', textColor: [63, 81, 181] },
                  5: { halign: 'center' },
                  6: { halign: 'center', fontStyle: 'bold' } // Grade
              },
              foot: [['GRAND TOTAL', '', '', '', grandTotalObtained, grandTotalMax, '']],
              footStyles: {
                  fillColor: [240, 240, 240],
                  textColor: 0,
                  fontStyle: 'bold',
                  halign: 'center'
              },
              styles: {
                  fontSize: 10,
                  cellPadding: 4
              }
          });

          // --- Performance Summary ---
          const finalY = (doc as any).lastAutoTable.finalY + 15;
          
          // Summary Box
          doc.setDrawColor(200);
          doc.setFillColor(240, 253, 244); // Light green tint
          doc.roundedRect(15, finalY, pageWidth - 30, 25, 2, 2, 'F');
          
          doc.setFontSize(12);
          doc.setTextColor(0);
          
          // Percentage
          doc.setFont("helvetica", "bold");
          doc.text(`Overall Percentage:`, 30, finalY + 10);
          doc.setFontSize(14);
          doc.setTextColor(63, 81, 181);
          doc.text(`${percentage}%`, 75, finalY + 10);
          
          // Attendance
          doc.setFontSize(12);
          doc.setTextColor(0);
          const presentDays = attendance.filter(a => a.status === 'Present').length;
          doc.text(`Total Attendance:`, 30, finalY + 18);
          doc.setFont("helvetica", "normal");
          doc.text(`${presentDays} / ${attendance.length} Days`, 75, finalY + 18);

          // Result Status
          const passed = parseFloat(percentage) >= 33;
          doc.setFont("helvetica", "bold");
          doc.setFontSize(14);
          doc.text("FINAL RESULT:", 120, finalY + 14);
          doc.setTextColor(passed ? 22 : 220, passed ? 163 : 38, passed ? 74 : 38); // Green or Red
          doc.text(passed ? "PASSED" : "NEEDS IMPROVEMENT", 160, finalY + 14);

          // --- Footer Signatures ---
          const signY = pageHeight - 35;
          doc.setDrawColor(0);
          doc.setLineWidth(0.5);
          doc.setTextColor(0);
          doc.setFontSize(10);
          doc.setFont("helvetica", "normal");

          // Teacher
          doc.line(30, signY, 80, signY);
          doc.text("Class Teacher Signature", 55, signY + 5, { align: "center" });
          
          // Principal
          doc.line(pageWidth - 80, signY, pageWidth - 30, signY);
          doc.text("Principal Signature", pageWidth - 55, signY + 5, { align: "center" });

          // Disclaimer
          doc.setFontSize(8);
          doc.setTextColor(150);
          doc.text(`Report Generated on: ${new Date().toLocaleString()}`, 15, pageHeight - 10);
          doc.text("This is a computer-generated document and does not require a physical seal.", pageWidth - 15, pageHeight - 10, { align: "right" });
          
          doc.save(`${child.name.replace(/\s+/g, '_')}_Final_Marksheet.pdf`);
      } catch (error) {
          console.error("Error generating PDF", error);
          alert("Failed to generate PDF. Please try again.");
      } finally {
          setIsGeneratingPDF(false);
      }
  };

  const renderContent = () => {
      switch(activeTab) {
          case 'homework':
              return (
                <div className="bg-white p-6 rounded-lg shadow-md">
                    <h3 className="text-xl font-bold mb-4 text-gray-800">होमवर्क</h3>
                    <div className="space-y-4">
                        {homework.length === 0 && <p className="text-gray-500">कोई होमवर्क नहीं मिला।</p>}
                        {homework.map(hw => (
                            <div key={hw.id} className="border-l-4 border-indigo-500 bg-gray-50 p-4 rounded-r-lg shadow-sm">
                                <div className="flex justify-between items-start">
                                    <div>
                                        <h4 className="font-semibold text-gray-800 text-lg">{hw.subject}</h4>
                                        <span className="text-sm text-gray-500">{new Date(hw.date).toLocaleDateString('hi-IN')}</span>
                                    </div>
                                    {hw.dueDate && (
                                        <span className="text-xs font-medium text-red-600 bg-white px-2 py-1 rounded border border-red-200">
                                            Due: {new Date(hw.dueDate).toLocaleDateString('hi-IN')}
                                        </span>
                                    )}
                                </div>
                                <p className="text-gray-700 mt-2">{hw.details}</p>
                                {hw.attachment && (
                                    <div className="mt-2">
                                        <a href={hw.attachment} download={hw.attachmentName || 'download'} className="text-indigo-600 hover:underline text-sm flex items-center font-medium">
                                            <PaperClipIcon className="w-4 h-4 mr-1" /> {hw.attachmentName || 'Download Attachment'}
                                        </a>
                                    </div>
                                )}
                                {hw.remark && (
                                    <p className="mt-3 text-sm bg-yellow-100 text-yellow-800 p-2 rounded border border-yellow-200"><strong>टीचर का रिमार्क:</strong> {hw.remark}</p>
                                )}
                            </div>
                        ))}
                    </div>
                </div>
              );
          case 'gallery':
               return (
                   <div className="bg-white p-6 rounded-lg shadow-md">
                       <h3 className="text-xl font-bold mb-6">School Gallery</h3>
                       <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                           {galleryItems.length === 0 && <p className="text-gray-500 col-span-full">No media available.</p>}
                           {galleryItems.map(item => (
                               <div key={item.id} className="border rounded overflow-hidden shadow-sm">
                                   <div className="h-48 bg-gray-100">
                                       {item.type === 'photo' ? (
                                           <img src={item.url} alt={item.title} className="w-full h-full object-cover" />
                                       ) : (
                                          item.url.includes('youtube.com') || item.url.includes('youtu.be') ? (
                                              <iframe 
                                                  width="100%" 
                                                  height="100%" 
                                                  src={item.url.replace("watch?v=", "embed/").replace("youtu.be/", "youtube.com/embed/")} 
                                                  title={item.title}
                                                  frameBorder="0" 
                                                  allowFullScreen
                                              ></iframe>
                                          ) : (
                                              <video src={item.url} controls className="w-full h-full object-cover bg-black" />
                                          )
                                       )}
                                   </div>
                                   <div className="p-3">
                                       <h4 className="font-bold truncate">{item.title}</h4>
                                       <p className="text-sm text-gray-500">{new Date(item.date).toLocaleDateString()}</p>
                                   </div>
                               </div>
                           ))}
                       </div>
                   </div>
               );
          case 'attendance':
              return (
                <div className="bg-white p-6 rounded-lg shadow-md">
                    <div className="flex justify-between items-center mb-4">
                        <h3 className="text-xl font-bold text-gray-800">उपस्थिति रिपोर्ट</h3>
                        <div className="text-sm">
                            <span className="inline-block w-3 h-3 bg-green-500 rounded-full mr-1"></span> P: उपस्थित
                            <span className="inline-block w-3 h-3 bg-red-500 rounded-full ml-3 mr-1"></span> A: अनुपस्थित
                        </div>
                    </div>
                    <div className="max-h-96 overflow-y-auto">
                        <table className="w-full text-left border-collapse">
                            <thead className="bg-gray-100 sticky top-0">
                                <tr>
                                    <th className="p-3 border-b">दिनांक</th>
                                    <th className="p-3 border-b text-center">स्थिति</th>
                                    <th className="p-3 border-b">विवरण</th>
                                </tr>
                            </thead>
                            <tbody className="divide-y">
                                {attendance.sort((a,b) => new Date(b.date).getTime() - new Date(a.date).getTime()).map((att, index) => (
                                    <tr key={index} className="hover:bg-gray-50">
                                        <td className="p-3">{new Date(att.date).toLocaleDateString('hi-IN', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}</td>
                                        <td className="p-3 text-center">
                                            <span className={`px-3 py-1 rounded-full text-xs font-bold ${att.status === 'Present' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`}>
                                                {att.status === 'Present' ? 'उपस्थित' : 'अनुपस्थित'}
                                            </span>
                                        </td>
                                        <td className="p-3 text-gray-600 text-sm">{att.reason || '-'}</td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                </div>
              );
           case 'leave':
               return (
                   <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                       <div className="bg-white p-6 rounded-lg shadow-md h-fit">
                           <h3 className="text-xl font-bold mb-4 flex items-center text-indigo-700">
                               <ClockIcon className="w-6 h-6 mr-2"/> छुट्टी आवेदन (Leave Application)
                           </h3>
                           <form onSubmit={handleApplyLeave} className="space-y-4">
                               <div className="grid grid-cols-2 gap-4">
                                   <div>
                                       <label className="block text-xs font-bold mb-1 text-gray-600">Start Date</label>
                                       <input type="date" value={newLeave.startDate} onChange={e => setNewLeave({...newLeave, startDate: e.target.value})} className="w-full p-2 border rounded" required />
                                   </div>
                                   <div>
                                       <label className="block text-xs font-bold mb-1 text-gray-600">End Date</label>
                                       <input type="date" value={newLeave.endDate} onChange={e => setNewLeave({...newLeave, endDate: e.target.value})} className="w-full p-2 border rounded" required />
                                   </div>
                               </div>
                               <div>
                                   <label className="block text-xs font-bold mb-1 text-gray-600">Reason (कारण)</label>
                                   <textarea 
                                       value={newLeave.reason} 
                                       onChange={e => setNewLeave({...newLeave, reason: e.target.value})} 
                                       className="w-full p-2 border rounded" 
                                       rows={3} 
                                       placeholder="e.g. Fever, Family function..." 
                                       required
                                   ></textarea>
                               </div>
                               <button type="submit" className="w-full bg-indigo-600 text-white py-2 rounded hover:bg-indigo-700 flex items-center justify-center font-semibold">
                                   <SendIcon className="w-4 h-4 mr-2"/> Submit Request
                               </button>
                           </form>
                       </div>

                       <div className="bg-white p-6 rounded-lg shadow-md">
                           <h3 className="text-lg font-bold mb-4 text-gray-800">Previous Applications</h3>
                           <div className="space-y-3 max-h-80 overflow-y-auto">
                               {leaves.length === 0 && <p className="text-gray-400 text-sm">No leave history found.</p>}
                               {leaves.sort((a,b) => new Date(b.requestDate).getTime() - new Date(a.requestDate).getTime()).map(leave => (
                                   <div key={leave.id} className="border p-3 rounded hover:bg-gray-50">
                                       <div className="flex justify-between items-start">
                                           <div>
                                               <p className="text-sm font-bold text-gray-700">
                                                   {new Date(leave.startDate).toLocaleDateString()} - {new Date(leave.endDate).toLocaleDateString()}
                                               </p>
                                               <p className="text-xs text-gray-500 italic mt-1">"{leave.reason}"</p>
                                           </div>
                                           <span className={`text-xs px-2 py-1 rounded font-bold ${
                                               leave.status === 'Approved' ? 'bg-green-100 text-green-800' : 
                                               leave.status === 'Rejected' ? 'bg-red-100 text-red-800' : 
                                               'bg-yellow-100 text-yellow-800'
                                           }`}>
                                               {leave.status}
                                           </span>
                                       </div>
                                       {leave.status === 'Approved' && <p className="text-[10px] text-green-600 mt-1">Approved by Principal</p>}
                                   </div>
                               ))}
                           </div>
                       </div>
                   </div>
               );
           case 'fees':
                if (!feeInfo) return <div>Loading...</div>;
                return (
                    <div className="space-y-6">
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                            <div className="bg-blue-50 p-4 rounded border border-blue-200">
                                <div className="text-gray-500 text-sm font-bold uppercase">Total Payable</div>
                                <div className="text-2xl font-bold text-blue-800">₹{feeInfo.totalPayable.toLocaleString('en-IN')}</div>
                            </div>
                            <div className="bg-green-50 p-4 rounded border border-green-200">
                                <div className="text-gray-500 text-sm font-bold uppercase">Total Paid</div>
                                <div className="text-2xl font-bold text-green-800">₹{feeInfo.totalPaid.toLocaleString('en-IN')}</div>
                            </div>
                            <div className="bg-red-50 p-4 rounded border border-red-200">
                                <div className="text-gray-500 text-sm font-bold uppercase">Balance Due</div>
                                <div className="text-2xl font-bold text-red-800">₹{feeInfo.balance.toLocaleString('en-IN')}</div>
                            </div>
                        </div>
                        
                        {feeInfo.balance > 0 && (
                            <div className="bg-white p-4 rounded shadow flex justify-between items-center border-l-4 border-orange-500">
                                <div>
                                    <h4 className="font-bold text-gray-800">Pay Outstanding Fees</h4>
                                    <p className="text-sm text-gray-500">Record online or cash payment.</p>
                                </div>
                                <button onClick={() => setPaymentModalOpen(true)} className="bg-indigo-600 text-white px-6 py-2 rounded hover:bg-indigo-700 shadow">Pay Now</button>
                            </div>
                        )}

                        <div className="bg-white p-6 rounded-lg shadow-md">
                            <h3 className="text-lg font-bold mb-4">Transaction History</h3>
                            {feeInfo.transactions.length === 0 ? (
                                <p className="text-gray-500">No transactions found.</p>
                            ) : (
                                <div className="overflow-x-auto">
                                    <table className="w-full text-left">
                                        <thead className="bg-gray-100"><tr><th className="p-3">Date</th><th className="p-3">Type</th><th className="p-3">Amount</th><th className="p-3">Method</th><th className="p-3">Receipt</th></tr></thead>
                                        <tbody className="divide-y">
                                            {feeInfo.transactions.map(t => (
                                                <tr key={t.id}>
                                                    <td className="p-3">{new Date(t.date).toLocaleDateString()}</td>
                                                    <td className="p-3">{t.type}</td>
                                                    <td className="p-3 font-bold text-gray-800">₹{t.amount}</td>
                                                    <td className="p-3 text-sm">{t.paymentMethod}</td>
                                                    <td className="p-3">
                                                        <button onClick={() => downloadReceipt(t)} className="text-indigo-600 hover:underline text-sm flex items-center"><ReceiptIcon className="w-4 h-4 mr-1"/> Download</button>
                                                    </td>
                                                </tr>
                                            ))}
                                        </tbody>
                                    </table>
                                </div>
                            )}
                        </div>
                    </div>
                );
           case 'timetable':
                  const days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
                  const periods = [1, 2, 3, 4, 5, 6, 7, 8];
                  return (
                      <div className="bg-white p-6 rounded-lg shadow-md overflow-x-auto">
                          <h3 className="text-xl font-bold mb-4">Weekly Timetable</h3>
                          <table className="w-full border-collapse border border-gray-200">
                              <thead>
                                  <tr className="bg-indigo-600 text-white">
                                      <th className="p-3 border w-24">Day</th>
                                      {periods.map(p => <th key={p} className="p-3 border text-center">{p}</th>)}
                                  </tr>
                              </thead>
                              <tbody>
                                  {days.map(day => (
                                      <tr key={day} className="bg-white hover:bg-gray-50">
                                          <td className="p-3 border font-bold bg-gray-100">{day}</td>
                                          {periods.map(period => {
                                              const entry = timetable.find(t => t.day === day && t.period === period);
                                              return (
                                                  <td key={period} className="p-2 border text-center h-16 align-middle">
                                                      {entry ? (
                                                          <div className="bg-indigo-50 p-1 rounded border border-indigo-100">
                                                              <div className="font-bold text-indigo-800 text-sm">{entry.subject}</div>
                                                              <div className="text-[10px] text-gray-400">{entry.startTime}-{entry.endTime}</div>
                                                          </div>
                                                      ) : <span className="text-gray-200">-</span>}
                                                  </td>
                                              );
                                          })}
                                      </tr>
                                  ))}
                              </tbody>
                          </table>
                      </div>
                  );
           case 'results':
               return (
                <div className="bg-white p-6 rounded-lg shadow-md">
                    <div className="flex flex-col sm:flex-row justify-between items-center mb-6 border-b pb-4">
                        <div>
                            <h3 className="text-xl font-bold text-gray-800">Annual Report Card</h3>
                            <p className="text-sm text-gray-500">Download the official marksheet comprising all exam terms.</p>
                        </div>
                        <button 
                            onClick={downloadFinalMarksheet} 
                            disabled={isGeneratingPDF || consolidatedMarks.length === 0}
                            className={`mt-4 sm:mt-0 bg-indigo-600 text-white px-6 py-3 rounded-lg shadow-lg flex items-center transition-all transform hover:scale-105 ${isGeneratingPDF || consolidatedMarks.length === 0 ? 'opacity-60 cursor-not-allowed' : 'hover:bg-indigo-700'}`}
                        >
                             {isGeneratingPDF ? (
                                 <span className="flex items-center">
                                     <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                                         <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                                         <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                                     </svg>
                                     Preparing PDF...
                                 </span>
                             ) : (
                                 <>
                                    <ReceiptIcon className="w-5 h-5 mr-2" /> Download Result (PDF)
                                 </>
                             )}
                        </button>
                    </div>
                    
                    <div className="overflow-x-auto">
                        <table className="w-full border-collapse border">
                            <thead>
                                <tr className="bg-indigo-50 text-indigo-900">
                                    <th className="p-3 border border-indigo-200 text-left">Subject</th>
                                    <th className="p-3 border border-indigo-200 text-center">Timahi (Quarterly)</th>
                                    <th className="p-3 border border-indigo-200 text-center">Chhimahi (Half Yearly)</th>
                                    <th className="p-3 border border-indigo-200 text-center">Salana (Annual)</th>
                                    <th className="p-3 border border-indigo-200 text-center font-bold">Total</th>
                                    <th className="p-3 border border-indigo-200 text-center font-bold">Grade</th>
                                </tr>
                            </thead>
                            <tbody>
                                {consolidatedMarks.map((row, idx) => (
                                    <tr key={idx} className="hover:bg-gray-50">
                                        <td className="p-3 border font-medium">{row.subject}</td>
                                        <td className="p-3 border text-center">
                                            {row.quarterly.obtained} <span className="text-gray-400 text-xs">/ {row.quarterly.max}</span>
                                        </td>
                                        <td className="p-3 border text-center">
                                            {row.halfYearly.obtained} <span className="text-gray-400 text-xs">/ {row.halfYearly.max}</span>
                                        </td>
                                        <td className="p-3 border text-center">
                                            {row.annual.obtained} <span className="text-gray-400 text-xs">/ {row.annual.max}</span>
                                        </td>
                                        <td className="p-3 border text-center font-bold text-indigo-700">
                                            {row.total.obtained} / {row.total.max}
                                        </td>
                                        <td className="p-3 border text-center font-bold">
                                            <span className={`px-2 py-1 rounded text-xs ${['A+','A'].includes(row.grade) ? 'bg-green-100 text-green-800' : 'bg-gray-100'}`}>{row.grade}</span>
                                        </td>
                                    </tr>
                                ))}
                                {consolidatedMarks.length > 0 && (
                                    <tr className="bg-gray-100 font-bold">
                                        <td className="p-3 border">GRAND TOTAL</td>
                                        <td className="p-3 border text-center" colSpan={3}></td>
                                        <td className="p-3 border text-center text-lg text-indigo-800">
                                            {consolidatedMarks.reduce((acc, r) => acc + r.total.obtained, 0)} / {consolidatedMarks.reduce((acc, r) => acc + r.total.max, 0)}
                                        </td>
                                        <td className="p-3 border text-center"></td>
                                    </tr>
                                )}
                            </tbody>
                        </table>
                        {consolidatedMarks.length === 0 && <div className="p-8 text-center text-gray-500 border-2 border-dashed border-gray-200 rounded mt-4">No exam data available yet. Results will appear here once published by the Principal.</div>}
                    </div>
                </div>
               );
          default: return null;
      }
  };

  return (
    <div className="min-h-screen bg-gray-100">
      <header className="bg-white shadow-md p-4 flex justify-between items-center sticky top-0 z-20">
        <div className="flex items-center space-x-3">
             <div className="bg-indigo-100 p-2 rounded-full">
                <SchoolIcon className="w-6 h-6 text-indigo-600" />
             </div>
             <div>
                <h1 className="text-lg font-bold text-gray-800">Parent Dashboard</h1>
                <p className="text-xs text-gray-500">Welcome, {user.name}</p>
             </div>
        </div>
        <button onClick={onLogout} className="flex items-center space-x-2 bg-red-500 text-white px-4 py-2 rounded hover:bg-red-600 transition">
          <LogoutIcon className="w-5 h-5" />
          <span className="hidden md:inline">Logout</span>
        </button>
      </header>

      <main className="p-4 md:p-6 max-w-5xl mx-auto">
        {child ? (
            <>
                <div className="bg-white p-6 rounded-lg shadow-md mb-6">
                    <div className="flex flex-col md:flex-row items-center md:items-start md:space-x-6">
                        <div className="relative group w-24 h-24 mb-4 md:mb-0">
                             <div className="w-24 h-24 rounded-full overflow-hidden border-4 border-indigo-100 shadow-sm">
                                 {child.profilePicture ? (
                                     <img src={child.profilePicture} alt={child.name} className="w-full h-full object-cover" />
                                 ) : (
                                     <div className="w-full h-full bg-indigo-50 flex items-center justify-center">
                                         <UserIcon className="w-12 h-12 text-indigo-300" />
                                     </div>
                                 )}
                             </div>
                             <label className="absolute bottom-0 right-0 bg-indigo-600 text-white p-1.5 rounded-full cursor-pointer hover:bg-indigo-700 shadow-lg" title="Upload Photo">
                                 <CameraIcon className="w-4 h-4" />
                                 <input type="file" className="hidden" accept="image/*" onChange={handleImageUpload} disabled={uploadingPhoto} />
                             </label>
                             {child.profilePicture && (
                                 <button onClick={handleRemovePhoto} className="absolute top-0 right-0 bg-red-500 text-white p-1 rounded-full hover:bg-red-600 shadow-lg" title="Remove Photo">
                                     <TrashIcon className="w-3 h-3" />
                                 </button>
                             )}
                        </div>
                        <div className="flex-1 text-center md:text-left">
                            <h2 className="text-2xl font-bold text-gray-800">{child.name}</h2>
                            <div className="mt-2 grid grid-cols-1 sm:grid-cols-2 gap-x-8 gap-y-2 text-sm text-gray-600">
                                <p><span className="font-semibold">Class:</span> {child.class}</p>
                                <p><span className="font-semibold">Roll No:</span> {child.id.substring(0,6).toUpperCase()}</p>
                                <p><span className="font-semibold">Father:</span> {child.fatherName}</p>
                                <p><span className="font-semibold">Contact:</span> {child.mobile}</p>
                            </div>
                        </div>
                        {feeInfo && feeInfo.balance > 0 && (
                            <div className="bg-red-50 border border-red-200 rounded-lg p-4 text-center md:text-right mt-4 md:mt-0">
                                <p className="text-xs text-red-600 font-bold uppercase">Fee Due</p>
                                <p className="text-xl font-bold text-red-800">₹{feeInfo.balance}</p>
                                <button onClick={() => { setActiveTab('fees'); setPaymentModalOpen(true); }} className="text-xs text-indigo-600 underline mt-1 hover:text-indigo-800">Pay Now</button>
                            </div>
                        )}
                    </div>
                </div>

                <div className="flex overflow-x-auto space-x-4 mb-6 pb-2">
                    {[
                        { id: 'homework', label: 'Homework & Remarks' },
                        { id: 'gallery', label: 'Gallery' },
                        { id: 'attendance', label: 'Attendance' },
                        { id: 'timetable', label: 'Time Table' },
                        { id: 'results', label: 'Results' },
                        { id: 'fees', label: 'Fees' },
                        { id: 'leave', label: 'Leave Application' }
                    ].map(tab => (
                        <button
                            key={tab.id}
                            onClick={() => setActiveTab(tab.id)}
                            className={`px-6 py-2 rounded-full font-semibold whitespace-nowrap transition-all ${
                                activeTab === tab.id 
                                ? 'bg-indigo-600 text-white shadow-lg transform scale-105' 
                                : 'bg-white text-gray-600 hover:bg-gray-50'
                            }`}
                        >
                            {tab.label}
                        </button>
                    ))}
                </div>

                <div className="animate-fade-in">
                    {renderContent()}
                </div>
            </>
        ) : (
            <div className="text-center py-20">
                <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600 mx-auto mb-4"></div>
                <p className="text-gray-500">Loading student data...</p>
            </div>
        )}
      </main>

      {/* Payment Modal */}
      {paymentModalOpen && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-50 px-4">
              <div className="bg-white p-6 rounded-lg shadow-xl w-full max-w-md">
                  <h2 className="text-xl font-bold mb-4 text-green-700">Pay Fees Online</h2>
                  <form onSubmit={handlePayment}>
                      <div className="mb-4">
                          <label className="block text-sm font-medium">Payment Type</label>
                          <select value={paymentType} onChange={e => setPaymentType(e.target.value as any)} className="w-full p-2 border rounded">
                              <option value="Tuition">Tuition Fee</option>
                              <option value="Admission">Admission Fee</option>
                              <option value="Exam">Exam Fee</option>
                              <option value="Annual">Annual Charge</option>
                          </select>
                      </div>
                      <div className="mb-6">
                          <label className="block text-sm font-medium">Amount (₹)</label>
                          <input type="number" value={paymentAmount} onChange={e => setPaymentAmount(Number(e.target.value))} className="w-full p-2 border rounded" min="1" required />
                      </div>
                      
                      <div className="bg-yellow-50 p-3 rounded text-xs text-yellow-800 mb-4 border border-yellow-200">
                          Note: This is a demo payment. No actual money will be deducted.
                      </div>

                      <div className="flex justify-end space-x-2">
                          <button type="button" onClick={() => setPaymentModalOpen(false)} className="px-4 py-2 border rounded">Cancel</button>
                          <button type="submit" className="px-4 py-2 bg-green-600 text-white rounded font-bold shadow">Pay Now</button>
                      </div>
                  </form>
              </div>
          </div>
      )}
    </div>
  );
};

export default ParentDashboard;
