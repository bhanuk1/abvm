
import { initializeApp } from "firebase/app";
import { initializeFirestore } from "firebase/firestore";
import { getStorage } from "firebase/storage";
import { getAuth } from "firebase/auth";
import { getAnalytics } from "firebase/analytics";

const firebaseConfig = {
  apiKey: "AIzaSyCf8qqGnOs3XwbqLVgg_t-0haq7wY38Izk",
  authDomain: "abvm-school-app.firebaseapp.com",
  projectId: "abvm-school-app",
  storageBucket: "abvm-school-app.firebasestorage.app",
  messagingSenderId: "490867306272",
  appId: "1:490867306272:web:e677e0d1a08c33941bb145",
  measurementId: "G-49P2DPW9LK"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

// Initialize Firestore
// 'experimentalForceLongPolling' helps in certain restrictive networks (like corporate wifi or some emulators)
export const db = initializeFirestore(app, {
    experimentalForceLongPolling: true,
});

export const storage = getStorage(app);
export const auth = getAuth(app);
export const analytics = getAnalytics(app);
